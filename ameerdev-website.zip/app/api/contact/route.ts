import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, message, phone, subject } = body

    // Validate required fields
    if (!name || !email || !message) {
      return NextResponse.json({ error: "Name, email, and message are required" }, { status: 400 })
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json({ error: "Invalid email format" }, { status: 400 })
    }

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // In a real application, you would:
    // 1. Save to database
    // 2. Send email notification
    // 3. Integrate with email service (SendGrid, Mailgun, etc.)

    console.log("Contact form submission:", {
      name,
      email,
      message,
      phone,
      subject,
      timestamp: new Date().toISOString(),
    })

    // Simulate different responses for demo
    const responses = [
      {
        success: true,
        message: `Thank you ${name}! Your message has been received. I'll get back to you within 24 hours.`,
        id: `MSG-${Date.now()}`,
      },
      {
        success: true,
        message: `Hi ${name}! Thanks for reaching out. I'm excited to discuss your project with you!`,
        id: `MSG-${Date.now()}`,
      },
      {
        success: true,
        message: `Hello ${name}! Your inquiry has been submitted successfully. Looking forward to connecting with you soon!`,
        id: `MSG-${Date.now()}`,
      },
    ]

    const randomResponse = responses[Math.floor(Math.random() * responses.length)]

    return NextResponse.json(randomResponse, { status: 200 })
  } catch (error) {
    console.error("Contact form error:", error)
    return NextResponse.json({ error: "Internal server error. Please try again later." }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({ message: "Contact API is working! Use POST to submit contact forms." }, { status: 200 })
}
