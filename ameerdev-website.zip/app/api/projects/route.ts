import { type NextRequest, NextResponse } from "next/server"

const projects = [
  {
    id: 1,
    title: "E-Commerce Platform",
    description: "Full-stack e-commerce solution with advanced security features and payment integration",
    longDescription:
      "A comprehensive e-commerce platform built with modern technologies, featuring real-time inventory management, secure payment processing, advanced analytics, and mobile-responsive design. The platform handles thousands of transactions daily with 99.9% uptime.",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=600&fit=crop",
    tech: ["React", "Node.js", "MongoDB", "Stripe", "AWS", "Redis"],
    category: "Web Development",
    client: "TechMart Solutions",
    duration: "4 months",
    year: "2024",
    features: [
      "Real-time inventory management",
      "Secure payment processing with Stripe",
      "Advanced analytics dashboard",
      "Mobile-responsive design",
      "Multi-vendor support",
      "Automated email notifications",
    ],
    challenges: [
      "Handling high traffic loads during peak sales",
      "Implementing complex inventory synchronization",
      "Ensuring PCI DSS compliance for payments",
    ],
    results: ["300% increase in online sales", "50% reduction in cart abandonment", "99.9% uptime achievement"],
    testimonial: {
      text: "Ahmad delivered an exceptional e-commerce platform that exceeded our expectations. The attention to detail and security implementation is outstanding.",
      author: "Sarah Johnson",
      role: "CEO, TechMart Solutions",
    },
  },
  {
    id: 2,
    title: "Cybersecurity Dashboard",
    description: "Real-time threat monitoring and analysis system with AI-powered detection",
    longDescription:
      "An advanced cybersecurity dashboard that provides real-time threat monitoring, AI-powered anomaly detection, and comprehensive security analytics. The system processes millions of security events daily and provides actionable insights to security teams.",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&h=600&fit=crop",
    tech: ["Python", "React", "TensorFlow", "Docker", "Elasticsearch", "Kibana"],
    category: "Security",
    client: "SecureNet Corp",
    duration: "6 months",
    year: "2023",
    features: [
      "Real-time threat detection",
      "AI-powered anomaly analysis",
      "Comprehensive security reporting",
      "Integration with SIEM systems",
      "Automated incident response",
      "Custom alert configurations",
    ],
    challenges: [
      "Processing massive amounts of security data in real-time",
      "Reducing false positive rates in threat detection",
      "Creating intuitive visualizations for complex security data",
    ],
    results: [
      "85% reduction in false positives",
      "60% faster incident response time",
      "Prevented 15+ major security breaches",
    ],
    testimonial: {
      text: "The cybersecurity dashboard Ahmad built has transformed our security operations. We can now detect and respond to threats in real-time.",
      author: "Michael Chen",
      role: "CISO, SecureNet Corp",
    },
  },
  {
    id: 3,
    title: "Mobile Banking App",
    description: "Secure mobile banking application with biometric authentication",
    longDescription:
      "A cutting-edge mobile banking application featuring biometric authentication, real-time transaction processing, and advanced security measures. The app serves over 100,000 active users with bank-grade security and seamless user experience.",
    image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&h=600&fit=crop",
    tech: ["React Native", "Node.js", "PostgreSQL", "JWT", "Biometric APIs"],
    category: "Mobile",
    client: "FinanceFirst Bank",
    duration: "8 months",
    year: "2023",
    features: [
      "Biometric authentication (fingerprint, face ID)",
      "Real-time transaction processing",
      "Account balance and history",
      "Bill payment and transfers",
      "Investment portfolio tracking",
      "Push notifications for transactions",
    ],
    challenges: [
      "Implementing bank-grade security measures",
      "Ensuring seamless biometric authentication across devices",
      "Optimizing performance for real-time transactions",
    ],
    results: [
      "100,000+ active users within 6 months",
      "4.8/5 app store rating",
      "Zero security incidents since launch",
    ],
    testimonial: {
      text: "Ahmad's mobile banking app has revolutionized how our customers interact with their finances. The security and user experience are exceptional.",
      author: "Emily Rodriguez",
      role: "Digital Banking Director, FinanceFirst Bank",
    },
  },
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get("id")

  if (id) {
    const project = projects.find((p) => p.id === Number.parseInt(id))
    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }
    return NextResponse.json(project)
  }

  return NextResponse.json(projects)
}
