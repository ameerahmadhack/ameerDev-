"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Menu,
  Code,
  Shield,
  Sparkles,
  ArrowRight,
  Phone,
  Mail,
  MapPin,
  Github,
  Linkedin,
  Twitter,
  X,
  Home,
  User,
  Briefcase,
  MessageCircle,
  Star,
  FolderOpen,
  BookOpen,
  Calendar,
  Award,
  Clock,
  Send,
  ChevronLeft,
  ChevronRight,
  Monitor,
  Zap,
  TrendingUp,
  Thermometer,
  Wind,
  Eye,
  GitBranch,
  Activity,
  Terminal,
  Layers,
  Settings,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import Image from "next/image"

const pages = [
  { id: "home", title: "Home", icon: Home },
  { id: "about", title: "About", icon: User },
  { id: "services", title: "Services", icon: Briefcase },
  { id: "portfolio", title: "Portfolio", icon: FolderOpen },
  { id: "blog", title: "Blog", icon: BookOpen },
  { id: "contact", title: "Contact", icon: MessageCircle },
]

export default function AmeerDevWebsite() {
  const [currentPage, setCurrentPage] = useState("home")
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isMobile, setIsMobile] = useState(false)

  // Add project details state and functions in the main component
  const [selectedProject, setSelectedProject] = useState<any>(null)
  const [projectDetails, setProjectDetails] = useState<any>(null)
  const [isLoadingProject, setIsLoadingProject] = useState(false)

  // Add function to fetch project details
  const fetchProjectDetails = async (projectId: number) => {
    setIsLoadingProject(true)
    try {
      const response = await fetch(`/api/projects?id=${projectId}`)
      const data = await response.json()
      setProjectDetails(data)
      setSelectedProject(projectId)
    } catch (error) {
      console.error("Error fetching project details:", error)
    } finally {
      setIsLoadingProject(false)
    }
  }

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    window.addEventListener("mousemove", handleMouseMove)

    return () => {
      window.removeEventListener("resize", checkMobile)
      window.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  const AnimatedText = ({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) => (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  )

  const FloatingElement = ({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) => (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 1, delay, ease: "easeOut" }}
      className="absolute"
      animate={{
        y: [0, -10, 0],
        rotate: [0, 2, 0],
      }}
      transition={{
        duration: 8,
        repeat: Number.POSITIVE_INFINITY,
        ease: "easeInOut",
      }}
    >
      {children}
    </motion.div>
  )

  const HomePage = () => {
    const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; vx: number; vy: number }>>([])
    const [currentSkill, setCurrentSkill] = useState(0)
    const [isListening, setIsListening] = useState(false)
    const [voiceCommand, setVoiceCommand] = useState("")
    const [currentTime, setCurrentTime] = useState(new Date())
    const [typedText, setTypedText] = useState("")
    const [currentTestimonial, setCurrentTestimonial] = useState(0)
    const [currentProject, setCurrentProject] = useState(0)
    const [liveStats, setLiveStats] = useState({ visitors: 1247, projects: 52, clients: 28 })
    const [timelineStep, setTimelineStep] = useState(0)
    const [weatherData, setWeatherData] = useState({ temp: 24, condition: "Sunny", humidity: 65 })
    const [githubActivity, setGithubActivity] = useState({ commits: 127, repos: 15, contributions: 342 })
    const [codeMetrics, setCodeMetrics] = useState({ linesWritten: 15420, bugsFixed: 89, projectsDeployed: 23 })
    const [techTrends, setTechTrends] = useState([
      { name: "React", trend: "+15%", popularity: 92 },
      { name: "TypeScript", trend: "+22%", popularity: 88 },
      { name: "Next.js", trend: "+18%", popularity: 85 },
    ])
    const [clientLocations, setClientLocations] = useState([
      { country: "Nigeria", clients: 12, flag: "🇳🇬" },
      { country: "USA", clients: 8, flag: "🇺🇸" },
      { country: "UK", clients: 5, flag: "🇬🇧" },
      { country: "Canada", clients: 3, flag: "🇨🇦" },
    ])
    const [certifications, setCertifications] = useState([
      { name: "AWS Certified", level: "Professional", year: "2024" },
      { name: "Google Cloud", level: "Associate", year: "2023" },
      { name: "Cybersecurity+", level: "Certified", year: "2023" },
    ])
    const [currentCodeSnippet, setCurrentCodeSnippet] = useState(0)
    const [interactiveCode, setInteractiveCode] = useState("console.log('Hello, World!');")
    const [codeOutput, setCodeOutput] = useState("Hello, World!")

    const skills = [
      { name: "React/Next.js", level: 95, color: "from-blue-500 to-cyan-500" },
      { name: "Node.js", level: 90, color: "from-green-500 to-emerald-500" },
      { name: "Cyber Security", level: 88, color: "from-red-500 to-orange-500" },
      { name: "TypeScript", level: 92, color: "from-purple-500 to-pink-500" },
      { name: "Cloud Computing", level: 85, color: "from-indigo-500 to-blue-500" },
      { name: "Python", level: 87, color: "from-yellow-500 to-orange-500" },
    ]

    const techStack = [
      { name: "React", icon: "⚛️", color: "from-blue-400 to-blue-600" },
      { name: "Next.js", icon: "▲", color: "from-gray-700 to-gray-900" },
      { name: "Node.js", icon: "🟢", color: "from-green-400 to-green-600" },
      { name: "Python", icon: "🐍", color: "from-yellow-400 to-yellow-600" },
      { name: "MongoDB", icon: "🍃", color: "from-green-500 to-green-700" },
      { name: "AWS", icon: "☁️", color: "from-orange-400 to-orange-600" },
      { name: "Docker", icon: "🐳", color: "from-blue-500 to-blue-700" },
      { name: "GraphQL", icon: "◆", color: "from-pink-500 to-purple-600" },
    ]

    const achievements = [
      { number: "50+", label: "Projects Completed", icon: "🚀" },
      { number: "3+", label: "Years Experience", icon: "⏱️" },
      { number: "100%", label: "Client Satisfaction", icon: "⭐" },
      { number: "24/7", label: "Support Available", icon: "🛡️" },
    ]

    const testimonials = [
      {
        name: "Sarah Johnson",
        role: "CEO, TechStart",
        content:
          "Ahmad delivered exceptional work on our web platform. His attention to security and user experience is outstanding.",
        rating: 5,
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
      },
      {
        name: "Michael Chen",
        role: "CTO, InnovateCorp",
        content:
          "The cybersecurity solutions Ahmad implemented saved our company from potential threats. Highly recommended!",
        rating: 5,
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
      },
      {
        name: "Emily Rodriguez",
        role: "Founder, DigitalFlow",
        content:
          "Working with Ahmad was a game-changer. His innovative approach and technical expertise exceeded our expectations.",
        rating: 5,
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
      },
    ]

    const featuredProjects = [
      {
        title: "E-Commerce Platform",
        description: "Full-stack e-commerce solution with advanced security",
        image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop",
        tech: ["React", "Node.js", "MongoDB"],
        gradient: "from-blue-500 to-cyan-500",
      },
      {
        title: "Cybersecurity Dashboard",
        description: "Real-time threat monitoring and analysis system",
        image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&h=400&fit=crop",
        tech: ["Python", "React", "AI/ML"],
        gradient: "from-emerald-500 to-teal-500",
      },
      {
        title: "Mobile Banking App",
        description: "Secure mobile banking with biometric authentication",
        image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=600&h=400&fit=crop",
        tech: ["React Native", "Node.js", "Blockchain"],
        gradient: "from-purple-500 to-pink-500",
      },
    ]

    const timeline = [
      { year: "2021", title: "Started Journey", description: "Began professional web development career" },
      { year: "2022", title: "First Major Project", description: "Delivered enterprise-level e-commerce platform" },
      { year: "2023", title: "Security Specialization", description: "Expanded into cybersecurity consulting" },
      { year: "2024", title: "AmeerDev Founded", description: "Established personal brand and consultancy" },
    ]

    const codeSnippets = [
      "const dream = await reality.create();",
      "function innovate() { return creativity + code; }",
      "const future = new Promise(resolve => resolve('AmeerDev'));",
      "class Developer extends Human { constructor() { super('Ahmad'); } }",
      "const security = encrypt(data, 'unbreakable');",
    ]

    // Enhanced Particle System
    useEffect(() => {
      if (typeof window === "undefined") return

      const initParticles = () => {
        const particleCount = isMobile ? 25 : 50
        const newParticles = Array.from({ length: particleCount }, (_, i) => ({
          id: i,
          x: Math.random() * window.innerWidth,
          y: Math.random() * window.innerHeight,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
        }))
        setParticles(newParticles)
      }

      const animateParticles = () => {
        setParticles((prev) =>
          prev.map((particle) => ({
            ...particle,
            x: (particle.x + particle.vx + window.innerWidth) % window.innerWidth,
            y: (particle.y + particle.vy + window.innerHeight) % window.innerHeight,
          })),
        )
      }

      initParticles()
      const interval = setInterval(animateParticles, 50)
      return () => clearInterval(interval)
    }, [isMobile])

    // Real-time Clock
    useEffect(() => {
      const timer = setInterval(() => setCurrentTime(new Date()), 1000)
      return () => clearInterval(timer)
    }, [])

    // AI Typing Animation
    useEffect(() => {
      let currentIndex = 0
      let charIndex = 0
      const typeText = () => {
        const currentSnippet = codeSnippets[currentIndex]
        if (charIndex < currentSnippet.length) {
          setTypedText(currentSnippet.slice(0, charIndex + 1))
          charIndex++
        } else {
          setTimeout(() => {
            currentIndex = (currentIndex + 1) % codeSnippets.length
            charIndex = 0
            setTypedText("")
          }, 2000)
        }
      }

      const interval = setInterval(typeText, 100)
      return () => clearInterval(interval)
    }, [])

    // Voice Commands
    useEffect(() => {
      if (typeof window === "undefined" || !("webkitSpeechRecognition" in window)) return

      const recognition = new (window as any).webkitSpeechRecognition()
      recognition.continuous = false
      recognition.interimResults = false
      recognition.lang = "en-US"

      recognition.onresult = (event: any) => {
        const command = event.results[0][0].transcript.toLowerCase()
        setVoiceCommand(command)

        if (command.includes("about")) setCurrentPage("about")
        else if (command.includes("services")) setCurrentPage("services")
        else if (command.includes("portfolio")) setCurrentPage("portfolio")
        else if (command.includes("blog")) setCurrentPage("blog")
        else if (command.includes("contact")) setCurrentPage("contact")
        else if (command.includes("home")) setCurrentPage("home")

        setTimeout(() => setVoiceCommand(""), 3000)
      }

      recognition.onend = () => setIsListening(false)

      if (isListening) {
        recognition.start()
      }
    }, [isListening])

    // Skill Rotation
    useEffect(() => {
      const interval = setInterval(() => {
        setCurrentSkill((prev) => (prev + 1) % skills.length)
      }, 3000)
      return () => clearInterval(interval)
    }, [])

    // Testimonial Rotation
    useEffect(() => {
      const interval = setInterval(() => {
        setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
      }, 5000)
      return () => clearInterval(interval)
    }, [])

    // Project Carousel
    useEffect(() => {
      const interval = setInterval(() => {
        setCurrentProject((prev) => (prev + 1) % featuredProjects.length)
      }, 4000)
      return () => clearInterval(interval)
    }, [])

    // Live Stats Animation
    useEffect(() => {
      const interval = setInterval(() => {
        setLiveStats((prev) => ({
          visitors: prev.visitors + Math.floor(Math.random() * 3),
          projects: prev.projects + (Math.random() > 0.95 ? 1 : 0),
          clients: prev.clients + (Math.random() > 0.98 ? 1 : 0),
        }))
      }, 5000)
      return () => clearInterval(interval)
    }, [])

    // Timeline Animation
    useEffect(() => {
      const interval = setInterval(() => {
        setTimelineStep((prev) => (prev + 1) % timeline.length)
      }, 3000)
      return () => clearInterval(interval)
    }, [])

    // Weather Simulation
    useEffect(() => {
      const interval = setInterval(() => {
        setWeatherData((prev) => ({
          ...prev,
          temp: 20 + Math.floor(Math.random() * 15),
          humidity: 50 + Math.floor(Math.random() * 30),
        }))
      }, 30000)
      return () => clearInterval(interval)
    }, [])

    // GitHub Activity Simulation
    useEffect(() => {
      const interval = setInterval(() => {
        setGithubActivity((prev) => ({
          commits: prev.commits + Math.floor(Math.random() * 3),
          repos: prev.repos + (Math.random() > 0.95 ? 1 : 0),
          contributions: prev.contributions + Math.floor(Math.random() * 5),
        }))
      }, 10000)
      return () => clearInterval(interval)
    }, [])

    // Code Metrics Animation
    useEffect(() => {
      const interval = setInterval(() => {
        setCodeMetrics((prev) => ({
          linesWritten: prev.linesWritten + Math.floor(Math.random() * 10),
          bugsFixed: prev.bugsFixed + (Math.random() > 0.9 ? 1 : 0),
          projectsDeployed: prev.projectsDeployed + (Math.random() > 0.98 ? 1 : 0),
        }))
      }, 8000)
      return () => clearInterval(interval)
    }, [])

    // Interactive Code Editor
    useEffect(() => {
      const codeExamples = [
        {
          code: "const fibonacci = n => n <= 1 ? n : fibonacci(n-1) + fibonacci(n-2);",
          output: "Fibonacci sequence generator",
        },
        {
          code: "const isPrime = n => n > 1 && ![...Array(Math.sqrt(n))].some((_, i) => n % (i + 2) === 0);",
          output: "Prime number checker",
        },
        {
          code: "const quickSort = arr => arr.length <= 1 ? arr : [...quickSort(arr.slice(1).filter(x => x <= arr[0])), arr[0], ...quickSort(arr.slice(1).filter(x => x > arr[0]))];",
          output: "Quick sort algorithm",
        },
      ]

      const interval = setInterval(() => {
        const nextSnippet = (currentCodeSnippet + 1) % codeExamples.length
        setCurrentCodeSnippet(nextSnippet)
        setInteractiveCode(codeExamples[nextSnippet].code)
        setCodeOutput(codeExamples[nextSnippet].output)
      }, 6000)
      return () => clearInterval(interval)
    }, [currentCodeSnippet])

    return (
      <div className="min-h-screen relative overflow-hidden">
        {/* Enhanced Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-50 via-blue-50 to-emerald-50">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,0.1),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(16,185,129,0.1),transparent_50%)]" />

          {/* Interactive Particle System */}
          <svg className="absolute inset-0 w-full h-full">
            {particles.map((particle, index) => (
              <g key={particle.id}>
                <circle cx={particle.x} cy={particle.y} r="1.5" fill="url(#particleGradient)" opacity="0.4">
                  <animate attributeName="r" values="1;2.5;1" dur="4s" repeatCount="indefinite" />
                </circle>
                {!isMobile &&
                  particles.slice(index + 1).map((otherParticle) => {
                    const distance = Math.sqrt(
                      Math.pow(particle.x - otherParticle.x, 2) + Math.pow(particle.y - otherParticle.y, 2),
                    )
                    return distance < 80 ? (
                      <line
                        key={`${particle.id}-${otherParticle.id}`}
                        x1={particle.x}
                        y1={particle.y}
                        x2={otherParticle.x}
                        y2={otherParticle.y}
                        stroke="url(#lineGradient)"
                        strokeWidth="0.5"
                        opacity={0.2 - distance / 400}
                      />
                    ) : null
                  })}
              </g>
            ))}
            <defs>
              <linearGradient id="particleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3b82f6" />
                <stop offset="100%" stopColor="#10b981" />
              </linearGradient>
              <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3b82f6" />
                <stop offset="100%" stopColor="#10b981" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* Enhanced Floating Elements */}
        <FloatingElement delay={1}>
          <div className="top-20 left-10 w-16 h-16 md:w-20 md:h-20 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full opacity-15 blur-xl" />
        </FloatingElement>
        <FloatingElement delay={1.5}>
          <div
            className="top-40 right-20 w-24 h-24 md:w-32 md:h-32 bg-gradient-to-r from-emerald-400 to-emerald-600 transform rotate-12 opacity-15 blur-xl"
            style={{ clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)" }}
          />
        </FloatingElement>

        {/* Feature 1: Live Statistics Dashboard */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-20 right-4 md:right-6 bg-white/10 backdrop-blur-md rounded-2xl p-3 md:p-4 border border-white/20 z-30"
        >
          <div className="text-xs md:text-sm text-slate-600 space-y-2">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-xs">Live Stats</span>
            </div>
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-xs">Visitors:</span>
                <span className="font-mono text-xs">{liveStats.visitors}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-xs">Projects:</span>
                <span className="font-mono text-xs">{liveStats.projects}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-xs">Clients:</span>
                <span className="font-mono text-xs">{liveStats.clients}</span>
              </div>
            </div>
            <div className="font-mono text-xs">{currentTime.toLocaleTimeString()}</div>
          </div>
        </motion.div>

        {/* Feature 2: AI Code Terminal */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          className="absolute bottom-20 left-4 md:left-6 bg-slate-900/90 backdrop-blur-md rounded-2xl p-3 md:p-4 border border-slate-700 max-w-xs md:max-w-md z-30"
        >
          <div className="flex items-center space-x-2 mb-2">
            <div className="w-2 h-2 md:w-3 md:h-3 bg-red-500 rounded-full" />
            <div className="w-2 h-2 md:w-3 md:h-3 bg-yellow-500 rounded-full" />
            <div className="w-2 h-2 md:w-3 md:h-3 bg-green-500 rounded-full" />
            <span className="text-slate-400 text-xs ml-2">AI Terminal</span>
          </div>
          <div className="font-mono text-xs md:text-sm">
            <span className="text-green-400">$ </span>
            <span className="text-white">{typedText}</span>
            <span className="animate-pulse text-green-400">|</span>
          </div>
        </motion.div>

        {/* Feature 3: Voice Command Interface */}
        {!isMobile && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute top-1/2 right-4 md:right-6 transform -translate-y-1/2 z-30"
          >
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsListening(!isListening)}
              className={`p-3 md:p-4 rounded-full backdrop-blur-md border transition-all duration-300 ${
                isListening
                  ? "bg-red-500/20 border-red-500/50 text-red-600"
                  : "bg-white/10 border-white/20 text-slate-600"
              }`}
            >
              <motion.div
                animate={isListening ? { scale: [1, 1.2, 1] } : {}}
                transition={{ duration: 1, repeat: isListening ? Number.POSITIVE_INFINITY : 0 }}
                className="text-lg md:text-xl"
              >
                🎤
              </motion.div>
            </motion.button>
            {voiceCommand && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute top-full mt-2 right-0 bg-white/90 backdrop-blur-md rounded-lg p-2 text-sm text-slate-700 whitespace-nowrap"
              >
                "{voiceCommand}"
              </motion.div>
            )}
          </motion.div>
        )}

        {/* Feature 4: Dynamic Skill Visualization */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          className="absolute bottom-20 right-4 md:right-6 bg-white/10 backdrop-blur-md rounded-2xl p-4 md:p-6 border border-white/20 z-30"
        >
          <div className="text-center">
            <div className="relative w-16 h-16 md:w-24 md:h-24 mx-auto mb-4">
              <svg className="w-16 h-16 md:w-24 md:h-24 transform -rotate-90">
                <circle
                  cx="32"
                  cy="32"
                  r="28"
                  stroke="rgba(255,255,255,0.2)"
                  strokeWidth="4"
                  fill="none"
                  className="md:hidden"
                />
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="rgba(255,255,255,0.2)"
                  strokeWidth="8"
                  fill="none"
                  className="hidden md:block"
                />
                <motion.circle
                  cx={isMobile ? "32" : "48"}
                  cy={isMobile ? "32" : "48"}
                  r={isMobile ? "28" : "40"}
                  stroke="url(#skillGradient)"
                  strokeWidth={isMobile ? "4" : "8"}
                  fill="none"
                  strokeLinecap="round"
                  initial={{ strokeDasharray: isMobile ? "0 175.9" : "0 251.2" }}
                  animate={{
                    strokeDasharray: isMobile
                      ? `${(skills[currentSkill].level / 100) * 175.9} 175.9`
                      : `${(skills[currentSkill].level / 100) * 251.2} 251.2`,
                  }}
                  transition={{ duration: 1, ease: "easeInOut" }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-lg md:text-2xl font-bold text-slate-700">{skills[currentSkill].level}%</span>
              </div>
            </div>
            <motion.h3
              key={currentSkill}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-xs md:text-sm font-semibold text-slate-700"
            >
              {skills[currentSkill].name}
            </motion.h3>
          </div>
          <svg className="absolute inset-0 w-full h-full">
            <defs>
              <linearGradient id="skillGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3b82f6" />
                <stop offset="100%" stopColor="#10b981" />
              </linearGradient>
            </defs>
          </svg>
        </motion.div>

        {/* Feature 5: Interactive Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-white/10 backdrop-blur-md rounded-2xl p-3 md:p-4 border border-white/20 z-30 max-w-xs md:max-w-sm"
        >
          <div className="text-center">
            <div className="text-xs md:text-sm text-slate-600 mb-2">Journey Timeline</div>
            <motion.div
              key={timelineStep}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-1"
            >
              <div className="text-lg md:text-xl font-bold text-slate-800">{timeline[timelineStep].year}</div>
              <div className="text-xs md:text-sm font-semibold text-slate-700">{timeline[timelineStep].title}</div>
              <div className="text-xs text-slate-600">{timeline[timelineStep].description}</div>
            </motion.div>
            <div className="flex justify-center mt-2 space-x-1">
              {timeline.map((_, index) => (
                <div
                  key={index}
                  className={`w-1.5 h-1.5 md:w-2 md:h-2 rounded-full transition-all duration-300 ${
                    index === timelineStep ? "bg-blue-500" : "bg-slate-300"
                  }`}
                />
              ))}
            </div>
          </div>
        </motion.div>

        {/* Feature 6: Live Weather & Environment */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute top-32 left-4 md:left-6 bg-white/10 backdrop-blur-md rounded-2xl p-3 md:p-4 border border-white/20 z-30"
        >
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <Thermometer className="h-4 w-4 text-orange-500" />
              <span className="text-xs md:text-sm font-semibold text-slate-700">Live Environment</span>
            </div>
            <div className="space-y-1">
              <div className="text-lg md:text-xl font-bold text-slate-800">{weatherData.temp}°C</div>
              <div className="text-xs text-slate-600">{weatherData.condition}</div>
              <div className="flex items-center justify-center space-x-1">
                <Wind className="h-3 w-3 text-blue-500" />
                <span className="text-xs text-slate-600">{weatherData.humidity}%</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Feature 7: GitHub Activity Dashboard */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-1/2 left-4 md:left-6 transform -translate-y-1/2 bg-slate-900/90 backdrop-blur-md rounded-2xl p-3 md:p-4 border border-slate-700 z-30"
        >
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-3">
              <GitBranch className="h-4 w-4 text-green-400" />
              <span className="text-xs text-slate-400">GitHub Activity</span>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-300">Commits:</span>
                <span className="text-xs font-mono text-green-400">{githubActivity.commits}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-300">Repos:</span>
                <span className="text-xs font-mono text-blue-400">{githubActivity.repos}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-300">Contributions:</span>
                <span className="text-xs font-mono text-purple-400">{githubActivity.contributions}</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Feature 8: Interactive Code Editor */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          className="absolute bottom-32 right-4 md:right-6 bg-slate-900/95 backdrop-blur-md rounded-2xl p-3 md:p-4 border border-slate-700 max-w-xs md:max-w-sm z-30"
        >
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Terminal className="h-4 w-4 text-green-400" />
                <span className="text-xs text-slate-400">Code Editor</span>
              </div>
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              </div>
            </div>
            <div className="bg-slate-800 rounded-lg p-2">
              <div className="font-mono text-xs text-slate-300 mb-2">
                <span className="text-purple-400">const</span> <span className="text-blue-400">result</span>{" "}
                <span className="text-white">=</span>
              </div>
              <div className="font-mono text-xs text-green-400 leading-relaxed">{interactiveCode.slice(0, 40)}...</div>
            </div>
            <div className="text-xs text-slate-400">
              Output: <span className="text-green-400">{codeOutput}</span>
            </div>
          </div>
        </motion.div>

        {/* Feature 9: Code Metrics Dashboard */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute top-40 right-20 md:right-32 bg-white/10 backdrop-blur-md rounded-2xl p-3 md:p-4 border border-white/20 z-30"
        >
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-3">
              <Activity className="h-4 w-4 text-blue-500" />
              <span className="text-xs font-semibold text-slate-700">Code Metrics</span>
            </div>
            <div className="space-y-2">
              <div className="text-center">
                <div className="text-sm md:text-base font-bold text-slate-800">
                  {codeMetrics.linesWritten.toLocaleString()}
                </div>
                <div className="text-xs text-slate-600">Lines Written</div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="text-center">
                  <div className="font-semibold text-green-600">{codeMetrics.bugsFixed}</div>
                  <div className="text-slate-600">Bugs Fixed</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold text-purple-600">{codeMetrics.projectsDeployed}</div>
                  <div className="text-slate-600">Deployed</div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Feature 10: Technology Trends Tracker */}
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-32 right-4 md:right-6 bg-white/10 backdrop-blur-md rounded-2xl p-3 md:p-4 border border-white/20 z-30 max-w-xs"
        >
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-3">
              <TrendingUp className="h-4 w-4 text-green-500" />
              <span className="text-xs font-semibold text-slate-700">Tech Trends</span>
            </div>
            <div className="space-y-2">
              {techTrends.map((tech, index) => (
                <div key={tech.name} className="flex items-center justify-between">
                  <span className="text-xs text-slate-700">{tech.name}</span>
                  <div className="flex items-center space-x-1">
                    <span className="text-xs text-green-600 font-semibold">{tech.trend}</span>
                    <div className="w-8 h-1 bg-slate-200 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-gradient-to-r from-green-500 to-blue-500"
                        initial={{ width: 0 }}
                        animate={{ width: `${tech.popularity}%` }}
                        transition={{ duration: 1, delay: index * 0.2 }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Main Content */}
        <div className="relative z-10 px-4 md:px-6">
          {/* Hero Section */}
          <div className="flex flex-col items-center justify-center min-h-screen text-center">
            {/* Professional Logo */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="mb-6 md:mb-8 relative"
            >
              <motion.div
                animate={{
                  y: [0, -5, 0],
                }}
                transition={{
                  duration: 4,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "easeInOut",
                }}
                className="relative z-10 p-4 md:p-8 bg-gradient-to-br from-white/30 to-white/10 backdrop-blur-xl rounded-3xl border border-white/30 shadow-2xl"
              >
                <Image
                  src="/logo.png"
                  alt="AmeerDev Logo"
                  width={isMobile ? 200 : 300}
                  height={isMobile ? 133 : 200}
                  className="mx-auto drop-shadow-2xl"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600/5 to-emerald-600/5 rounded-3xl" />
              </motion.div>
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-emerald-500/20 rounded-full blur-3xl transform scale-110" />
            </motion.div>

            <AnimatedText delay={0.3}>
              <h1 className="text-4xl md:text-6xl lg:text-8xl font-bold bg-gradient-to-r from-slate-800 via-blue-600 to-emerald-600 bg-clip-text text-transparent mb-4 md:mb-6 relative">
                AmeerDev
                <motion.div
                  className="absolute -top-2 -right-2 md:-top-4 md:-right-4 w-6 h-6 md:w-8 md:h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center text-xs md:text-base"
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                  }}
                >
                  ✨
                </motion.div>
              </h1>
            </AnimatedText>

            <AnimatedText delay={0.5}>
              <p className="text-lg md:text-2xl lg:text-3xl text-slate-600 mb-3 md:mb-4 font-light">
                Code. Create. Innovate.
              </p>
            </AnimatedText>

            <AnimatedText delay={0.7}>
              <div className="text-base md:text-lg lg:text-xl text-slate-500 mb-6 md:mb-8 max-w-2xl leading-relaxed px-4">
                <motion.span
                  animate={{
                    opacity: [0.7, 1, 0.7],
                    backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
                  }}
                  transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                  className="inline-block bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent bg-[length:200%_100%]"
                >
                  Where dreams meet reality through elegant code
                </motion.span>
              </div>
            </AnimatedText>

            <AnimatedText delay={0.9}>
              <div className="flex flex-col sm:flex-row gap-3 md:gap-4 mb-12 md:mb-16">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    onClick={() => setCurrentPage("about")}
                    className="bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 text-white px-6 md:px-8 py-3 md:py-4 rounded-full text-base md:text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    Begin the Journey
                    <ArrowRight className="ml-2 h-4 w-4 md:h-5 md:w-5" />
                  </Button>
                </motion.div>

                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    onClick={() => setCurrentPage("services")}
                    variant="outline"
                    className="border-2 border-slate-300 hover:border-blue-500 text-slate-700 hover:text-blue-600 px-6 md:px-8 py-3 md:py-4 rounded-full text-base md:text-lg font-medium backdrop-blur-sm bg-white/50 hover:bg-white/70 transition-all duration-300"
                  >
                    Explore Services
                    <Sparkles className="ml-2 h-4 w-4 md:h-5 md:w-5" />
                  </Button>
                </motion.div>
              </div>
            </AnimatedText>
          </div>

          {/* Tech Stack Section */}
          <motion.section
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="py-12 md:py-20"
          >
            <div className="max-w-6xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-slate-800 to-blue-600 bg-clip-text text-transparent mb-8 md:mb-12">
                Technology Stack
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4 md:gap-6">
                {techStack.map((tech, index) => (
                  <motion.div
                    key={tech.name}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    whileHover={{ scale: 1.1, y: -10 }}
                    className={`p-4 md:p-6 bg-gradient-to-br ${tech.color} rounded-2xl text-white shadow-lg hover:shadow-xl transition-all duration-300`}
                  >
                    <div className="text-2xl md:text-3xl mb-2">{tech.icon}</div>
                    <div className="font-semibold text-xs md:text-sm">{tech.name}</div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.section>

          {/* Achievements Section */}
          <motion.section
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="py-12 md:py-20"
          >
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent mb-8 md:mb-12">
                Achievements & Milestones
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
                {achievements.map((achievement, index) => (
                  <motion.div
                    key={achievement.label}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                    className="text-center p-4 md:p-8 bg-white/60 backdrop-blur-sm rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 border border-white/20"
                  >
                    <div className="text-3xl md:text-4xl mb-2 md:mb-4">{achievement.icon}</div>
                    <div className="text-2xl md:text-3xl font-bold text-slate-800 mb-1 md:mb-2">
                      {achievement.number}
                    </div>
                    <div className="text-slate-600 font-medium text-xs md:text-sm">{achievement.label}</div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.section>

          {/* Featured Projects Carousel */}
          <motion.section
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="py-12 md:py-20"
          >
            <div className="max-w-6xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-8 md:mb-12">
                Featured Projects
              </h2>
              <div className="relative">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentProject}
                    initial={{ opacity: 0, x: 100 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                    transition={{ duration: 0.5 }}
                    className="bg-white/70 backdrop-blur-sm rounded-3xl overflow-hidden shadow-lg border border-white/20 max-w-2xl mx-auto"
                  >
                    <div className="relative overflow-hidden">
                      <Image
                        src={featuredProjects[currentProject].image || "/placeholder.svg"}
                        alt={featuredProjects[currentProject].title}
                        width={600}
                        height={400}
                        className="w-full h-48 md:h-64 object-cover"
                      />
                      <div
                        className={`absolute inset-0 bg-gradient-to-r ${featuredProjects[currentProject].gradient} opacity-20`}
                      />
                    </div>
                    <div className="p-6 md:p-8">
                      <h3 className="text-xl md:text-2xl font-bold text-slate-800 mb-3 md:mb-4">
                        {featuredProjects[currentProject].title}
                      </h3>
                      <p className="text-slate-600 leading-relaxed mb-4">
                        {featuredProjects[currentProject].description}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {featuredProjects[currentProject].tech.map((tech) => (
                          <span
                            key={tech}
                            className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm font-medium"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                </AnimatePresence>

                <div className="flex justify-center mt-6 space-x-2">
                  {featuredProjects.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentProject(index)}
                      className={`w-3 h-3 rounded-full transition-all duration-300 ${
                        index === currentProject ? "bg-purple-500" : "bg-slate-300"
                      }`}
                    />
                  ))}
                </div>

                <button
                  onClick={() =>
                    setCurrentProject((prev) => (prev - 1 + featuredProjects.length) % featuredProjects.length)
                  }
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 p-2 bg-white/80 rounded-full shadow-lg hover:bg-white transition-all duration-300"
                >
                  <ChevronLeft className="h-5 w-5 text-slate-700" />
                </button>

                <button
                  onClick={() => setCurrentProject((prev) => (prev + 1) % featuredProjects.length)}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 p-2 bg-white/80 rounded-full shadow-lg hover:bg-white transition-all duration-300"
                >
                  <ChevronRight className="h-5 w-5 text-slate-700" />
                </button>
              </div>
            </div>
          </motion.section>

          {/* Testimonials Section */}
          <motion.section
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="py-12 md:py-20"
          >
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent mb-8 md:mb-12">
                Client Testimonials
              </h2>
              <div className="relative">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentTestimonial}
                    initial={{ opacity: 0, x: 100 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                    transition={{ duration: 0.5 }}
                    className="bg-white/70 backdrop-blur-sm rounded-3xl p-6 md:p-8 shadow-lg border border-white/20"
                  >
                    <div className="flex items-center justify-center mb-4 md:mb-6">
                      {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 md:h-6 md:w-6 text-yellow-500 fill-current" />
                      ))}
                    </div>
                    <p className="text-base md:text-lg text-slate-700 mb-4 md:mb-6 italic">
                      "{testimonials[currentTestimonial].content}"
                    </p>
                    <div className="flex items-center justify-center space-x-4">
                      <Image
                        src={testimonials[currentTestimonial].avatar || "/placeholder.svg"}
                        alt={testimonials[currentTestimonial].name}
                        width={60}
                        height={60}
                        className="rounded-full"
                      />
                      <div>
                        <div className="font-semibold text-slate-800">{testimonials[currentTestimonial].name}</div>
                        <div className="text-slate-600 text-sm">{testimonials[currentTestimonial].role}</div>
                      </div>
                    </div>
                  </motion.div>
                </AnimatePresence>
                <div className="flex justify-center mt-6 space-x-2">
                  {testimonials.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentTestimonial(index)}
                      className={`w-3 h-3 rounded-full transition-all duration-300 ${
                        index === currentTestimonial ? "bg-orange-500" : "bg-slate-300"
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </motion.section>

          {/* Quick Contact Form */}
          <motion.section
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="py-12 md:py-20"
          >
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-slate-800 to-emerald-600 bg-clip-text text-transparent mb-8 md:mb-12">
                Quick Contact
              </h2>
              <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-6 md:p-8 shadow-lg border border-white/20">
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input placeholder="Your Name" className="bg-white/50 border-white/30" />
                    <Input placeholder="Your Email" className="bg-white/50 border-white/30" />
                  </div>
                  <Textarea placeholder="Your Message" className="bg-white/50 border-white/30" rows={4} />
                  <Button
                    onClick={() => setCurrentPage("contact")}
                    className="w-full bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 text-white py-3 rounded-full font-medium shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    Send Message
                    <Send className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </motion.section>

          {/* Call to Action */}
          <motion.section
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="py-12 md:py-20"
          >
            <div className="max-w-4xl mx-auto text-center">
              <div className="bg-gradient-to-r from-blue-600 to-emerald-600 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden">
                <div
                  className="absolute inset-0 opacity-20"
                  style={{
                    backgroundImage:
                      "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Ccircle cx='30' cy='30' r='2' fill='%23ffffff' fillOpacity='0.1'/%3E%3C/svg%3E\")",
                  }}
                />
                <div className="relative z-10">
                  <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Start Your Project?</h2>
                  <p className="text-lg md:text-xl mb-6 md:mb-8 opacity-90">
                    Let's transform your ideas into powerful digital solutions
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button
                      onClick={() => setCurrentPage("contact")}
                      className="bg-white text-blue-600 hover:bg-gray-100 px-6 md:px-8 py-3 md:py-4 rounded-full text-base md:text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300"
                    >
                      Get In Touch
                      <ArrowRight className="ml-2 h-4 w-4 md:h-5 md:w-5" />
                    </Button>
                    <Button
                      onClick={() => setCurrentPage("portfolio")}
                      variant="outline"
                      className="border-2 border-white text-white hover:bg-white hover:text-blue-600 px-6 md:px-8 py-3 md:py-4 rounded-full text-base md:text-lg font-medium transition-all duration-300"
                    >
                      View Portfolio
                      <FolderOpen className="ml-2 h-4 w-4 md:h-5 md:w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </motion.section>

          {/* Professional Certifications Section */}
          <motion.section
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="py-12 md:py-20"
          >
            <div className="max-w-6xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent mb-8 md:mb-12">
                Professional Certifications
              </h2>
              <div className="grid md:grid-cols-3 gap-6 md:gap-8">
                {certifications.map((cert, index) => (
                  <motion.div
                    key={cert.name}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    whileHover={{ scale: 1.05, y: -5 }}
                    className="bg-white/70 backdrop-blur-sm rounded-3xl p-6 md:p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-white/20"
                  >
                    <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                      <Award className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-slate-800 mb-2">{cert.name}</h3>
                    <p className="text-slate-600 mb-2">{cert.level}</p>
                    <p className="text-sm text-slate-500">{cert.year}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.section>

          {/* Global Client Map Section */}
          <motion.section
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="py-12 md:py-20"
          >
            <div className="max-w-6xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent mb-8 md:mb-12">
                Global Client Network
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                {clientLocations.map((location, index) => (
                  <motion.div
                    key={location.country}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                    className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 md:p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-white/20"
                  >
                    <div className="text-3xl md:text-4xl mb-2">{location.flag}</div>
                    <h3 className="font-bold text-slate-800 mb-1">{location.country}</h3>
                    <p className="text-2xl font-bold text-green-600">{location.clients}</p>
                    <p className="text-xs text-slate-600">Active Clients</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.section>

          {/* Development Process Section */}
          <motion.section
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="py-12 md:py-20"
          >
            <div className="max-w-6xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent mb-8 md:mb-12">
                Development Process
              </h2>
              <div className="grid md:grid-cols-4 gap-6 md:gap-8">
                {[
                  {
                    step: "01",
                    title: "Discovery",
                    description: "Understanding your vision and requirements",
                    icon: Eye,
                    color: "from-blue-500 to-cyan-500",
                  },
                  {
                    step: "02",
                    title: "Design",
                    description: "Creating beautiful and functional designs",
                    icon: Layers,
                    color: "from-purple-500 to-pink-500",
                  },
                  {
                    step: "03",
                    title: "Development",
                    description: "Building with cutting-edge technologies",
                    icon: Settings,
                    color: "from-green-500 to-emerald-500",
                  },
                  {
                    step: "04",
                    title: "Deployment",
                    description: "Launching your project to the world",
                    icon: Zap,
                    color: "from-orange-500 to-red-500",
                  },
                ].map((process, index) => (
                  <motion.div
                    key={process.step}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    className="relative"
                  >
                    <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-6 md:p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-white/20 h-full">
                      <div
                        className={`w-12 h-12 mx-auto mb-4 bg-gradient-to-r ${process.color} rounded-full flex items-center justify-center`}
                      >
                        <process.icon className="h-6 w-6 text-white" />
                      </div>
                      <div className="text-sm font-bold text-slate-500 mb-2">{process.step}</div>
                      <h3 className="text-xl font-bold text-slate-800 mb-3">{process.title}</h3>
                      <p className="text-slate-600 text-sm leading-relaxed">{process.description}</p>
                    </div>
                    {index < 3 && (
                      <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                        <ArrowRight className="h-6 w-6 text-slate-400" />
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.section>

          {/* Performance Metrics Section */}
          <motion.section
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="py-12 md:py-20"
          >
            <div className="max-w-6xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent mb-8 md:mb-12">
                Performance Metrics
              </h2>
              <div className="grid md:grid-cols-3 gap-6 md:gap-8">
                {[
                  {
                    metric: "99.9%",
                    label: "Uptime Guarantee",
                    icon: Monitor,
                    description: "Reliable hosting and monitoring",
                  },
                  { metric: "<2s", label: "Load Time", icon: Zap, description: "Lightning-fast performance" },
                  { metric: "A+", label: "Security Grade", icon: Shield, description: "Enterprise-level security" },
                ].map((metric, index) => (
                  <motion.div
                    key={metric.label}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                    className="bg-gradient-to-br from-white/80 to-white/60 backdrop-blur-sm rounded-3xl p-6 md:p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-white/20"
                  >
                    <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center">
                      <metric.icon className="h-8 w-8 text-white" />
                    </div>
                    <div className="text-3xl md:text-4xl font-bold text-slate-800 mb-2">{metric.metric}</div>
                    <h3 className="text-xl font-semibold text-slate-700 mb-2">{metric.label}</h3>
                    <p className="text-slate-600 text-sm">{metric.description}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.section>
        </div>
      </div>
    )
  }

  const AboutPage = () => (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-50 via-blue-50 to-purple-50">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_70%,rgba(16,185,129,0.1),transparent_50%)]" />
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 md:px-6">
        <div className="max-w-4xl mx-auto text-center">
          <AnimatedText>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent mb-8">
              About the Vision
            </h2>
          </AnimatedText>

          <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.3 }}
              className="relative"
            >
              {/* Enhanced Profile Image Design */}
              <div className="relative w-64 h-64 md:w-80 md:h-80 mx-auto">
                {/* Outer decorative ring */}
                <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-500 to-emerald-500 p-1">
                  <div className="w-full h-full rounded-full bg-white p-2">
                    {/* Inner decorative ring */}
                    <div className="w-full h-full rounded-full bg-gradient-to-br from-slate-100 to-white p-3 shadow-inner">
                      <Image
                        src="/profile.jpg"
                        alt="Ahmad Musa Waziri"
                        width={320}
                        height={320}
                        className="w-full h-full rounded-full object-cover shadow-2xl"
                      />
                    </div>
                  </div>
                </div>

                {/* Floating decorative elements */}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                  className="absolute inset-0"
                >
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full shadow-lg flex items-center justify-center">
                    <Code className="h-4 w-4 text-white" />
                  </div>
                  <div className="absolute top-1/2 -right-4 transform -translate-y-1/2 w-8 h-8 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full shadow-lg flex items-center justify-center">
                    <Shield className="h-4 w-4 text-white" />
                  </div>
                  <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full shadow-lg flex items-center justify-center">
                    <Sparkles className="h-4 w-4 text-white" />
                  </div>
                  <div className="absolute top-1/2 -left-4 transform -translate-y-1/2 w-8 h-8 bg-gradient-to-r from-orange-500 to-red-500 rounded-full shadow-lg flex items-center justify-center">
                    <Award className="h-4 w-4 text-white" />
                  </div>
                </motion.div>

                {/* Glowing background effect */}
                <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-600/20 to-emerald-600/20 blur-2xl transform scale-110" />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="text-left"
            >
              <motion.h3
                animate={{
                  backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
                }}
                transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-slate-800 via-blue-600 to-emerald-600 bg-clip-text text-transparent mb-4 bg-[length:200%_100%]"
              >
                Ahmad Musa Waziri
              </motion.h3>

              <motion.p
                animate={{ opacity: [0.7, 1, 0.7] }}
                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                className="text-lg md:text-xl text-slate-600 mb-6"
              >
                Professional Web Developer & Cyber Security Expert
              </motion.p>

              <div className="space-y-4 text-slate-600">
                <p className="leading-relaxed">
                  In the realm where technology meets artistry, I craft digital experiences that transcend the ordinary.
                  Every line of code is a brushstroke, every function a verse in the poetry of innovation.
                </p>
                <p className="leading-relaxed">
                  With expertise spanning web development and cybersecurity, I build bridges between what is and what
                  could be, creating secure, beautiful, and purposeful digital solutions.
                </p>
                <p className="leading-relaxed">
                  My journey is driven by a passion for excellence, a commitment to security, and an unwavering
                  dedication to transforming complex challenges into elegant solutions.
                </p>
              </div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="mt-6 space-y-3"
              >
                <div className="flex items-center space-x-3 text-slate-600">
                  <div className="p-2 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-lg">
                    <Phone className="h-4 w-4 text-white" />
                  </div>
                  <span className="font-medium">09014480971</span>
                </div>
                <div className="flex items-center space-x-3 text-slate-600">
                  <div className="p-2 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-lg">
                    <Mail className="h-4 w-4 text-white" />
                  </div>
                  <span className="font-medium">ahmad@ameerdev.com</span>
                </div>
                <div className="flex items-center space-x-3 text-slate-600">
                  <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg">
                    <MapPin className="h-4 w-4 text-white" />
                  </div>
                  <span className="font-medium">Nigeria</span>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  )

  const ServicesPage = () => (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-50 via-blue-50 to-emerald-50">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(147,51,234,0.1),transparent_50%)]" />
      </div>

      <div className="relative z-10 py-16 md:py-20 px-4 md:px-6">
        <div className="max-w-6xl mx-auto">
          <AnimatedText>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-center bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-12 md:mb-16">
              Services & Expertise
            </h2>
          </AnimatedText>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {[
              {
                icon: Code,
                title: "Web Development",
                description: "Crafting responsive, modern web applications with cutting-edge technologies",
                image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=300&fit=crop",
                gradient: "from-blue-500 to-cyan-500",
              },
              {
                icon: Shield,
                title: "Cyber Security",
                description: "Protecting digital assets with comprehensive security solutions and best practices",
                image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=400&h=300&fit=crop",
                gradient: "from-emerald-500 to-teal-500",
              },
              {
                icon: Sparkles,
                title: "Innovation Consulting",
                description: "Transforming ideas into reality through strategic technology consulting",
                image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=400&h=300&fit=crop",
                gradient: "from-purple-500 to-pink-500",
              },
            ].map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="group"
              >
                <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-6 md:p-8 shadow-xl hover:shadow-2xl transition-all duration-500 border border-white/20 h-full">
                  <div className="relative mb-6 overflow-hidden rounded-2xl">
                    <Image
                      src={service.image || "/placeholder.svg"}
                      alt={service.title}
                      width={400}
                      height={300}
                      className="w-full h-40 md:h-48 object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div
                      className={`absolute inset-0 bg-gradient-to-r ${service.gradient} opacity-20 group-hover:opacity-30 transition-opacity duration-500`}
                    />
                  </div>

                  <div className={`inline-flex p-3 rounded-2xl bg-gradient-to-r ${service.gradient} mb-4`}>
                    <service.icon className="h-6 w-6 text-white" />
                  </div>

                  <h3 className="text-xl md:text-2xl font-bold text-slate-800 mb-4">{service.title}</h3>
                  <p className="text-slate-600 leading-relaxed">{service.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )

  // Update the PortfolioPage component to include project details functionality

  const PortfolioPage = () => (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_40%_60%,rgba(99,102,241,0.1),transparent_50%)]" />
      </div>

      <div className="relative z-10 py-16 md:py-20 px-4 md:px-6">
        <div className="max-w-6xl mx-auto">
          <AnimatedText>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-center bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent mb-12 md:mb-16">
              Portfolio Showcase
            </h2>
          </AnimatedText>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {[
              {
                id: 1,
                title: "E-Commerce Platform",
                description: "Full-stack e-commerce solution with advanced security features and payment integration",
                image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=500&h=400&fit=crop",
                tech: ["React", "Node.js", "MongoDB", "Stripe"],
                gradient: "from-blue-500 to-cyan-500",
                category: "Web Development",
              },
              {
                id: 2,
                title: "Cybersecurity Dashboard",
                description: "Real-time threat monitoring and analysis system with AI-powered detection",
                image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=500&h=400&fit=crop",
                tech: ["Python", "React", "TensorFlow", "Docker"],
                gradient: "from-emerald-500 to-teal-500",
                category: "Security",
              },
              {
                id: 3,
                title: "Mobile Banking App",
                description: "Secure mobile banking application with biometric authentication",
                image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=500&h=400&fit=crop",
                tech: ["React Native", "Node.js", "PostgreSQL"],
                gradient: "from-purple-500 to-pink-500",
                category: "Mobile",
              },
              {
                id: 4,
                title: "Healthcare Management System",
                description: "Comprehensive healthcare management platform with patient records and scheduling",
                image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=500&h=400&fit=crop",
                tech: ["Next.js", "Express", "MySQL", "AWS"],
                gradient: "from-green-500 to-emerald-500",
                category: "Healthcare",
              },
              {
                id: 5,
                title: "Real Estate Platform",
                description: "Modern real estate platform with virtual tours and property management",
                image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=500&h=400&fit=crop",
                tech: ["Vue.js", "Laravel", "Redis", "Cloudinary"],
                gradient: "from-orange-500 to-red-500",
                category: "Real Estate",
              },
              {
                id: 6,
                title: "Learning Management System",
                description: "Interactive learning platform with video streaming and progress tracking",
                image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=500&h=400&fit=crop",
                tech: ["Angular", "Django", "PostgreSQL", "WebRTC"],
                gradient: "from-indigo-500 to-purple-500",
                category: "Education",
              },
            ].map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="group cursor-pointer"
                onClick={() => fetchProjectDetails(project.id)}
              >
                <div className="bg-white/80 backdrop-blur-sm rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 border border-white/20 h-full">
                  <div className="relative overflow-hidden">
                    <Image
                      src={project.image || "/placeholder.svg"}
                      alt={project.title}
                      width={500}
                      height={400}
                      className="w-full h-48 md:h-56 object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div
                      className={`absolute inset-0 bg-gradient-to-r ${project.gradient} opacity-20 group-hover:opacity-30 transition-opacity duration-500`}
                    />
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-white/90 text-slate-700 rounded-full text-sm font-medium">
                        {project.category}
                      </span>
                    </div>
                    <div className="absolute bottom-4 right-4">
                      <div className="p-2 bg-white/90 rounded-full">
                        <Eye className="h-4 w-4 text-slate-700" />
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl md:text-2xl font-bold text-slate-800 mb-3 group-hover:text-indigo-600 transition-colors duration-300">
                      {project.title}
                    </h3>
                    <p className="text-slate-600 leading-relaxed mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {project.tech.map((tech) => (
                        <span
                          key={tech}
                          className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm font-medium"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Project Details Modal */}
      <AnimatePresence>
        {selectedProject && projectDetails && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setSelectedProject(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 50 }}
              className="bg-white rounded-3xl max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative">
                <Image
                  src={projectDetails.image || "/placeholder.svg"}
                  alt={projectDetails.title}
                  width={800}
                  height={400}
                  className="w-full h-64 md:h-80 object-cover"
                />
                <button
                  onClick={() => setSelectedProject(null)}
                  className="absolute top-4 right-4 p-2 bg-white/90 rounded-full hover:bg-white transition-colors duration-200"
                >
                  <X className="h-5 w-5 text-slate-700" />
                </button>
              </div>

              <div className="p-6 md:p-8">
                <div className="flex items-center justify-between mb-4">
                  <span className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium">
                    {projectDetails.category}
                  </span>
                  <span className="text-slate-500">{projectDetails.year}</span>
                </div>

                <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">{projectDetails.title}</h2>
                <p className="text-lg text-slate-600 leading-relaxed mb-6">{projectDetails.longDescription}</p>

                <div className="grid md:grid-cols-3 gap-6 mb-8">
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-2">Client</h4>
                    <p className="text-slate-600">{projectDetails.client}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-2">Duration</h4>
                    <p className="text-slate-600">{projectDetails.duration}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-2">Year</h4>
                    <p className="text-slate-600">{projectDetails.year}</p>
                  </div>
                </div>

                <div className="mb-8">
                  <h4 className="font-semibold text-slate-800 mb-3">Technologies Used</h4>
                  <div className="flex flex-wrap gap-2">
                    {projectDetails.tech.map((tech: string) => (
                      <span
                        key={tech}
                        className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm font-medium"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-8 mb-8">
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-3">Key Features</h4>
                    <ul className="space-y-2">
                      {projectDetails.features.map((feature: string, index: number) => (
                        <li key={index} className="flex items-start space-x-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0" />
                          <span className="text-slate-600">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-800 mb-3">Results Achieved</h4>
                    <ul className="space-y-2">
                      {projectDetails.results.map((result: string, index: number) => (
                        <li key={index} className="flex items-start space-x-2">
                          <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                          <span className="text-slate-600">{result}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {projectDetails.testimonial && (
                  <div className="bg-slate-50 rounded-2xl p-6">
                    <h4 className="font-semibold text-slate-800 mb-3">Client Testimonial</h4>
                    <blockquote className="text-slate-600 italic mb-4">"{projectDetails.testimonial.text}"</blockquote>
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-semibold text-sm">
                          {projectDetails.testimonial.author
                            .split(" ")
                            .map((n: string) => n[0])
                            .join("")}
                        </span>
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">{projectDetails.testimonial.author}</div>
                        <div className="text-sm text-slate-600">{projectDetails.testimonial.role}</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Loading Modal */}
      <AnimatePresence>
        {isLoadingProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center"
          >
            <div className="bg-white rounded-2xl p-8 flex items-center space-x-4">
              <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
              <span className="text-slate-700 font-medium">Loading project details...</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )

  const BlogPage = () => (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_60%_40%,rgba(20,184,166,0.1),transparent_50%)]" />
      </div>

      <div className="relative z-10 py-16 md:py-20 px-4 md:px-6">
        <div className="max-w-6xl mx-auto">
          <AnimatedText>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-center bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent mb-12 md:mb-16">
              Latest Insights
            </h2>
          </AnimatedText>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {[
              {
                title: "The Future of Web Development",
                excerpt:
                  "Exploring emerging technologies and trends that will shape the future of web development in 2024 and beyond.",
                image: "https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?w=500&h=300&fit=crop",
                date: "Dec 15, 2024",
                readTime: "5 min read",
                category: "Technology",
              },
              {
                title: "Cybersecurity Best Practices",
                excerpt:
                  "Essential security measures every developer should implement to protect applications and user data.",
                image: "https://images.unsplash.com/photo-1563206767-5b18f218e8de?w=500&h=300&fit=crop",
                date: "Dec 10, 2024",
                readTime: "7 min read",
                category: "Security",
              },
              {
                title: "Building Scalable Applications",
                excerpt:
                  "Strategies and architectural patterns for creating applications that can handle growth and scale efficiently.",
                image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=500&h=300&fit=crop",
                date: "Dec 5, 2024",
                readTime: "6 min read",
                category: "Architecture",
              },
              {
                title: "Modern JavaScript Frameworks",
                excerpt: "A comprehensive comparison of React, Vue, and Angular for modern web development projects.",
                image: "https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=500&h=300&fit=crop",
                date: "Nov 28, 2024",
                readTime: "8 min read",
                category: "JavaScript",
              },
              {
                title: "Cloud Computing Essentials",
                excerpt:
                  "Understanding cloud services and how to leverage them for better application deployment and scaling.",
                image: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=500&h=300&fit=crop",
                date: "Nov 20, 2024",
                readTime: "4 min read",
                category: "Cloud",
              },
              {
                title: "API Design Principles",
                excerpt:
                  "Best practices for designing RESTful APIs that are maintainable, scalable, and developer-friendly.",
                image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=500&h=300&fit=crop",
                date: "Nov 15, 2024",
                readTime: "6 min read",
                category: "API",
              },
            ].map((article, index) => (
              <motion.div
                key={article.title}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="group cursor-pointer"
              >
                <div className="bg-white/80 backdrop-blur-sm rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 border border-white/20 h-full">
                  <div className="relative overflow-hidden">
                    <Image
                      src={article.image || "/placeholder.svg"}
                      alt={article.title}
                      width={500}
                      height={300}
                      className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-white/90 text-slate-700 rounded-full text-sm font-medium">
                        {article.category}
                      </span>
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="flex items-center space-x-4 text-sm text-slate-500 mb-3">
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-4 w-4" />
                        <span>{article.date}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{article.readTime}</span>
                      </div>
                    </div>
                    <h3 className="text-xl md:text-2xl font-bold text-slate-800 mb-3 group-hover:text-teal-600 transition-colors duration-300">
                      {article.title}
                    </h3>
                    <p className="text-slate-600 leading-relaxed">{article.excerpt}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )

  const ContactPage = () => {
    const [formData, setFormData] = useState({
      name: "",
      email: "",
      phone: "",
      subject: "",
      message: "",
    })
    const [isSubmitting, setIsSubmitting] = useState(false)
    const [submitStatus, setSubmitStatus] = useState<{ type: "success" | "error"; message: string } | null>(null)

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      setFormData((prev) => ({
        ...prev,
        [e.target.name]: e.target.value,
      }))
    }

    const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault()
      setIsSubmitting(true)
      setSubmitStatus(null)

      try {
        const response = await fetch("/api/contact", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        })

        const data = await response.json()

        if (response.ok) {
          setSubmitStatus({ type: "success", message: data.message })
          setFormData({ name: "", email: "", phone: "", subject: "", message: "" })
        } else {
          setSubmitStatus({ type: "error", message: data.error || "Something went wrong" })
        }
      } catch (error) {
        setSubmitStatus({ type: "error", message: "Network error. Please try again." })
      } finally {
        setIsSubmitting(false)
      }
    }

    return (
      <div className="min-h-screen relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-50 via-emerald-50 to-blue-50">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,0.1),transparent_50%)]" />
        </div>

        <div className="relative z-10 py-16 md:py-20 px-4 md:px-6">
          <div className="max-w-6xl mx-auto">
            <AnimatedText>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-center bg-gradient-to-r from-slate-800 to-emerald-600 bg-clip-text text-transparent mb-8">
                Let's Create Together
              </h2>
            </AnimatedText>

            <AnimatedText delay={0.3}>
              <p className="text-lg md:text-xl text-slate-600 mb-12 max-w-2xl mx-auto leading-relaxed text-center">
                Ready to transform your vision into reality? Let's embark on a journey of innovation and excellence.
              </p>
            </AnimatedText>

            <div className="grid lg:grid-cols-2 gap-8 md:gap-12">
              {/* Contact Information */}
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 1, delay: 0.5 }}
                className="space-y-8"
              >
                <div className="relative">
                  <Image
                    src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=500&h=400&fit=crop"
                    alt="Contact"
                    width={500}
                    height={400}
                    className="rounded-3xl shadow-2xl w-full"
                  />
                  <div className="absolute inset-0 rounded-3xl bg-gradient-to-r from-blue-600/20 to-emerald-600/20" />
                </div>

                <div className="space-y-6">
                  {[
                    { icon: Phone, label: "Phone", value: "09014480971" },
                    { icon: Mail, label: "Email", value: "ahmad@ameerdev.com" },
                    { icon: MapPin, label: "Location", value: "Nigeria" },
                  ].map((contact, index) => (
                    <motion.div
                      key={contact.label}
                      whileHover={{ scale: 1.02, x: 10 }}
                      className="flex items-center space-x-4 p-4 md:p-6 bg-white/60 backdrop-blur-sm rounded-2xl shadow-lg"
                    >
                      <div className="p-3 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-xl">
                        <contact.icon className="h-5 w-5 md:h-6 md:w-6 text-white" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 font-medium">{contact.label}</p>
                        <p className="text-lg md:text-xl text-slate-800 font-semibold">{contact.value}</p>
                      </div>
                    </motion.div>
                  ))}

                  <div className="flex space-x-4 pt-4">
                    {[Github, Linkedin, Twitter].map((Icon, index) => (
                      <motion.button
                        key={index}
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        whileTap={{ scale: 0.9 }}
                        className="p-3 md:p-4 bg-gradient-to-r from-slate-600 to-slate-800 rounded-xl text-white hover:shadow-lg transition-all duration-300"
                      >
                        <Icon className="h-5 w-5 md:h-6 md:w-6" />
                      </motion.button>
                    ))}
                  </div>
                </div>
              </motion.div>

              {/* Contact Form */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 1, delay: 0.7 }}
                className="bg-white/70 backdrop-blur-sm rounded-3xl p-6 md:p-8 shadow-xl border border-white/20"
              >
                <h3 className="text-2xl md:text-3xl font-bold text-slate-800 mb-6">Send a Message</h3>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-2">
                        Full Name *
                      </label>
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Your full name"
                        className="bg-white/50 border-white/30 focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">
                        Email Address *
                      </label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="your.email@example.com"
                        className="bg-white/50 border-white/30 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-slate-700 mb-2">
                        Phone Number
                      </label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="+234 xxx xxx xxxx"
                        className="bg-white/50 border-white/30 focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium text-slate-700 mb-2">
                        Subject
                      </label>
                      <Input
                        id="subject"
                        name="subject"
                        type="text"
                        value={formData.subject}
                        onChange={handleInputChange}
                        placeholder="Project inquiry"
                        className="bg-white/50 border-white/30 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-2">
                      Message *
                    </label>
                    <Textarea
                      id="message"
                      name="message"
                      required
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Tell me about your project..."
                      rows={6}
                      className="bg-white/50 border-white/30 focus:border-blue-500"
                    />
                  </div>

                  {submitStatus && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`p-4 rounded-lg ${
                        submitStatus.type === "success"
                          ? "bg-green-100 text-green-800 border border-green-200"
                          : "bg-red-100 text-red-800 border border-red-200"
                      }`}
                    >
                      {submitStatus.message}
                    </motion.div>
                  )}

                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 text-white py-3 md:py-4 rounded-full font-medium shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <div className="flex items-center justify-center space-x-2">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Sending...</span>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center space-x-2">
                        <span>Send Message</span>
                        <Send className="h-4 w-4" />
                      </div>
                    )}
                  </Button>
                </form>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const renderCurrentPage = () => {
    switch (currentPage) {
      case "home":
        return <HomePage />
      case "about":
        return <AboutPage />
      case "services":
        return <ServicesPage />
      case "portfolio":
        return <PortfolioPage />
      case "blog":
        return <BlogPage />
      case "contact":
        return <ContactPage />
      default:
        return <HomePage />
    }
  }

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Enhanced Cursor Effect */}
      {!isMobile && (
        <motion.div
          className="fixed top-0 left-0 w-4 h-4 md:w-6 md:h-6 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full pointer-events-none z-50 mix-blend-difference"
          animate={{
            x: mousePosition.x - (isMobile ? 8 : 12),
            y: mousePosition.y - (isMobile ? 8 : 12),
          }}
          transition={{ type: "spring", stiffness: 500, damping: 28 }}
        />
      )}

      {/* Enhanced Navigation */}
      <motion.nav
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        className="fixed top-0 left-0 right-0 z-40 p-4 md:p-6"
      >
        <div className="flex justify-between items-center">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="text-xl md:text-2xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent"
          >
            AmeerDev
          </motion.div>

          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 md:p-3 bg-white/20 backdrop-blur-sm rounded-full border border-white/30 hover:bg-white/30 transition-all duration-300"
          >
            {isMenuOpen ? (
              <X className="h-5 w-5 md:h-6 md:w-6 text-slate-700" />
            ) : (
              <Menu className="h-5 w-5 md:h-6 md:w-6 text-slate-700" />
            )}
          </motion.button>
        </div>
      </motion.nav>

      {/* Full Screen Navigation Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-gradient-to-br from-slate-900/95 via-blue-900/95 to-emerald-900/95 backdrop-blur-xl"
          >
            <div className="flex items-center justify-center min-h-screen p-4">
              <div className="text-center">
                <motion.h2
                  initial={{ opacity: 0, y: -30 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-3xl md:text-4xl font-bold text-white mb-8 md:mb-12"
                >
                  Navigation
                </motion.h2>
                <div className="grid grid-cols-1 gap-4 md:gap-6">
                  {pages.map((page, index) => (
                    <motion.button
                      key={page.id}
                      initial={{ opacity: 0, x: -50 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      whileHover={{ scale: 1.05, x: 10 }}
                      onClick={() => {
                        setCurrentPage(page.id)
                        setIsMenuOpen(false)
                      }}
                      className={`flex items-center space-x-4 p-4 md:p-6 rounded-2xl transition-all duration-300 ${
                        currentPage === page.id
                          ? "bg-gradient-to-r from-blue-600 to-emerald-600 text-white"
                          : "bg-white/10 text-white hover:bg-white/20"
                      }`}
                    >
                      <page.icon className="h-6 w-6 md:h-8 md:w-8" />
                      <span className="text-lg md:text-2xl font-semibold">{page.title}</span>
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Page Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -100 }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
        >
          {renderCurrentPage()}
        </motion.div>
      </AnimatePresence>

      {/* Enhanced Page Indicator */}
      <div className="fixed bottom-4 md:bottom-6 left-1/2 transform -translate-x-1/2 z-40">
        <div className="flex space-x-2 bg-white/20 backdrop-blur-sm rounded-full p-2 md:p-3 border border-white/30">
          {pages.map((page) => (
            <motion.button
              key={page.id}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.8 }}
              onClick={() => setCurrentPage(page.id)}
              className={`w-3 h-3 md:w-4 md:h-4 rounded-full transition-all duration-300 flex items-center justify-center ${
                currentPage === page.id ? "bg-gradient-to-r from-blue-500 to-emerald-500" : "bg-white/50"
              }`}
            >
              {currentPage === page.id && <page.icon className="h-1.5 w-1.5 md:h-2 md:w-2 text-white" />}
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  )
}
