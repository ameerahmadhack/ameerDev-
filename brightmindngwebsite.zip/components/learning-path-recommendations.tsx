"use client"

import { motion } from "framer-motion"
import { ArrowRight, Target, Clock, Award, TrendingUp } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

const learningPaths = [
  {
    id: 1,
    title: "Full-Stack Web Developer",
    description: "Complete path from frontend to backend development",
    duration: "6-8 months",
    difficulty: "Beginner to Advanced",
    courses: [
      { name: "HTML5 & CSS3", completed: true },
      { name: "JavaScript Essentials", completed: true },
      { name: "React Development", completed: false, current: true },
      { name: "Node.js Backend", completed: false },
      { name: "Database Design", completed: false },
      { name: "Full-Stack Project", completed: false },
    ],
    skills: ["Frontend", "Backend", "Database", "Deployment"],
    careerOutcomes: ["Web Developer", "Full-Stack Engineer", "Software Developer"],
    salary: "₦2,500,000 - ₦8,000,000",
    progress: 33,
    color: "from-blue-500 to-cyan-500",
  },
  {
    id: 2,
    title: "Data Science & AI",
    description: "Master data analysis, machine learning, and AI",
    duration: "8-10 months",
    difficulty: "Intermediate to Expert",
    courses: [
      { name: "Python Programming", completed: false, current: true },
      { name: "Data Analysis", completed: false },
      { name: "Machine Learning", completed: false },
      { name: "Deep Learning", completed: false },
      { name: "AI Projects", completed: false },
    ],
    skills: ["Python", "Statistics", "ML", "AI", "Data Visualization"],
    careerOutcomes: ["Data Scientist", "ML Engineer", "AI Researcher"],
    salary: "₦3,000,000 - ₦12,000,000",
    progress: 0,
    color: "from-purple-500 to-pink-500",
  },
  {
    id: 3,
    title: "Mobile App Developer",
    description: "Build native and cross-platform mobile applications",
    duration: "5-7 months",
    difficulty: "Beginner to Advanced",
    courses: [
      { name: "Mobile Development Basics", completed: false, current: true },
      { name: "React Native", completed: false },
      { name: "Flutter Development", completed: false },
      { name: "Mobile UI/UX", completed: false },
      { name: "App Store Deployment", completed: false },
    ],
    skills: ["React Native", "Flutter", "Mobile UI", "App Store"],
    careerOutcomes: ["Mobile Developer", "App Developer", "Cross-Platform Developer"],
    salary: "₦2,000,000 - ₦7,000,000",
    progress: 0,
    color: "from-green-500 to-emerald-500",
  },
]

export function LearningPathRecommendations() {
  return (
    <section className="py-20 bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Recommended{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
              Learning Paths
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Structured learning journeys designed to take you from beginner to professional in your chosen field
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {learningPaths.map((path, index) => (
            <motion.div
              key={path.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <Card className="h-full bg-white/80 backdrop-blur-sm border-white/20 hover:shadow-2xl transition-all duration-500 overflow-hidden">
                {/* Header with gradient */}
                <div className={`h-2 bg-gradient-to-r ${path.color}`} />

                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-3 rounded-lg bg-gradient-to-r ${path.color}`}>
                      <Target className="w-6 h-6 text-white" />
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {path.difficulty}
                    </Badge>
                  </div>

                  <CardTitle className="text-xl font-bold mb-2">{path.title}</CardTitle>
                  <p className="text-slate-600 text-sm leading-relaxed">{path.description}</p>

                  <div className="flex items-center gap-4 mt-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{path.duration}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="w-4 h-4" />
                      <span>{path.progress}% Complete</span>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  {/* Progress */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Progress</span>
                      <span className="font-medium">{path.progress}%</span>
                    </div>
                    <Progress value={path.progress} className="h-2" />
                  </div>

                  {/* Course List */}
                  <div className="space-y-3">
                    <h4 className="font-medium text-sm text-slate-700">Course Sequence:</h4>
                    <div className="space-y-2">
                      {path.courses.slice(0, 4).map((course, idx) => (
                        <div key={idx} className="flex items-center gap-3 text-sm">
                          <div
                            className={`w-2 h-2 rounded-full ${
                              course.completed ? "bg-green-500" : course.current ? "bg-blue-500" : "bg-slate-300"
                            }`}
                          />
                          <span
                            className={
                              course.completed
                                ? "text-slate-500 line-through"
                                : course.current
                                  ? "text-blue-600 font-medium"
                                  : "text-slate-600"
                            }
                          >
                            {course.name}
                          </span>
                        </div>
                      ))}
                      {path.courses.length > 4 && (
                        <div className="text-xs text-slate-500 ml-5">+{path.courses.length - 4} more courses</div>
                      )}
                    </div>
                  </div>

                  {/* Skills */}
                  <div className="space-y-3">
                    <h4 className="font-medium text-sm text-slate-700">Skills You'll Learn:</h4>
                    <div className="flex flex-wrap gap-1">
                      {path.skills.map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs bg-blue-100 text-blue-700">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Career Outcomes */}
                  <div className="space-y-3">
                    <h4 className="font-medium text-sm text-slate-700">Career Opportunities:</h4>
                    <div className="space-y-1">
                      {path.careerOutcomes.slice(0, 2).map((career, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm text-slate-600">
                          <Award className="w-3 h-3 text-green-600" />
                          <span>{career}</span>
                        </div>
                      ))}
                    </div>
                    <div className="text-sm font-medium text-green-600">Salary Range: {path.salary}</div>
                  </div>

                  <Button className={`w-full bg-gradient-to-r ${path.color} hover:opacity-90 text-white group`}>
                    Start Learning Path
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
