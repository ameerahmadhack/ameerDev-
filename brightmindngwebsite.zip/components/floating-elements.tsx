"use client"

import { motion } from "framer-motion"
import { Code, Lightbulb, Cpu, Database, Smartphone, Palette } from "lucide-react"

const floatingIcons = [
  { icon: Code, delay: 0, x: "10%", y: "20%" },
  { icon: Lightbulb, delay: 0.5, x: "80%", y: "15%" },
  { icon: Cpu, delay: 1, x: "15%", y: "70%" },
  { icon: Database, delay: 1.5, x: "85%", y: "75%" },
  { icon: Smartphone, delay: 2, x: "60%", y: "25%" },
  { icon: Palette, delay: 2.5, x: "25%", y: "45%" },
]

export function FloatingElements() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {floatingIcons.map((item, index) => (
        <motion.div
          key={index}
          className="absolute"
          style={{ left: item.x, top: item.y }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{
            opacity: [0, 0.3, 0.1, 0.3],
            scale: [0, 1, 1.1, 1],
            y: [0, -20, 0, -10, 0],
          }}
          transition={{
            duration: 6,
            delay: item.delay,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        >
          <div className="p-3 rounded-full bg-gradient-to-r from-blue-500/20 to-indigo-500/20 backdrop-blur-sm">
            <item.icon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
          </div>
        </motion.div>
      ))}
    </div>
  )
}
