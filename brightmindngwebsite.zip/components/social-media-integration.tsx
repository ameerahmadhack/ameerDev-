"use client"

import { motion } from "framer-motion"
import { Facebook, Twitter, Instagram, Linkedin, Youtube, Share2, Copy } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { useState } from "react"
import { toast } from "@/hooks/use-toast"

interface SocialMediaProps {
  variant?: "follow" | "share" | "footer"
  className?: string
}

export function SocialMedia({ variant = "follow", className = "" }: SocialMediaProps) {
  const socialLinks = [
    {
      name: "Facebook",
      icon: Facebook,
      color: "bg-blue-600 hover:bg-blue-700",
      url: "https://facebook.com/brightmindng",
    },
    {
      name: "Twitter",
      icon: Twitter,
      color: "bg-sky-500 hover:bg-sky-600",
      url: "https://twitter.com/brightmindng",
    },
    {
      name: "Instagram",
      icon: Instagram,
      color: "bg-pink-600 hover:bg-pink-700",
      url: "https://instagram.com/brightmindng",
    },
    {
      name: "LinkedIn",
      icon: Linkedin,
      color: "bg-blue-700 hover:bg-blue-800",
      url: "https://linkedin.com/company/brightmindng",
    },
    {
      name: "YouTube",
      icon: Youtube,
      color: "bg-red-600 hover:bg-red-700",
      url: "https://youtube.com/c/brightmindng",
    },
  ]

  if (variant === "follow") {
    return (
      <div className={`flex items-center justify-center space-x-3 ${className}`}>
        <span className="text-sm font-medium text-slate-600">Follow us:</span>
        <div className="flex items-center space-x-2">
          {socialLinks.map((social, index) => (
            <motion.a
              key={social.name}
              href={social.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`w-8 h-8 flex items-center justify-center rounded-full text-white transition-all ${social.color}`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <social.icon size={16} />
            </motion.a>
          ))}
        </div>
      </div>
    )
  }

  if (variant === "footer") {
    return (
      <div className={`flex items-center space-x-4 ${className}`}>
        {socialLinks.map((social) => (
          <TooltipProvider key={social.name}>
            <Tooltip>
              <TooltipTrigger asChild>
                <motion.a
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-slate-100 transition-colors"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <social.icon size={20} />
                </motion.a>
              </TooltipTrigger>
              <TooltipContent>
                <p>{social.name}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        ))}
      </div>
    )
  }

  return (
    <div className={`flex items-center justify-center space-x-3 ${className}`}>
      <span className="text-sm font-medium text-slate-600">Share:</span>
      <div className="flex items-center space-x-2">
        {socialLinks.map((social) => (
          <motion.a
            key={social.name}
            href={social.url}
            target="_blank"
            rel="noopener noreferrer"
            className={`w-7 h-7 flex items-center justify-center rounded-full text-white transition-all ${social.color}`}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <social.icon size={14} />
          </motion.a>
        ))}
      </div>
    </div>
  )
}

interface SocialShareButtonProps {
  url: string
  title: string
}

export function SocialShareButton({ url, title }: SocialShareButtonProps) {
  const [isOpen, setIsOpen] = useState(false)

  const handleShare = (platform: string) => {
    let shareUrl = ""

    switch (platform) {
      case "facebook":
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`
        break
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`
        break
      case "linkedin":
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`
        break
      case "whatsapp":
        shareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(title + " " + url)}`
        break
      default:
        break
    }

    if (shareUrl) {
      window.open(shareUrl, "_blank", "width=600,height=400")
    }

    setIsOpen(false)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(url)
    toast({
      title: "Link copied!",
      description: "The link has been copied to your clipboard.",
    })
    setIsOpen(false)
  }

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="icon" className="rounded-full w-8 h-8">
          <Share2 className="h-4 w-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-2" align="end">
        <div className="grid gap-1">
          <Button
            variant="ghost"
            className="flex items-center justify-start gap-2 px-2 h-9"
            onClick={() => handleShare("facebook")}
          >
            <Facebook className="h-4 w-4 text-blue-600" />
            <span>Facebook</span>
          </Button>
          <Button
            variant="ghost"
            className="flex items-center justify-start gap-2 px-2 h-9"
            onClick={() => handleShare("twitter")}
          >
            <Twitter className="h-4 w-4 text-sky-500" />
            <span>Twitter</span>
          </Button>
          <Button
            variant="ghost"
            className="flex items-center justify-start gap-2 px-2 h-9"
            onClick={() => handleShare("linkedin")}
          >
            <Linkedin className="h-4 w-4 text-blue-700" />
            <span>LinkedIn</span>
          </Button>
          <Button
            variant="ghost"
            className="flex items-center justify-start gap-2 px-2 h-9"
            onClick={() => handleShare("whatsapp")}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-4 w-4 text-green-600"
            >
              <path d="M3 21l1.65-3.8a9 9 0 1 1 3.4 2.9L3 21" />
              <path d="M9 10a.5.5 0 0 0 1 0V9a.5.5 0 0 0-1 0v1Z" />
              <path d="M14 10a.5.5 0 0 0 1 0V9a.5.5 0 0 0-1 0v1Z" />
              <path d="M9.5 13.5c.5 1.5 2.5 2 4 1" />
            </svg>
            <span>WhatsApp</span>
          </Button>
          <Button variant="ghost" className="flex items-center justify-start gap-2 px-2 h-9" onClick={copyToClipboard}>
            <Copy className="h-4 w-4" />
            <span>Copy link</span>
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  )
}
