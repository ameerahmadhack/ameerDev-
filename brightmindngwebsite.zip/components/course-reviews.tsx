"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Star, ThumbsUp, MessageSquare, Filter, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"

interface Review {
  id: string
  userName: string
  userImage?: string
  rating: number
  title: string
  content: string
  date: string
  helpful: number
  verified: boolean
  course: string
}

const reviews: Review[] = [
  {
    id: "1",
    userName: "Muhammad Ibrahim",
    rating: 5,
    title: "Excellent Python Course!",
    content:
      "This course exceeded my expectations. Ameer Ahmad's teaching style is clear and practical. I went from knowing nothing about Python to building real projects. The hands-on approach really helped me understand the concepts.",
    date: "2 weeks ago",
    helpful: 24,
    verified: true,
    course: "Python Programming",
  },
  {
    id: "2",
    userName: "Aisha Abdullahi",
    rating: 5,
    title: "Perfect for beginners",
    content:
      "As someone with no programming background, I was worried about starting. But this course made everything so easy to understand. The projects are well-designed and the community support is amazing.",
    date: "1 month ago",
    helpful: 18,
    verified: true,
    course: "Python Programming",
  },
  {
    id: "3",
    userName: "Yusuf Hassan",
    rating: 4,
    title: "Great content, could use more advanced topics",
    content:
      "The course covers the fundamentals very well. I would love to see more advanced Python topics like decorators and metaclasses covered in more detail. Overall, very satisfied with the learning experience.",
    date: "3 weeks ago",
    helpful: 12,
    verified: true,
    course: "Python Programming",
  },
  {
    id: "4",
    userName: "Fatima Al-Zahra",
    rating: 5,
    title: "Life-changing course!",
    content:
      "I got my first developer job 2 months after completing this course. The practical projects in the curriculum really prepared me for real-world development. Thank you Ameer Ahmad!",
    date: "1 week ago",
    helpful: 31,
    verified: true,
    course: "Python Programming",
  },
  {
    id: "5",
    userName: "Omar Suleiman",
    rating: 4,
    title: "Solid foundation",
    content:
      "Good course structure and clear explanations. The instructor responds quickly to questions in the community forum. Would recommend to anyone starting their programming journey.",
    date: "2 months ago",
    helpful: 15,
    verified: true,
    course: "Python Programming",
  },
]

interface CourseReviewsProps {
  courseName?: string
}

export function CourseReviews({ courseName = "Python Programming" }: CourseReviewsProps) {
  const [showReviewForm, setShowReviewForm] = useState(false)
  const [newReview, setNewReview] = useState({ rating: 5, title: "", content: "" })
  const [sortBy, setSortBy] = useState("newest")
  const [filterRating, setFilterRating] = useState("all")

  const courseReviews = reviews.filter((review) => review.course === courseName)
  const averageRating = courseReviews.reduce((sum, review) => sum + review.rating, 0) / courseReviews.length
  const totalReviews = courseReviews.length

  const ratingDistribution = [5, 4, 3, 2, 1].map((rating) => ({
    rating,
    count: courseReviews.filter((review) => review.rating === rating).length,
    percentage: (courseReviews.filter((review) => review.rating === rating).length / totalReviews) * 100,
  }))

  const handleSubmitReview = () => {
    // Handle review submission
    console.log("New review:", newReview)
    setShowReviewForm(false)
    setNewReview({ rating: 5, title: "", content: "" })
  }

  return (
    <section className="py-16 bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-6xl mx-auto"
        >
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">
              Student{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
                Reviews
              </span>
            </h2>
            <p className="text-xl text-muted-foreground">See what our students say about {courseName}</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Rating Summary */}
            <div className="lg:col-span-1">
              <Card className="bg-white/80 backdrop-blur-sm border-white/20 sticky top-24">
                <CardHeader className="text-center">
                  <div className="text-5xl font-bold text-primary mb-2">{averageRating.toFixed(1)}</div>
                  <div className="flex items-center justify-center gap-1 mb-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-5 h-5 ${
                          star <= averageRating ? "fill-yellow-400 text-yellow-400" : "text-slate-300"
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-muted-foreground">{totalReviews} reviews</p>
                </CardHeader>

                <CardContent className="space-y-3">
                  {ratingDistribution.map(({ rating, count, percentage }) => (
                    <div key={rating} className="flex items-center gap-3">
                      <div className="flex items-center gap-1 w-12">
                        <span className="text-sm">{rating}</span>
                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      </div>
                      <Progress value={percentage} className="flex-1 h-2" />
                      <span className="text-sm text-muted-foreground w-8">{count}</span>
                    </div>
                  ))}

                  <Button
                    onClick={() => setShowReviewForm(true)}
                    className="w-full mt-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                  >
                    Write a Review
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Reviews List */}
            <div className="lg:col-span-2 space-y-6">
              {/* Filters */}
              <div className="flex flex-wrap gap-4 items-center justify-between">
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="gap-2">
                    <Filter className="w-4 h-4" />
                    Sort: Newest
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    All Ratings
                  </Button>
                </div>
              </div>

              {/* Reviews */}
              <div className="space-y-6">
                {courseReviews.map((review, index) => (
                  <motion.div
                    key={review.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="bg-white/80 backdrop-blur-sm border-white/20 hover:shadow-lg transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={review.userImage || "/placeholder.svg"} />
                            <AvatarFallback className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
                              {review.userName
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>

                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h4 className="font-semibold">{review.userName}</h4>
                              {review.verified && (
                                <Badge variant="secondary" className="bg-green-100 text-green-700 text-xs">
                                  Verified Purchase
                                </Badge>
                              )}
                              <span className="text-sm text-muted-foreground">{review.date}</span>
                            </div>

                            <div className="flex items-center gap-2 mb-3">
                              <div className="flex items-center gap-1">
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <Star
                                    key={star}
                                    className={`w-4 h-4 ${
                                      star <= review.rating ? "fill-yellow-400 text-yellow-400" : "text-slate-300"
                                    }`}
                                  />
                                ))}
                              </div>
                              <h5 className="font-medium">{review.title}</h5>
                            </div>

                            <p className="text-slate-700 leading-relaxed mb-4">{review.content}</p>

                            <div className="flex items-center gap-4">
                              <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground">
                                <ThumbsUp className="w-4 h-4" />
                                Helpful ({review.helpful})
                              </Button>
                              <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground">
                                <MessageSquare className="w-4 h-4" />
                                Reply
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          {/* Review Form Modal */}
          <AnimatePresence>
            {showReviewForm && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
                onClick={() => setShowReviewForm(false)}
              >
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.9, opacity: 0 }}
                  onClick={(e) => e.stopPropagation()}
                  className="bg-white rounded-lg p-6 max-w-2xl w-full"
                >
                  <CardHeader className="px-0 pt-0">
                    <CardTitle>Write a Review for {courseName}</CardTitle>
                  </CardHeader>

                  <CardContent className="px-0 space-y-6">
                    {/* Rating */}
                    <div>
                      <label className="block text-sm font-medium mb-2">Rating</label>
                      <div className="flex gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            onClick={() => setNewReview({ ...newReview, rating: star })}
                            className="p-1"
                          >
                            <Star
                              className={`w-6 h-6 ${
                                star <= newReview.rating ? "fill-yellow-400 text-yellow-400" : "text-slate-300"
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Title */}
                    <div>
                      <label className="block text-sm font-medium mb-2">Review Title</label>
                      <input
                        type="text"
                        value={newReview.title}
                        onChange={(e) => setNewReview({ ...newReview, title: e.target.value })}
                        className="w-full p-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Summarize your experience..."
                      />
                    </div>

                    {/* Content */}
                    <div>
                      <label className="block text-sm font-medium mb-2">Your Review</label>
                      <Textarea
                        value={newReview.content}
                        onChange={(e) => setNewReview({ ...newReview, content: e.target.value })}
                        className="min-h-[120px]"
                        placeholder="Tell other students about your experience with this course..."
                      />
                    </div>

                    <div className="flex gap-4 pt-4">
                      <Button variant="outline" onClick={() => setShowReviewForm(false)} className="flex-1">
                        Cancel
                      </Button>
                      <Button
                        onClick={handleSubmitReview}
                        className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                      >
                        Submit Review
                      </Button>
                    </div>
                  </CardContent>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  )
}
