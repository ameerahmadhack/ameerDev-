"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { CreditCard, Shield, CheckCircle, X, Lock, Smartphone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  course: {
    name: string
    instructor: string
    price: number
    originalPrice?: number
  }
}

export function PaymentIntegration({ isOpen, onClose, course }: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState("card")
  const [isProcessing, setIsProcessing] = useState(false)
  const [paymentSuccess, setPaymentSuccess] = useState(false)
  const [formData, setFormData] = useState({
    email: "",
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    cardName: "",
    phone: "",
  })

  const handlePayment = async () => {
    setIsProcessing(true)

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 3000))

    setIsProcessing(false)
    setPaymentSuccess(true)

    // Auto close after success
    setTimeout(() => {
      onClose()
      setPaymentSuccess(false)
    }, 3000)
  }

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "")
    const matches = v.match(/\d{4,16}/g)
    const match = (matches && matches[0]) || ""
    const parts = []

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4))
    }

    if (parts.length) {
      return parts.join(" ")
    } else {
      return v
    }
  }

  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "")
    if (v.length >= 2) {
      return v.substring(0, 2) + "/" + v.substring(2, 4)
    }
    return v
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ type: "spring", duration: 0.5 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-4xl max-h-[90vh] overflow-y-auto"
          >
            <Card className="bg-white/95 backdrop-blur-md border-white/20 shadow-2xl">
              <CardHeader className="flex flex-row items-center justify-between pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gradient-to-r from-green-600 to-emerald-600 rounded-lg">
                    <Lock className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-2xl font-bold">Secure Checkout</CardTitle>
                    <p className="text-sm text-muted-foreground">Complete your enrollment</p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={onClose}>
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>

              <CardContent>
                {!paymentSuccess ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Course Summary */}
                    <div className="space-y-6">
                      <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
                        <CardHeader>
                          <CardTitle className="text-lg">Order Summary</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="flex items-start gap-4">
                            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                              {course.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </div>
                            <div className="flex-1">
                              <h3 className="font-semibold">{course.name}</h3>
                              <p className="text-sm text-muted-foreground">by {course.instructor}</p>
                            </div>
                          </div>

                          <div className="space-y-2 pt-4 border-t">
                            <div className="flex justify-between">
                              <span>Course Price</span>
                              <span className="font-medium">₦{course.price.toLocaleString()}</span>
                            </div>
                            {course.originalPrice && (
                              <div className="flex justify-between text-sm text-muted-foreground">
                                <span>Original Price</span>
                                <span className="line-through">₦{course.originalPrice.toLocaleString()}</span>
                              </div>
                            )}
                            <div className="flex justify-between text-sm text-green-600">
                              <span>You Save</span>
                              <span>
                                ₦{course.originalPrice ? (course.originalPrice - course.price).toLocaleString() : "0"}
                              </span>
                            </div>
                            <div className="flex justify-between text-lg font-bold pt-2 border-t">
                              <span>Total</span>
                              <span>₦{course.price.toLocaleString()}</span>
                            </div>
                          </div>

                          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                            <div className="flex items-center gap-2 text-green-700">
                              <CheckCircle className="w-5 h-5" />
                              <span className="font-medium">What's Included:</span>
                            </div>
                            <ul className="mt-2 space-y-1 text-sm text-green-600">
                              <li>• Lifetime access to course content</li>
                              <li>• Certificate of completion</li>
                              <li>• Community access</li>
                              <li>• 30-day money-back guarantee</li>
                            </ul>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Payment Form */}
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-semibold mb-4">Payment Method</h3>
                        <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-3">
                          <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-slate-50">
                            <RadioGroupItem value="card" id="card" />
                            <Label htmlFor="card" className="flex items-center gap-3 cursor-pointer flex-1">
                              <CreditCard className="w-5 h-5 text-blue-600" />
                              <span>Credit/Debit Card</span>
                              <Badge variant="secondary" className="ml-auto">
                                Recommended
                              </Badge>
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-slate-50">
                            <RadioGroupItem value="bank" id="bank" />
                            <Label htmlFor="bank" className="flex items-center gap-3 cursor-pointer flex-1">
                              <Smartphone className="w-5 h-5 text-green-600" />
                              <span>Bank Transfer</span>
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>

                      {paymentMethod === "card" && (
                        <motion.div
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="space-y-4"
                        >
                          <div>
                            <label className="block text-sm font-medium mb-2">Email Address</label>
                            <Input
                              type="email"
                              value={formData.email}
                              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                              placeholder="your.email@example.com"
                              className="h-12"
                            />
                          </div>

                          <div>
                            <label className="block text-sm font-medium mb-2">Card Number</label>
                            <Input
                              type="text"
                              value={formData.cardNumber}
                              onChange={(e) =>
                                setFormData({ ...formData, cardNumber: formatCardNumber(e.target.value) })
                              }
                              placeholder="1234 5678 9012 3456"
                              maxLength={19}
                              className="h-12"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium mb-2">Expiry Date</label>
                              <Input
                                type="text"
                                value={formData.expiryDate}
                                onChange={(e) =>
                                  setFormData({ ...formData, expiryDate: formatExpiryDate(e.target.value) })
                                }
                                placeholder="MM/YY"
                                maxLength={5}
                                className="h-12"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-2">CVV</label>
                              <Input
                                type="text"
                                value={formData.cvv}
                                onChange={(e) => setFormData({ ...formData, cvv: e.target.value.replace(/\D/g, "") })}
                                placeholder="123"
                                maxLength={4}
                                className="h-12"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-sm font-medium mb-2">Cardholder Name</label>
                            <Input
                              type="text"
                              value={formData.cardName}
                              onChange={(e) => setFormData({ ...formData, cardName: e.target.value })}
                              placeholder="Name on card"
                              className="h-12"
                            />
                          </div>
                        </motion.div>
                      )}

                      {paymentMethod === "bank" && (
                        <motion.div
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="space-y-4"
                        >
                          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <h4 className="font-medium text-blue-800 mb-2">Bank Transfer Instructions</h4>
                            <div className="text-sm text-blue-700 space-y-1">
                              <p>
                                <strong>Account Name:</strong> BrightMind NG Limited
                              </p>
                              <p>
                                <strong>Account Number:</strong> 1234567890
                              </p>
                              <p>
                                <strong>Bank:</strong> First Bank of Nigeria
                              </p>
                              <p>
                                <strong>Amount:</strong> ₦{course.price.toLocaleString()}
                              </p>
                            </div>
                          </div>

                          <div>
                            <label className="block text-sm font-medium mb-2">Your Phone Number</label>
                            <Input
                              type="tel"
                              value={formData.phone}
                              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                              placeholder="+234 801 234 5678"
                              className="h-12"
                            />
                          </div>
                        </motion.div>
                      )}

                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Shield className="w-4 h-4 text-green-600" />
                        <span>Your payment information is secure and encrypted</span>
                      </div>

                      <Button
                        onClick={handlePayment}
                        disabled={isProcessing}
                        className="w-full h-12 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-medium"
                      >
                        {isProcessing ? (
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                            className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                          />
                        ) : (
                          `Complete Payment - ₦${course.price.toLocaleString()}`
                        )}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-16"
                  >
                    <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-green-600 mb-4">Payment Successful! 🎉</h3>
                    <p className="text-lg text-slate-600 mb-6">
                      Welcome to <strong>{course.name}</strong>!
                    </p>
                    <div className="bg-green-50 border border-green-200 rounded-lg p-6 max-w-md mx-auto">
                      <p className="text-green-700 mb-4">
                        You now have lifetime access to the course. Check your email for login details and course
                        access.
                      </p>
                      <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                        Start Learning Now
                      </Button>
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
