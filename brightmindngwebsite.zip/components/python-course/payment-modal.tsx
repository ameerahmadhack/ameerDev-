"use client"

import type React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, CreditCard, Building2, CheckCircle, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Badge } from "@/components/ui/badge"

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  course: {
    name: string
    instructor: string
    price: number
    originalPrice?: number
  }
}

export function PaymentModal({ isOpen, onClose, course }: PaymentModalProps) {
  const [step, setStep] = useState(1) // 1: Details, 2: Payment, 3: Success
  const [paymentMethod, setPaymentMethod] = useState("bank")
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    transferPhone: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [studentId, setStudentId] = useState("")

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (formData.fullName && formData.email && formData.phone) {
      setStep(2)
    }
  }

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call to backend
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Generate student ID
    const generatedId = `BM${Date.now().toString().slice(-6)}`
    setStudentId(generatedId)

    // Save to backend (simulated)
    const enrollmentData = {
      ...formData,
      course: course.name,
      paymentMethod,
      amount: course.price,
      studentId: generatedId,
      status: "pending",
      timestamp: new Date().toISOString(),
    }

    console.log("Enrollment data:", enrollmentData)

    setIsSubmitting(false)
    setStep(3)
  }

  const resetModal = () => {
    setStep(1)
    setFormData({ fullName: "", email: "", phone: "", transferPhone: "" })
    setStudentId("")
    onClose()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={resetModal}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ type: "spring", duration: 0.5 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-2xl max-h-[90vh] overflow-y-auto"
          >
            <Card className="bg-white/95 backdrop-blur-md border-white/20 shadow-2xl">
              <CardHeader className="flex flex-row items-center justify-between pb-4">
                <div>
                  <CardTitle className="text-2xl font-bold">
                    {step === 1 && "Course Enrollment"}
                    {step === 2 && "Payment Details"}
                    {step === 3 && "Enrollment Successful!"}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    {step === 1 && "Enter your details to continue"}
                    {step === 2 && "Choose your payment method"}
                    {step === 3 && "Welcome to BrightMind NG!"}
                  </p>
                </div>
                <Button variant="ghost" size="icon" onClick={resetModal}>
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>

              <CardContent>
                {/* Step 1: Student Details */}
                {step === 1 && (
                  <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
                    {/* Course Summary */}
                    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
                      <CardContent className="p-4">
                        <h3 className="font-semibold text-lg mb-2">{course.name}</h3>
                        <p className="text-sm text-muted-foreground mb-3">by {course.instructor}</p>
                        <div className="flex items-center gap-4">
                          <span className="text-2xl font-bold text-blue-600">₦{course.price.toLocaleString()}</span>
                          {course.originalPrice && (
                            <span className="text-lg text-muted-foreground line-through">
                              ₦{course.originalPrice.toLocaleString()}
                            </span>
                          )}
                          <Badge className="bg-green-100 text-green-700">
                            Save ₦{course.originalPrice ? (course.originalPrice - course.price).toLocaleString() : "0"}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Student Details Form */}
                    <form onSubmit={handleDetailsSubmit} className="space-y-4">
                      <div>
                        <Label htmlFor="fullName">Full Name *</Label>
                        <Input
                          id="fullName"
                          type="text"
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                          placeholder="Enter your full name"
                          required
                          className="mt-1"
                        />
                      </div>

                      <div>
                        <Label htmlFor="email">Email Address *</Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="Enter your email address"
                          required
                          className="mt-1"
                        />
                      </div>

                      <div>
                        <Label htmlFor="phone">Phone Number *</Label>
                        <Input
                          id="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          placeholder="+234 801 234 5678"
                          required
                          className="mt-1"
                        />
                      </div>

                      <Button
                        type="submit"
                        className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                      >
                        Continue to Payment
                      </Button>
                    </form>
                  </motion.div>
                )}

                {/* Step 2: Payment Method */}
                {step === 2 && (
                  <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Choose Payment Method</h3>
                      <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-3">
                        <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-slate-50">
                          <RadioGroupItem value="bank" id="bank" />
                          <Label htmlFor="bank" className="flex items-center gap-3 cursor-pointer flex-1">
                            <Building2 className="w-5 h-5 text-green-600" />
                            <span>Bank Transfer</span>
                            <Badge variant="secondary">Recommended</Badge>
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2 p-4 border rounded-lg bg-slate-50 opacity-60">
                          <RadioGroupItem value="card" id="card" disabled />
                          <Label htmlFor="card" className="flex items-center gap-3 cursor-not-allowed flex-1">
                            <CreditCard className="w-5 h-5 text-slate-400" />
                            <span className="text-slate-500">Card Payment</span>
                            <Badge variant="outline" className="text-orange-600 border-orange-600">
                              Coming Soon
                            </Badge>
                          </Label>
                        </div>
                      </RadioGroup>

                      <div className="mt-3 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                        <div className="flex items-center gap-2 text-orange-700">
                          <AlertCircle className="w-4 h-4" />
                          <span className="text-sm font-medium">Card payments temporarily unavailable</span>
                        </div>
                        <p className="text-sm text-orange-600 mt-1">
                          We're updating our security systems. Please use bank transfer for now.
                        </p>
                      </div>
                    </div>

                    {paymentMethod === "bank" && (
                      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
                        <Card className="bg-blue-50 border-blue-200">
                          <CardContent className="p-4">
                            <h4 className="font-medium text-blue-800 mb-3">Bank Transfer Details</h4>
                            <div className="space-y-2 text-sm">
                              <div className="flex justify-between">
                                <span className="text-blue-700">Account Name:</span>
                                <span className="font-medium text-blue-900">BrightMind NG Limited</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-blue-700">Account Number:</span>
                                <span className="font-medium text-blue-900">1234567890</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-blue-700">Bank:</span>
                                <span className="font-medium text-blue-900">First Bank of Nigeria</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-blue-700">Amount:</span>
                                <span className="font-medium text-blue-900">₦{course.price.toLocaleString()}</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        <form onSubmit={handlePaymentSubmit} className="space-y-4">
                          <div>
                            <Label htmlFor="transferPhone">Phone Number Used for Transfer *</Label>
                            <Input
                              id="transferPhone"
                              type="tel"
                              value={formData.transferPhone}
                              onChange={(e) => setFormData({ ...formData, transferPhone: e.target.value })}
                              placeholder="Enter phone number used for the transfer"
                              required
                              className="mt-1"
                            />
                            <p className="text-xs text-muted-foreground mt-1">
                              This helps us verify your payment quickly
                            </p>
                          </div>

                          <div className="flex gap-3">
                            <Button type="button" variant="outline" onClick={() => setStep(1)} className="flex-1">
                              Back
                            </Button>
                            <Button
                              type="submit"
                              disabled={isSubmitting}
                              className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                            >
                              {isSubmitting ? "Processing..." : "Complete Enrollment"}
                            </Button>
                          </div>
                        </form>
                      </motion.div>
                    )}
                  </motion.div>
                )}

                {/* Step 3: Success */}
                {step === 3 && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-8"
                  >
                    <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle className="w-10 h-10 text-white" />
                    </div>

                    <h3 className="text-2xl font-bold text-green-600 mb-4">Enrollment Submitted Successfully!</h3>

                    <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
                      <p className="text-green-700 mb-4">
                        Your enrollment has been submitted for review. You will be automatically approved within 5
                        minutes after payment verification.
                      </p>

                      <div className="bg-white border border-green-300 rounded-lg p-4 mb-4">
                        <p className="text-sm text-green-600 mb-2">Your Student ID:</p>
                        <p className="text-2xl font-bold text-green-800 font-mono">{studentId}</p>
                        <p className="text-xs text-green-600 mt-2">
                          Save this ID - you'll need it to access your course
                        </p>
                      </div>

                      <div className="text-sm text-green-700 space-y-1">
                        <p>• Check your email for confirmation details</p>
                        <p>• Use your Student ID to login and access the course</p>
                        <p>• Admin will verify your payment within 5 minutes</p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <Button onClick={resetModal} variant="outline" className="flex-1">
                        Close
                      </Button>
                      <Button
                        asChild
                        className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                      >
                        <a href="/python-course/login">Login to Course</a>
                      </Button>
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
