"use client"

import { motion } from "framer-motion"
import { Star, Award, Users, BookOpen, MapPin, Linkedin, Twitter, Github } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const instructors = [
  {
    id: 1,
    name: "Ameer Ahmad",
    title: "Founder & Lead Instructor",
    image: "/images/ameer-ahmad.jpg",
    rating: 4.9,
    students: 15000,
    courses: 25,
    experience: "8+ years",
    location: "Yobe State, Nigeria",
    bio: "Full-stack developer and tech educator with extensive experience in Python, JavaScript, and cloud technologies. Former senior developer at leading tech companies.",
    specialties: ["Python", "JavaScript", "React", "Node.js", "AWS"],
    social: {
      linkedin: "#",
      twitter: "#",
      github: "#",
    },
  },
  {
    id: 2,
    name: "Fatima Al-Zahra",
    title: "Frontend Development Expert",
    image: "/placeholder.svg?height=120&width=120",
    rating: 4.8,
    students: 8500,
    courses: 12,
    experience: "6+ years",
    location: "Kano, Nigeria",
    bio: "Frontend specialist with deep expertise in modern JavaScript frameworks and responsive design. Passionate about creating beautiful, accessible user interfaces.",
    specialties: ["React", "Vue.js", "TypeScript", "CSS", "UI/UX"],
    social: {
      linkedin: "#",
      twitter: "#",
      github: "#",
    },
  },
  {
    id: 3,
    name: "Dr. Hamza Ali",
    title: "AI/ML Research Scientist",
    image: "/placeholder.svg?height=120&width=120",
    rating: 4.9,
    students: 5200,
    courses: 8,
    experience: "10+ years",
    location: "Kaduna, Nigeria",
    bio: "PhD in Computer Science with specialization in Machine Learning and AI. Published researcher with 50+ papers in top-tier conferences.",
    specialties: ["Machine Learning", "Deep Learning", "Python", "TensorFlow", "Data Science"],
    social: {
      linkedin: "#",
      twitter: "#",
      github: "#",
    },
  },
  {
    id: 4,
    name: "Hafsa Yusuf",
    title: "Design & UX Specialist",
    image: "/placeholder.svg?height=120&width=120",
    rating: 4.7,
    students: 6800,
    courses: 15,
    experience: "7+ years",
    location: "Abuja, Nigeria",
    bio: "Award-winning designer with experience at top design agencies. Expert in user-centered design and modern design tools.",
    specialties: ["Figma", "Adobe Creative Suite", "UI/UX", "Design Systems", "Prototyping"],
    social: {
      linkedin: "#",
      twitter: "#",
      github: "#",
    },
  },
]

export function InstructorProfiles() {
  return (
    <section className="py-20 bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Meet Our{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
              Expert Instructors
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Learn from industry professionals with years of real-world experience and a passion for teaching
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {instructors.map((instructor, index) => (
            <motion.div
              key={instructor.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <Card className="h-full bg-white/80 backdrop-blur-sm border-white/20 hover:shadow-2xl transition-all duration-500">
                <CardHeader className="text-center pb-4">
                  <div className="relative mx-auto mb-4">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full blur-lg opacity-30"></div>
                    <Avatar className="relative w-24 h-24 border-4 border-white shadow-xl">
                      <AvatarImage src={instructor.image || "/placeholder.svg"} />
                      <AvatarFallback className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
                        {instructor.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                  </div>

                  <CardTitle className="text-xl font-bold">{instructor.name}</CardTitle>
                  <p className="text-blue-600 font-medium">{instructor.title}</p>

                  <div className="flex items-center justify-center gap-4 mt-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      <span>{instructor.location}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Award className="w-4 h-4" />
                      <span>{instructor.experience}</span>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  <p className="text-slate-600 leading-relaxed">{instructor.bio}</p>

                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="space-y-1">
                      <div className="flex items-center justify-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="font-bold text-lg">{instructor.rating}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">Rating</p>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-center gap-1">
                        <Users className="w-4 h-4 text-blue-600" />
                        <span className="font-bold text-lg">{(instructor.students / 1000).toFixed(1)}k</span>
                      </div>
                      <p className="text-xs text-muted-foreground">Students</p>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-center gap-1">
                        <BookOpen className="w-4 h-4 text-green-600" />
                        <span className="font-bold text-lg">{instructor.courses}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">Courses</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3 text-sm text-muted-foreground">Specialties:</h4>
                    <div className="flex flex-wrap gap-2">
                      {instructor.specialties.map((specialty) => (
                        <Badge key={specialty} variant="secondary" className="bg-blue-100 text-blue-700">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex gap-2">
                      <Button variant="outline" size="icon" className="h-8 w-8">
                        <Linkedin className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="icon" className="h-8 w-8">
                        <Twitter className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="icon" className="h-8 w-8">
                        <Github className="w-4 h-4" />
                      </Button>
                    </div>
                    <Button
                      size="sm"
                      className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                    >
                      View Courses
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
