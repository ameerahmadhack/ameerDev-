"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { SocialMedia } from "@/components/social-media-integration"
import { ArrowRight, Mail, Phone, MapPin } from "lucide-react"

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-slate-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center space-x-3 mb-4">
              <Image
                src="/images/brightmind-logo.png"
                alt="BrightMind NG Logo"
                width={40}
                height={40}
                className="rounded-lg"
              />
              <div>
                <h3 className="text-xl font-bold">BrightMind NG</h3>
                <p className="text-xs text-slate-400">Illuminate Your Future</p>
              </div>
            </div>
            <p className="text-slate-300 mb-6">
              Empowering the next generation of tech professionals through quality education and practical skills
              development.
            </p>
            <div className="flex flex-col space-y-2">
              <div className="flex items-center space-x-3 text-slate-300">
                <Mail className="w-4 h-4 text-blue-400" />
                <a href="mailto:info@brightmindng.com" className="hover:text-blue-400 transition-colors">
                  info@brightmindng.com
                </a>
              </div>
              <div className="flex items-center space-x-3 text-slate-300">
                <Phone className="w-4 h-4 text-blue-400" />
                <a href="tel:+2349014480971" className="hover:text-blue-400 transition-colors">
                  +234 901 448 0971
                </a>
              </div>
              <div className="flex items-start space-x-3 text-slate-300">
                <MapPin className="w-4 h-4 text-blue-400 mt-1 flex-shrink-0" />
                <span>Lagos, Nigeria</span>
              </div>
            </div>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h3 className="text-lg font-semibold mb-4 border-b border-slate-700 pb-2">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-slate-300 hover:text-blue-400 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-slate-300 hover:text-blue-400 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/categories" className="text-slate-300 hover:text-blue-400 transition-colors">
                  Courses
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-slate-300 hover:text-blue-400 transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-slate-300 hover:text-blue-400 transition-colors">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/coming-soon" className="text-slate-300 hover:text-blue-400 transition-colors">
                  Upcoming Courses
                </Link>
              </li>
            </ul>
          </motion.div>

          {/* Resources */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="text-lg font-semibold mb-4 border-b border-slate-700 pb-2">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/blog" className="text-slate-300 hover:text-blue-400 transition-colors">
                  Tutorials
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-slate-300 hover:text-blue-400 transition-colors">
                  Documentation
                </Link>
              </li>
              <li>
                <Link href="/coming-soon" className="text-slate-300 hover:text-blue-400 transition-colors">
                  Community
                </Link>
              </li>
              <li>
                <Link href="/coming-soon" className="text-slate-300 hover:text-blue-400 transition-colors">
                  Career Resources
                </Link>
              </li>
              <li>
                <Link href="/coming-soon" className="text-slate-300 hover:text-blue-400 transition-colors">
                  FAQ
                </Link>
              </li>
            </ul>
          </motion.div>

          {/* Newsletter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <h3 className="text-lg font-semibold mb-4 border-b border-slate-700 pb-2">Stay Updated</h3>
            <p className="text-slate-300 mb-4">Subscribe to our newsletter for the latest updates and resources.</p>
            <div className="flex flex-col space-y-2">
              <Input
                type="email"
                placeholder="Your email address"
                className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-400"
              />
              <Button className="bg-blue-600 hover:bg-blue-700 text-white w-full">
                Subscribe
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
            <div className="mt-6">
              <p className="text-sm text-slate-400 mb-2">Follow us on social media:</p>
              <SocialMedia variant="footer" />
            </div>
          </motion.div>
        </div>

        <div className="border-t border-slate-800 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-slate-400 text-sm mb-4 md:mb-0">© {currentYear} BrightMind NG. All rights reserved.</p>
          <div className="flex space-x-6 text-sm">
            <Link href="/coming-soon" className="text-slate-400 hover:text-blue-400 transition-colors">
              Privacy Policy
            </Link>
            <Link href="/coming-soon" className="text-slate-400 hover:text-blue-400 transition-colors">
              Terms of Service
            </Link>
            <Link href="/coming-soon" className="text-slate-400 hover:text-blue-400 transition-colors">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
