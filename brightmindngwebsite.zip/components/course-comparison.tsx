"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Plus, Check, Star, Users, Clock, Award, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface Course {
  name: string
  instructor: string
  description: string
  category: string
  rating: number
  students: number
  price: number
  originalPrice?: number
  duration: string
  level: string
  features: string[]
  image?: string
}

interface CourseComparisonProps {
  isOpen: boolean
  onClose: () => void
  availableCourses: Course[]
}

const sampleCourses: Course[] = [
  {
    name: "Python Programming",
    instructor: "Ameer Ahmad",
    description: "Master Python from basics to advanced concepts",
    category: "Programming",
    rating: 4.9,
    students: 1250,
    price: 25000,
    originalPrice: 35000,
    duration: "12 weeks",
    level: "Beginner to Advanced",
    features: [
      "40+ hours of video content",
      "10 hands-on projects",
      "Certificate of completion",
      "Lifetime access",
      "Community support",
      "Job placement assistance",
    ],
  },
  {
    name: "JavaScript Essentials",
    instructor: "Fatima Al-Zahra",
    description: "Modern JavaScript and ES6+ features",
    category: "Web Development",
    rating: 4.8,
    students: 980,
    price: 22000,
    originalPrice: 30000,
    duration: "10 weeks",
    level: "Beginner to Intermediate",
    features: [
      "35+ hours of video content",
      "8 practical projects",
      "Certificate of completion",
      "Lifetime access",
      "Community support",
      "Interview preparation",
    ],
  },
  {
    name: "React Development",
    instructor: "Abdullah Hassan",
    description: "Build modern web apps with React",
    category: "Frontend",
    rating: 4.9,
    students: 1100,
    price: 28000,
    originalPrice: 38000,
    duration: "14 weeks",
    level: "Intermediate to Advanced",
    features: [
      "45+ hours of video content",
      "12 real-world projects",
      "Certificate of completion",
      "Lifetime access",
      "1-on-1 mentoring",
      "Portfolio review",
    ],
  },
]

export function CourseComparison({ isOpen, onClose, availableCourses = sampleCourses }: CourseComparisonProps) {
  const [selectedCourses, setSelectedCourses] = useState<Course[]>([])
  const [showCourseSelector, setShowCourseSelector] = useState(false)

  const addCourse = (course: Course) => {
    if (selectedCourses.length < 3 && !selectedCourses.find((c) => c.name === course.name)) {
      setSelectedCourses([...selectedCourses, course])
    }
    setShowCourseSelector(false)
  }

  const removeCourse = (courseName: string) => {
    setSelectedCourses(selectedCourses.filter((c) => c.name !== courseName))
  }

  const allFeatures = Array.from(new Set(selectedCourses.flatMap((course) => course.features)))

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ type: "spring", duration: 0.5 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-7xl max-h-[90vh] overflow-y-auto"
          >
            <Card className="bg-white/95 backdrop-blur-md border-white/20 shadow-2xl">
              <CardHeader className="flex flex-row items-center justify-between pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg">
                    <Zap className="w-5 h-5 text-white" />
                  </div>
                  <CardTitle className="text-2xl font-bold">Course Comparison</CardTitle>
                </div>
                <Button variant="ghost" size="icon" onClick={onClose}>
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>

              <CardContent>
                {selectedCourses.length === 0 ? (
                  <div className="text-center py-16">
                    <Zap className="w-16 h-16 mx-auto mb-4 text-slate-400" />
                    <h3 className="text-xl font-semibold text-slate-600 mb-2">Start Comparing Courses</h3>
                    <p className="text-slate-500 mb-6">Select up to 3 courses to compare their features side by side</p>
                    <Button
                      onClick={() => setShowCourseSelector(true)}
                      className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Course to Compare
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* Add Course Button */}
                    {selectedCourses.length < 3 && (
                      <div className="flex justify-center">
                        <Button
                          variant="outline"
                          onClick={() => setShowCourseSelector(true)}
                          className="border-dashed border-2 border-blue-300 text-blue-600 hover:bg-blue-50"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Add Another Course ({selectedCourses.length}/3)
                        </Button>
                      </div>
                    )}

                    {/* Comparison Table */}
                    <div className="overflow-x-auto">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 min-w-full">
                        {selectedCourses.map((course, index) => (
                          <motion.div
                            key={course.name}
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="relative"
                          >
                            <Card className="h-full bg-gradient-to-br from-white to-blue-50 border-blue-200">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => removeCourse(course.name)}
                                className="absolute right-2 top-2 h-8 w-8 z-10"
                              >
                                <X className="w-4 h-4" />
                              </Button>

                              <CardHeader className="text-center pb-4">
                                <Avatar className="w-16 h-16 mx-auto mb-3">
                                  <AvatarImage src={course.image || "/placeholder.svg"} />
                                  <AvatarFallback className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-lg font-bold">
                                    {course.name
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("")}
                                  </AvatarFallback>
                                </Avatar>
                                <CardTitle className="text-lg">{course.name}</CardTitle>
                                <p className="text-sm text-slate-600">by {course.instructor}</p>
                                <Badge variant="secondary" className="mt-2">
                                  {course.category}
                                </Badge>
                              </CardHeader>

                              <CardContent className="space-y-4">
                                {/* Rating */}
                                <div className="flex items-center justify-center gap-2">
                                  <div className="flex items-center gap-1">
                                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                    <span className="font-medium">{course.rating}</span>
                                  </div>
                                  <div className="flex items-center gap-1 text-sm text-slate-500">
                                    <Users className="w-4 h-4" />
                                    <span>{course.students.toLocaleString()}</span>
                                  </div>
                                </div>

                                {/* Price */}
                                <div className="text-center">
                                  <div className="text-2xl font-bold text-primary">
                                    ₦{course.price.toLocaleString()}
                                  </div>
                                  {course.originalPrice && (
                                    <div className="text-sm text-slate-500 line-through">
                                      ₦{course.originalPrice.toLocaleString()}
                                    </div>
                                  )}
                                </div>

                                {/* Duration & Level */}
                                <div className="space-y-2 text-sm">
                                  <div className="flex items-center gap-2">
                                    <Clock className="w-4 h-4 text-blue-600" />
                                    <span>{course.duration}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Award className="w-4 h-4 text-green-600" />
                                    <span>{course.level}</span>
                                  </div>
                                </div>

                                {/* Features */}
                                <div className="space-y-2">
                                  <h4 className="font-medium text-sm">What's Included:</h4>
                                  <div className="space-y-1">
                                    {allFeatures.map((feature) => (
                                      <div key={feature} className="flex items-center gap-2 text-sm">
                                        {course.features.includes(feature) ? (
                                          <Check className="w-4 h-4 text-green-600" />
                                        ) : (
                                          <div className="w-4 h-4" />
                                        )}
                                        <span
                                          className={
                                            course.features.includes(feature) ? "text-slate-700" : "text-slate-400"
                                          }
                                        >
                                          {feature}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                </div>

                                <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                                  Choose This Course
                                </Button>
                              </CardContent>
                            </Card>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Course Selector Modal */}
                <AnimatePresence>
                  {showCourseSelector && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
                      onClick={() => setShowCourseSelector(false)}
                    >
                      <motion.div
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.9, opacity: 0 }}
                        onClick={(e) => e.stopPropagation()}
                        className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto"
                      >
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg font-semibold">Select a Course</h3>
                          <Button variant="ghost" size="icon" onClick={() => setShowCourseSelector(false)}>
                            <X className="w-4 h-4" />
                          </Button>
                        </div>

                        <div className="grid grid-cols-1 gap-4">
                          {availableCourses
                            .filter((course) => !selectedCourses.find((c) => c.name === course.name))
                            .map((course) => (
                              <Card
                                key={course.name}
                                className="cursor-pointer hover:shadow-md transition-shadow"
                                onClick={() => addCourse(course)}
                              >
                                <CardContent className="p-4">
                                  <div className="flex items-center gap-4">
                                    <Avatar>
                                      <AvatarImage src={course.image || "/placeholder.svg"} />
                                      <AvatarFallback className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
                                        {course.name
                                          .split(" ")
                                          .map((n) => n[0])
                                          .join("")}
                                      </AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1">
                                      <h4 className="font-medium">{course.name}</h4>
                                      <p className="text-sm text-slate-600">by {course.instructor}</p>
                                      <div className="flex items-center gap-4 mt-1">
                                        <div className="flex items-center gap-1">
                                          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                          <span className="text-sm">{course.rating}</span>
                                        </div>
                                        <span className="text-sm font-medium text-primary">
                                          ₦{course.price.toLocaleString()}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            ))}
                        </div>
                      </motion.div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
