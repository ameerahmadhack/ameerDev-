"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, Star, Quote } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const testimonials = [
  {
    id: 1,
    name: "Ibrahim Abdullahi",
    role: "Full-Stack Developer at Paystack",
    image: "/placeholder.svg?height=60&width=60",
    rating: 5,
    text: "BrightMind NG transformed my career completely. The Python course was so comprehensive that I landed my dream job at Paystack within 3 months of completion!",
    course: "Python Programming",
  },
  {
    id: 2,
    name: "Fatima Al-Zahra",
    role: "Frontend Developer at Flutterwave",
    image: "/placeholder.svg?height=60&width=60",
    rating: 5,
    text: "The React course exceeded my expectations. Ameer's teaching style is exceptional, and the practical projects prepared me for real-world development.",
    course: "React Development",
  },
  {
    id: 3,
    name: "Yusuf Hassan",
    role: "Data Scientist at Andela",
    image: "/placeholder.svg?height=60&width=60",
    rating: 5,
    text: "From zero to hero in Machine Learning! The course structure and hands-on approach made complex concepts easy to understand and implement.",
    course: "Machine Learning",
  },
  {
    id: 4,
    name: "Aisha Abdullahi",
    role: "UI/UX Designer at Kuda Bank",
    image: "/placeholder.svg?height=60&width=60",
    rating: 5,
    text: "The design courses at BrightMind NG are world-class. I learned Figma, design principles, and landed my first design role in just 4 months!",
    course: "Figma Design",
  },
  {
    id: 5,
    name: "Omar Suleiman",
    role: "Backend Developer at Interswitch",
    image: "/placeholder.svg?height=60&width=60",
    rating: 5,
    text: "The Node.js course was incredibly detailed. The instructor's industry experience really shows in the quality of content and real-world examples.",
    course: "Node.js Backend",
  },
]

export function TestimonialsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)

  useEffect(() => {
    if (!isAutoPlaying) return

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [isAutoPlaying])

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length)
    setIsAutoPlaying(false)
  }

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
    setIsAutoPlaying(false)
  }

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            What Our{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
              Students Say
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Join thousands of successful graduates who have transformed their careers with BrightMind NG
          </p>
        </motion.div>

        <div className="relative max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="bg-white/80 backdrop-blur-sm border-white/20 shadow-2xl">
                <CardContent className="p-8 md:p-12">
                  <div className="flex flex-col md:flex-row items-center gap-8">
                    <div className="flex-shrink-0">
                      <div className="relative">
                        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full blur-lg opacity-30"></div>
                        <Avatar className="relative w-24 h-24 border-4 border-white shadow-xl">
                          <AvatarImage src={testimonials[currentIndex].image || "/placeholder.svg"} />
                          <AvatarFallback className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
                            {testimonials[currentIndex].name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                      </div>
                    </div>

                    <div className="flex-1 text-center md:text-left">
                      <Quote className="w-8 h-8 text-blue-600 mb-4 mx-auto md:mx-0" />
                      <p className="text-lg md:text-xl text-slate-700 mb-6 leading-relaxed italic">
                        "{testimonials[currentIndex].text}"
                      </p>

                      <div className="flex items-center justify-center md:justify-start gap-1 mb-4">
                        {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                          <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>

                      <div>
                        <h4 className="font-bold text-lg text-slate-800">{testimonials[currentIndex].name}</h4>
                        <p className="text-slate-600 mb-2">{testimonials[currentIndex].role}</p>
                        <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                          {testimonials[currentIndex].course}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>

          {/* Navigation Buttons */}
          <Button
            variant="outline"
            size="icon"
            onClick={prevTestimonial}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 backdrop-blur-sm hover:bg-white shadow-lg"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>

          <Button
            variant="outline"
            size="icon"
            onClick={nextTestimonial}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 backdrop-blur-sm hover:bg-white shadow-lg"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>

          {/* Dots Indicator */}
          <div className="flex justify-center mt-8 gap-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => {
                  setCurrentIndex(index)
                  setIsAutoPlaying(false)
                }}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentIndex ? "bg-blue-600 w-8" : "bg-slate-300 hover:bg-slate-400"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
