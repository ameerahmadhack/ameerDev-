"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Search, X, Star, SlidersHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"

interface AdvancedSearchProps {
  isOpen: boolean
  onClose: () => void
  onSearch: (filters: SearchFilters) => void
}

interface SearchFilters {
  query: string
  categories: string[]
  priceRange: [number, number]
  rating: number
  duration: string[]
  level: string[]
}

const categories = [
  "Programming",
  "Web Development",
  "Frontend",
  "Backend",
  "Database",
  "Mobile",
  "Design",
  "AI/ML",
  "Cloud",
  "DevOps",
  "Security",
]

const durations = ["0-2 hours", "2-5 hours", "5-10 hours", "10+ hours"]
const levels = ["Beginner", "Intermediate", "Advanced", "Expert"]

export function AdvancedSearch({ isOpen, onClose, onSearch }: AdvancedSearchProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    query: "",
    categories: [],
    priceRange: [0, 100000],
    rating: 0,
    duration: [],
    level: [],
  })

  const handleCategoryToggle = (category: string) => {
    setFilters((prev) => ({
      ...prev,
      categories: prev.categories.includes(category)
        ? prev.categories.filter((c) => c !== category)
        : [...prev.categories, category],
    }))
  }

  const handleDurationToggle = (duration: string) => {
    setFilters((prev) => ({
      ...prev,
      duration: prev.duration.includes(duration)
        ? prev.duration.filter((d) => d !== duration)
        : [...prev.duration, duration],
    }))
  }

  const handleLevelToggle = (level: string) => {
    setFilters((prev) => ({
      ...prev,
      level: prev.level.includes(level) ? prev.level.filter((l) => l !== level) : [...prev.level, level],
    }))
  }

  const clearFilters = () => {
    setFilters({
      query: "",
      categories: [],
      priceRange: [0, 100000],
      rating: 0,
      duration: [],
      level: [],
    })
  }

  const applyFilters = () => {
    onSearch(filters)
    onClose()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ type: "spring", duration: 0.5 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-4xl max-h-[90vh] overflow-y-auto"
          >
            <Card className="bg-white/95 backdrop-blur-md border-white/20 shadow-2xl">
              <CardHeader className="flex flex-row items-center justify-between pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg">
                    <SlidersHorizontal className="w-5 h-5 text-white" />
                  </div>
                  <CardTitle className="text-2xl font-bold">Advanced Search</CardTitle>
                </div>
                <Button variant="ghost" size="icon" onClick={onClose}>
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>

              <CardContent className="space-y-8">
                {/* Search Query */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-slate-700">Search Query</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <Input
                      placeholder="Search courses, instructors, or topics..."
                      value={filters.query}
                      onChange={(e) => setFilters((prev) => ({ ...prev, query: e.target.value }))}
                      className="pl-10 h-12"
                    />
                  </div>
                </div>

                {/* Categories */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-slate-700">Categories</label>
                  <div className="flex flex-wrap gap-2">
                    {categories.map((category) => (
                      <Badge
                        key={category}
                        variant={filters.categories.includes(category) ? "default" : "outline"}
                        className="cursor-pointer hover:bg-blue-600 hover:text-white transition-colors"
                        onClick={() => handleCategoryToggle(category)}
                      >
                        {category}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Price Range */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-slate-700">
                    Price Range: ₦{filters.priceRange[0].toLocaleString()} - ₦{filters.priceRange[1].toLocaleString()}
                  </label>
                  <Slider
                    value={filters.priceRange}
                    onValueChange={(value) =>
                      setFilters((prev) => ({ ...prev, priceRange: value as [number, number] }))
                    }
                    max={100000}
                    min={0}
                    step={5000}
                    className="w-full"
                  />
                </div>

                {/* Rating */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-slate-700">Minimum Rating</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((rating) => (
                      <Button
                        key={rating}
                        variant={filters.rating >= rating ? "default" : "outline"}
                        size="sm"
                        onClick={() => setFilters((prev) => ({ ...prev, rating }))}
                        className="flex items-center gap-1"
                      >
                        <Star className="w-4 h-4" />
                        {rating}+
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Duration */}
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-slate-700">Duration</label>
                    <div className="space-y-2">
                      {durations.map((duration) => (
                        <div key={duration} className="flex items-center space-x-2">
                          <Checkbox
                            id={duration}
                            checked={filters.duration.includes(duration)}
                            onCheckedChange={() => handleDurationToggle(duration)}
                          />
                          <label htmlFor={duration} className="text-sm text-slate-600 cursor-pointer">
                            {duration}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Level */}
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-slate-700">Difficulty Level</label>
                    <div className="space-y-2">
                      {levels.map((level) => (
                        <div key={level} className="flex items-center space-x-2">
                          <Checkbox
                            id={level}
                            checked={filters.level.includes(level)}
                            onCheckedChange={() => handleLevelToggle(level)}
                          />
                          <label htmlFor={level} className="text-sm text-slate-600 cursor-pointer">
                            {level}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-4 pt-6 border-t">
                  <Button variant="outline" onClick={clearFilters} className="flex-1">
                    Clear All Filters
                  </Button>
                  <Button
                    onClick={applyFilters}
                    className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                  >
                    Apply Filters
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
