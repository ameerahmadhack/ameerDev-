import Image from "next/image"
import { Mail, Phone } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold text-center mb-8">About Us</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left Column: Company Information */}
        <div>
          <h2 className="text-2xl font-semibold mb-4">Our Story</h2>
          <p className="text-slate-700 mb-4">
            Founded in 2023, [Company Name] started with a simple vision: to provide high-quality software solutions to
            businesses of all sizes. We believe in innovation, collaboration, and a customer-centric approach.
          </p>
          <p className="text-slate-700 mb-4">
            Our team is composed of experienced developers, designers, and project managers who are passionate about
            creating impactful solutions. We are committed to staying ahead of the curve and delivering cutting-edge
            technology.
          </p>

          <h2 className="text-2xl font-semibold mt-6 mb-4">Our Mission</h2>
          <p className="text-slate-700">
            To empower businesses with innovative software solutions that drive growth and efficiency.
          </p>
        </div>

        {/* Right Column: Founder Information */}
        <div>
          <h2 className="text-2xl font-semibold mb-4">Meet the Founder</h2>
          <Image src="/images/ameer-ahmad.jpg" alt="Ameer Ahmad" width={300} height={300} className="rounded-lg mb-4" />
          <h3 className="text-xl font-semibold">Ameer Ahmad</h3>
          <p className="text-slate-700 mb-4">
            Ameer Ahmad is the founder and CEO of [Company Name]. With over 10 years of experience in the software
            industry, Ameer is passionate about building innovative solutions that solve real-world problems.
          </p>

          <h2 className="text-2xl font-semibold mt-6 mb-4">Contact Information</h2>
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <Mail className="w-5 h-5 text-blue-600" />
              <div>
                <p className="font-medium text-slate-800">Email</p>
                <a
                  href="mailto:ameerahmad@example.com"
                  className="text-slate-600 hover:text-blue-600 transition-colors"
                >
                  ameerahmad@example.com
                </a>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Phone className="w-5 h-5 text-blue-600" />
              <div>
                <p className="font-medium text-slate-800">Phone</p>
                <a href="tel:+2349014480971" className="text-slate-600 hover:text-blue-600 transition-colors">
                  +234 901 448 0971
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
