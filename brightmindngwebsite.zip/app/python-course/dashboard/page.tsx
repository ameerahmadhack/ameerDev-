"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { LogOut, BookOpen, Play, FileText, Download, CheckCircle, Clock, Award } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Image from "next/image"
import { useRouter } from "next/navigation"

const courseContent = [
  {
    day: 1,
    title: "The Basics of Python",
    completed: true,
    topics: [
      { name: "Python Overview", type: "video", duration: "15 min", completed: true },
      { name: "Python Introduction", type: "video", duration: "20 min", completed: true },
      { name: "Python Installing", type: "video", duration: "25 min", completed: true },
      { name: "Python Writing Code", type: "video", duration: "30 min", completed: true },
      { name: "Python Displaying Output", type: "video", duration: "15 min", completed: true },
      { name: "Python Statements", type: "notes", completed: true },
      { name: "Python Syntax", type: "notes", completed: true },
      { name: "Python Comments", type: "notes", completed: true },
    ],
  },
  {
    day: 2,
    title: "Python Data Fundamentals",
    completed: true,
    topics: [
      { name: "Python Variables", type: "video", duration: "25 min", completed: true },
      { name: "Python Data Types", type: "video", duration: "30 min", completed: true },
      { name: "Python Numbers", type: "video", duration: "20 min", completed: true },
      { name: "Python Number Methods", type: "notes", completed: true },
      { name: "Python Strings", type: "video", duration: "35 min", completed: true },
      { name: "Python String Methods", type: "notes", completed: true },
      { name: "Python Type Conversion", type: "video", duration: "20 min", completed: true },
      { name: "Python Booleans", type: "notes", completed: true },
    ],
  },
  {
    day: 3,
    title: "Python Operators",
    completed: false,
    current: true,
    topics: [
      { name: "Python Operators Intro", type: "video", duration: "20 min", completed: true },
      { name: "Python Arithmetic Operators", type: "video", duration: "25 min", completed: true },
      { name: "Python Assignment Operators", type: "video", duration: "20 min", completed: false, current: true },
      { name: "Python Comparison Operators", type: "video", duration: "25 min", completed: false },
      { name: "Python Logical Operators", type: "notes", completed: false },
      { name: "Python Identity Operators", type: "notes", completed: false },
      { name: "Python Membership Operators", type: "notes", completed: false },
    ],
  },
  // Add more days...
]

export default function CourseDashboard() {
  const [studentData, setStudentData] = useState({
    name: "Loading...",
    studentId: "",
    progress: 0,
    completedLessons: 0,
    totalLessons: 0,
  })
  const router = useRouter()

  useEffect(() => {
    // Get student data from localStorage or API
    const studentId = localStorage.getItem("studentId")
    if (!studentId) {
      router.push("/python-course/login")
      return
    }

    // Simulate fetching student data
    setStudentData({
      name: "Muhammad Ibrahim", // This would come from backend
      studentId: studentId,
      progress: 23,
      completedLessons: 18,
      totalLessons: 78,
    })
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("studentId")
    router.push("/python-course/login")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-blue-50/50 to-indigo-100/50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Image
                src="/images/brightmind-logo.png"
                alt="BrightMind NG Logo"
                width={40}
                height={40}
                className="rounded-lg"
              />
              <div>
                <h1 className="text-xl font-bold text-slate-800">Python Course</h1>
                <p className="text-sm text-slate-600">Welcome back, {studentData.name}!</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="hidden md:flex">
                ID: {studentData.studentId}
              </Badge>
              <Button variant="outline" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Progress Overview */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Course Progress</p>
                    <p className="text-3xl font-bold">{studentData.progress}%</p>
                  </div>
                  <BookOpen className="w-8 h-8 text-blue-200" />
                </div>
                <Progress value={studentData.progress} className="mt-4 bg-blue-500" />
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-600 to-emerald-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Completed Lessons</p>
                    <p className="text-3xl font-bold">
                      {studentData.completedLessons}/{studentData.totalLessons}
                    </p>
                  </div>
                  <CheckCircle className="w-8 h-8 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Days Completed</p>
                    <p className="text-3xl font-bold">2/13</p>
                  </div>
                  <Award className="w-8 h-8 text-purple-200" />
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.section>

        {/* Course Content */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <Tabs defaultValue="lessons" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="lessons">Course Lessons</TabsTrigger>
              <TabsTrigger value="notes">Notes & Resources</TabsTrigger>
              <TabsTrigger value="projects">Projects</TabsTrigger>
            </TabsList>

            <TabsContent value="lessons" className="space-y-6">
              {courseContent.map((day, index) => (
                <motion.div
                  key={day.day}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card
                    className={`${day.current ? "border-blue-500 bg-blue-50/50" : ""} ${day.completed ? "border-green-500 bg-green-50/50" : ""}`}
                  >
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
                              day.completed ? "bg-green-500" : day.current ? "bg-blue-500" : "bg-slate-400"
                            }`}
                          >
                            {day.completed ? <CheckCircle className="w-5 h-5" /> : day.day}
                          </div>
                          <div>
                            <CardTitle className="text-lg">
                              Day {day.day}: {day.title}
                            </CardTitle>
                            <CardDescription>
                              {day.completed ? "Completed" : day.current ? "In Progress" : "Locked"}
                            </CardDescription>
                          </div>
                        </div>
                        {day.current && <Badge className="bg-blue-100 text-blue-700">Current</Badge>}
                        {day.completed && <Badge className="bg-green-100 text-green-700">Completed</Badge>}
                      </div>
                    </CardHeader>

                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {day.topics.map((topic, topicIndex) => (
                          <div
                            key={topicIndex}
                            className={`flex items-center gap-3 p-3 rounded-lg border ${
                              topic.completed
                                ? "bg-green-50 border-green-200"
                                : topic.current
                                  ? "bg-blue-50 border-blue-200"
                                  : "bg-slate-50 border-slate-200"
                            }`}
                          >
                            <div
                              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                topic.completed
                                  ? "bg-green-500 text-white"
                                  : topic.current
                                    ? "bg-blue-500 text-white"
                                    : "bg-slate-300 text-slate-600"
                              }`}
                            >
                              {topic.completed ? (
                                <CheckCircle className="w-4 h-4" />
                              ) : topic.type === "video" ? (
                                <Play className="w-4 h-4" />
                              ) : (
                                <FileText className="w-4 h-4" />
                              )}
                            </div>
                            <div className="flex-1">
                              <p className="font-medium text-sm">{topic.name}</p>
                              {topic.duration && <p className="text-xs text-muted-foreground">{topic.duration}</p>}
                            </div>
                            {(topic.completed || topic.current) && (
                              <Button size="sm" variant="ghost">
                                {topic.type === "video" ? "Watch" : "Read"}
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </TabsContent>

            <TabsContent value="notes" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Course Notes & Resources</CardTitle>
                  <CardDescription>Download study materials and code examples</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-3 p-4 border rounded-lg">
                      <FileText className="w-8 h-8 text-blue-600" />
                      <div className="flex-1">
                        <p className="font-medium">Python Basics Notes</p>
                        <p className="text-sm text-muted-foreground">Complete guide to Python fundamentals</p>
                      </div>
                      <Button size="sm" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </div>
                    <div className="flex items-center gap-3 p-4 border rounded-lg">
                      <FileText className="w-8 h-8 text-green-600" />
                      <div className="flex-1">
                        <p className="font-medium">Code Examples</p>
                        <p className="text-sm text-muted-foreground">Practical Python code samples</p>
                      </div>
                      <Button size="sm" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="projects" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Course Projects</CardTitle>
                  <CardDescription>Build real-world applications to practice your skills</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-4 border rounded-lg">
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white">
                        <CheckCircle className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">Calculator App</p>
                        <p className="text-sm text-muted-foreground">Build a simple calculator using Python</p>
                      </div>
                      <Badge className="bg-green-100 text-green-700">Completed</Badge>
                    </div>
                    <div className="flex items-center gap-3 p-4 border rounded-lg">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white">
                        <Clock className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">To-Do List App</p>
                        <p className="text-sm text-muted-foreground">Create a task management application</p>
                      </div>
                      <Badge className="bg-blue-100 text-blue-700">In Progress</Badge>
                    </div>
                    <div className="flex items-center gap-3 p-4 border rounded-lg opacity-60">
                      <div className="w-8 h-8 bg-slate-300 rounded-full flex items-center justify-center text-slate-600">
                        3
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">Web Scraper</p>
                        <p className="text-sm text-muted-foreground">Extract data from websites</p>
                      </div>
                      <Badge variant="outline">Locked</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.section>
      </div>
    </div>
  )
}
