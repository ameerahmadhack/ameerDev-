"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, ArrowRight, BookOpen, Play, CheckCircle, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import Image from "next/image"
import { useParams, useRouter } from "next/navigation"

const lessonContent = {
  "1": {
    "python-overview": {
      title: "Python Overview",
      type: "video",
      duration: "15 min",
      content: `
# Python Overview

## What is Python?

Python is a high-level, interpreted programming language known for its simplicity and readability. Created by Guido van Rossum and first released in 1991, Python has become one of the most popular programming languages in the world.

## Why Learn Python?

### 1. **Easy to Learn and Use**
- Simple, clean syntax that resembles natural language
- Beginner-friendly with a gentle learning curve
- Less code required compared to other languages

### 2. **Versatile and Powerful**
- Web development (Django, Flask)
- Data science and analytics
- Machine learning and AI
- Automation and scripting
- Desktop applications

### 3. **Large Community and Libraries**
- Extensive standard library
- Thousands of third-party packages
- Active community support
- Comprehensive documentation

### 4. **High Demand in Job Market**
- One of the most sought-after programming skills
- High salary potential
- Used by major companies like Google, Netflix, Instagram

## Python Applications

### Web Development
Python frameworks like Django and Flask make web development fast and efficient.

### Data Science
Libraries like NumPy, Pandas, and Matplotlib make Python perfect for data analysis.

### Machine Learning
TensorFlow, PyTorch, and scikit-learn enable powerful AI applications.

### Automation
Python excels at automating repetitive tasks and system administration.

## Getting Started

In the next lessons, we'll cover:
1. Installing Python on your computer
2. Setting up your development environment
3. Writing your first Python program
4. Understanding Python syntax and structure

## Key Takeaways

- Python is beginner-friendly yet powerful
- It's used across many industries and applications
- Learning Python opens doors to numerous career opportunities
- The syntax is clean and readable
- Strong community and ecosystem support

Ready to start your Python journey? Let's move on to the next lesson!
      `,
      videoUrl: "https://example.com/python-overview-video",
      nextLesson: { day: "1", topic: "python-introduction" },
      prevLesson: null,
    },
    "python-introduction": {
      title: "Python Introduction",
      type: "video",
      duration: "20 min",
      content: `
# Python Introduction

## History of Python

Python was created by **Guido van Rossum** in the late 1980s and was first released in 1991. The name "Python" comes from the British comedy series "Monty Python's Flying Circus," not from the snake!

## Python Philosophy

Python follows the principle of **"The Zen of Python"** which emphasizes:

- Beautiful is better than ugly
- Explicit is better than implicit
- Simple is better than complex
- Readability counts
- There should be one obvious way to do it

## Python Versions

### Python 2 vs Python 3
- **Python 2**: Released in 2000, officially discontinued in 2020
- **Python 3**: Released in 2008, current version with active development
- **We'll be using Python 3** throughout this course

### Current Python 3 Versions
- Python 3.9, 3.10, 3.11, 3.12 are currently supported
- We recommend using Python 3.10 or newer

## Python Features

### 1. **Interpreted Language**
- No need to compile before running
- Code is executed line by line
- Interactive development possible

### 2. **Cross-Platform**
- Runs on Windows, macOS, Linux
- Write once, run anywhere

### 3. **Object-Oriented**
- Supports classes and objects
- Inheritance and polymorphism
- But also supports procedural programming

### 4. **Dynamic Typing**
- Variables don't need type declarations
- Types are determined at runtime
- More flexible but requires careful coding

### 5. **Extensive Libraries**
- Rich standard library
- Package Index (PyPI) with 400,000+ packages
- Libraries for almost any task

## Python Syntax Preview

Here's what Python code looks like:

\`\`\`python
# This is a comment
print("Hello, World!")

# Variables
name = "Muhammad"
age = 25

# Functions
def greet(person):
    return f"Hello, {person}!"

# Using the function
message = greet(name)
print(message)
\`\`\`

Notice how clean and readable it is!

## What Makes Python Special?

### Readability
Python code is designed to be readable. Compare these examples:

**Java:**
\`\`\`java
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
\`\`\`

**Python:**
\`\`\`python
print("Hello, World!")
\`\`\`

### Indentation
Python uses indentation (spaces/tabs) to define code blocks instead of curly braces:

\`\`\`python
if age >= 18:
    print("You are an adult")
    print("You can vote")
else:
    print("You are a minor")
\`\`\`

## Career Opportunities

Learning Python opens doors to:

- **Software Developer**: Building applications and systems
- **Data Scientist**: Analyzing data and building models
- **Web Developer**: Creating websites and web applications
- **DevOps Engineer**: Automating infrastructure and deployments
- **Machine Learning Engineer**: Building AI systems
- **Automation Engineer**: Creating scripts and tools

## Next Steps

In our next lesson, we'll install Python on your computer and set up your development environment. Get ready to write your first Python program!

## Summary

- Python is a powerful, beginner-friendly programming language
- Created by Guido van Rossum, first released in 1991
- Known for clean, readable syntax
- Versatile - used in web development, data science, AI, and more
- Strong job market demand
- We'll use Python 3 in this course
      `,
      videoUrl: "https://example.com/python-introduction-video",
      nextLesson: { day: "1", topic: "python-installing" },
      prevLesson: { day: "1", topic: "python-overview" },
    },
  },
}

export default function LessonPage() {
  const params = useParams()
  const router = useRouter()
  const [isCompleted, setIsCompleted] = useState(false)
  const [studentName, setStudentName] = useState("Muhammad Ibrahim")

  const day = params.day as string
  const topic = params.topic as string

  const lesson = lessonContent[day]?.[topic]

  useEffect(() => {
    // Check if student is logged in
    const studentId = localStorage.getItem("studentId")
    if (!studentId) {
      router.push("/python-course/login")
      return
    }

    // Load completion status from localStorage or API
    const completionKey = `lesson_${day}_${topic}_completed`
    setIsCompleted(localStorage.getItem(completionKey) === "true")
  }, [day, topic, router])

  const markAsCompleted = () => {
    const completionKey = `lesson_${day}_${topic}_completed`
    localStorage.setItem(completionKey, "true")
    setIsCompleted(true)
  }

  if (!lesson) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-800 mb-4">Lesson Not Found</h1>
          <Button asChild>
            <Link href="/python-course/dashboard">Back to Dashboard</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-blue-50/50 to-indigo-100/50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Image
                src="/images/brightmind-logo.png"
                alt="BrightMind NG Logo"
                width={40}
                height={40}
                className="rounded-lg"
              />
              <div>
                <h1 className="text-xl font-bold text-slate-800">Python Course</h1>
                <p className="text-sm text-slate-600">Welcome back, {studentName}!</p>
              </div>
            </div>

            <Button variant="outline" asChild>
              <Link href="/python-course/dashboard">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Lesson Header */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-4">
            <Badge className="bg-blue-100 text-blue-700">Day {day}</Badge>
            <Badge variant="outline">{lesson.type === "video" ? "Video Lesson" : "Reading"}</Badge>
            {lesson.duration && <Badge variant="outline">{lesson.duration}</Badge>}
            {isCompleted && <Badge className="bg-green-100 text-green-700">Completed</Badge>}
          </div>

          <h1 className="text-4xl font-bold text-slate-800 mb-4">{lesson.title}</h1>

          <div className="flex items-center gap-4">
            <Progress value={isCompleted ? 100 : 0} className="flex-1 max-w-md" />
            <span className="text-sm text-muted-foreground">{isCompleted ? "Completed" : "In Progress"}</span>
          </div>
        </motion.section>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-3"
          >
            <Card className="bg-white/80 backdrop-blur-sm border-white/20">
              <CardContent className="p-8">
                {lesson.type === "video" && (
                  <div className="mb-8">
                    <div className="aspect-video bg-slate-900 rounded-lg flex items-center justify-center mb-4">
                      <div className="text-center text-white">
                        <Play className="w-16 h-16 mx-auto mb-4" />
                        <p className="text-lg">Video Player</p>
                        <p className="text-sm text-slate-300">Duration: {lesson.duration}</p>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                        <Play className="w-4 h-4 mr-2" />
                        Play Video
                      </Button>
                      <Button variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                )}

                {/* Lesson Content */}
                <div className="prose prose-slate max-w-none">
                  <div
                    dangerouslySetInnerHTML={{
                      __html: lesson.content
                        .replace(/\n/g, "<br>")
                        .replace(/#{1,6}\s/g, (match) => {
                          const level = match.trim().length
                          return `<h${level} class="text-${4 - level}xl font-bold text-slate-800 mt-8 mb-4">`
                        })
                        .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
                        .replace(
                          /```python\n([\s\S]*?)\n```/g,
                          '<pre class="bg-slate-900 text-green-400 p-4 rounded-lg overflow-x-auto"><code>$1</code></pre>',
                        )
                        .replace(
                          /```(.*?)\n([\s\S]*?)\n```/g,
                          '<pre class="bg-slate-100 p-4 rounded-lg overflow-x-auto"><code>$2</code></pre>',
                        )
                        .replace(/`(.*?)`/g, '<code class="bg-slate-100 px-2 py-1 rounded text-sm">$1</code>'),
                    }}
                  />
                </div>

                {/* Completion Button */}
                {!isCompleted && (
                  <div className="mt-8 pt-8 border-t">
                    <Button
                      onClick={markAsCompleted}
                      className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Mark as Completed
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="lg:col-span-1"
          >
            <Card className="bg-white/80 backdrop-blur-sm border-white/20 sticky top-24">
              <CardHeader>
                <CardTitle className="text-lg">Lesson Navigation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {lesson.prevLesson && (
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href={`/python-course/lesson/${lesson.prevLesson.day}/${lesson.prevLesson.topic}`}>
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Previous Lesson
                    </Link>
                  </Button>
                )}

                {lesson.nextLesson && (
                  <Button
                    className="w-full justify-start bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                    asChild
                  >
                    <Link href={`/python-course/lesson/${lesson.nextLesson.day}/${lesson.nextLesson.topic}`}>
                      Next Lesson
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                  </Button>
                )}

                <Button variant="outline" className="w-full" asChild>
                  <Link href="/python-course/dashboard">
                    <BookOpen className="w-4 h-4 mr-2" />
                    Course Overview
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
