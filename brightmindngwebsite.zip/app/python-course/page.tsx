"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Clock, Users, Award, Star, BookOpen, Code } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import Image from "next/image"
import { ThemeToggle } from "@/components/theme-toggle"
import { MobileNav } from "@/components/mobile-nav"
import { FloatingElements } from "@/components/floating-elements"
import { PaymentModal } from "@/components/python-course/payment-modal"

const courseFeatures = [
  "13 Days Comprehensive Learning",
  "Hands-on Practical Examples",
  "Real-world Projects",
  "Lifetime Access",
  "Certificate of Completion",
  "Community Support",
  "Mobile Access",
  "Download Resources",
]

const courseOutline = [
  {
    day: 1,
    title: "The Basics of Python",
    topics: [
      "Python Overview",
      "Python Introduction",
      "Python Installing",
      "Python Writing Code",
      "Python Displaying Output",
      "Python Statements",
      "Python Syntax",
      "Python Comments",
    ],
  },
  {
    day: 2,
    title: "Python Data Fundamentals",
    topics: [
      "Python Variables",
      "Python Data Types",
      "Python Numbers",
      "Python Number Methods",
      "Python Strings",
      "Python String Methods",
      "Python Type Conversion",
      "Python Booleans",
    ],
  },
  {
    day: 3,
    title: "Python Operators",
    topics: [
      "Python Operators Intro",
      "Python Arithmetic Operators",
      "Python Assignment Operators",
      "Python Comparison Operators",
      "Python Logical Operators",
      "Python Identity Operators",
      "Python Membership Operators",
    ],
  },
  {
    day: 4,
    title: "Python Collections",
    topics: [
      "Python Collections",
      "Python Containers",
      "Python List",
      "Python Tuple",
      "Python Set",
      "Python Dictionary",
    ],
  },
  {
    day: 5,
    title: "Python Flow Control",
    topics: [
      "Python Flow Control",
      "Python Functions",
      "Python Lambda Functions",
      "Python if...else Statements",
      "Python if...else Shorthand",
      "Python for Loop",
      "Python while Loop",
      "Python break and continue",
      "Python pass Statement",
    ],
  },
  {
    day: 6,
    title: "Python Advanced Concepts",
    topics: [
      "Python Advanced",
      "Python Classes and Objects",
      "Python Inheritance",
      "Python Variable Scope",
      "Python Formatting Strings",
      "Python try..except",
      "Python Iterators",
      "Python User Input",
    ],
  },
  {
    day: 7,
    title: "Python Modules",
    topics: [
      "Python Modules Intro",
      "Python Math",
      "Python Random",
      "Python Date and Time",
      "Python JSON",
      "Python Regular Expressions",
    ],
  },
  {
    day: 8,
    title: "Python File Operations",
    topics: [
      "Python Working with Files",
      "Python File Handling",
      "Python File Reading",
      "Python File Writing/Creating",
      "Python File Deleting",
    ],
  },
  {
    day: 9,
    title: "Python NumPy",
    topics: [
      "Python NumPy Intro",
      "Python NumPy Arrays",
      "Python Array Indexing",
      "Python Array Slicing",
      "Python NumPy Data Types",
      "Python NumPy Iterate",
      "Python NumPy Join",
      "Python NumPy Search",
      "Python NumPy Sort",
    ],
  },
  {
    day: 10,
    title: "Python Pandas",
    topics: [
      "Python Pandas Intro",
      "Python DataFrames",
      "Python Data Analysis",
      "Python Data Cleaning",
      "Python Data Visualization",
    ],
  },
  {
    day: 11,
    title: "Python Web Development",
    topics: ["Python Flask Introduction", "Python Web Applications", "Python APIs", "Python Database Integration"],
  },
  {
    day: 12,
    title: "Python Best Practices",
    topics: [
      "Python Code Organization",
      "Python Testing",
      "Python Debugging",
      "Python Performance Optimization",
      "Python Deployment",
    ],
  },
  {
    day: 13,
    title: "Final Project",
    topics: [
      "Project Planning",
      "Building a Complete Application",
      "Code Review",
      "Project Presentation",
      "Certificate Generation",
    ],
  },
]

export default function PythonCoursePage() {
  const [showPaymentModal, setShowPaymentModal] = useState(false)

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-blue-50/50 to-indigo-100/50 dark:from-background dark:via-slate-900/50 dark:to-slate-800/50 relative">
      <FloatingElements />

      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-3"
            >
              <Image
                src="/images/brightmind-logo.png"
                alt="BrightMind NG Logo"
                width={50}
                height={50}
                className="rounded-lg"
              />
              <div>
                <h1 className="text-2xl font-bold text-slate-800">BrightMind NG</h1>
                <p className="text-sm text-slate-600">Illuminate Your Future</p>
              </div>
            </motion.div>

            <div className="flex items-center space-x-4">
              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                  Home
                </Link>
                <Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">
                  About
                </Link>
                <Link href="/categories" className="text-muted-foreground hover:text-primary transition-colors">
                  Categories
                </Link>
              </nav>
              <ThemeToggle />
              <MobileNav />
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="mb-8">
          <Button variant="ghost" asChild>
            <Link href="/" className="flex items-center space-x-2">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Courses</span>
            </Link>
          </Button>
        </motion.div>

        {/* Course Hero Section */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-green-100 text-green-700">Beginner Friendly</Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-slate-800 mb-6">
                Python Programming
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
                  {" "}
                  for Beginners
                </span>
              </h1>
              <p className="text-xl text-slate-600 mb-8 leading-relaxed">
                Master Python from absolute basics to advanced concepts in just 13 days. Build real projects, learn
                industry best practices, and start your programming journey with confidence.
              </p>

              <div className="flex flex-wrap gap-6 mb-8">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <span className="text-slate-700">13 Days Course</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <span className="text-slate-700">1,250+ Students</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  <span className="text-slate-700">4.9 Rating</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Award className="w-5 h-5 text-blue-600" />
                  <span className="text-slate-700">Certificate</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
                  onClick={() => setShowPaymentModal(true)}
                >
                  Enroll Now - ₦25,000
                </Button>
                <Button variant="outline" size="lg">
                  Preview Course
                </Button>
              </div>
            </div>

            <div className="relative">
              <motion.div whileHover={{ scale: 1.05 }} transition={{ duration: 0.3 }} className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur-lg opacity-20"></div>
                <div className="relative bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl p-8 text-white">
                  <Code className="w-16 h-16 mb-6" />
                  <h3 className="text-2xl font-bold mb-4">What You'll Build</h3>
                  <ul className="space-y-2">
                    <li>• Personal Portfolio Website</li>
                    <li>• Data Analysis Dashboard</li>
                    <li>• Web Scraping Tool</li>
                    <li>• API Integration Project</li>
                    <li>• Final Capstone Project</li>
                  </ul>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.section>

        {/* Course Features */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-16"
        >
          <h2 className="text-3xl font-bold text-center text-slate-800 mb-12">What's Included</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {courseFeatures.map((feature, index) => (
              <motion.div
                key={feature}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="text-center bg-white/80 backdrop-blur-sm border-white/20 hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <BookOpen className="w-6 h-6 text-white" />
                    </div>
                    <p className="font-medium text-slate-700">{feature}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Course Outline */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mb-16"
        >
          <h2 className="text-3xl font-bold text-center text-slate-800 mb-12">13-Day Course Outline</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courseOutline.map((day, index) => (
              <motion.div
                key={day.day}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <Card className="h-full bg-white/80 backdrop-blur-sm border-white/20 hover:shadow-xl transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center text-white font-bold">
                        {day.day}
                      </div>
                      <Badge variant="outline">Day {day.day}</Badge>
                    </div>
                    <CardTitle className="text-lg">{day.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {day.topics.map((topic, topicIndex) => (
                        <li key={topicIndex} className="flex items-center gap-2 text-sm text-slate-600">
                          <div className="w-1.5 h-1.5 bg-blue-600 rounded-full" />
                          {topic}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Instructor Section */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mb-16"
        >
          <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
            <CardContent className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                  <h2 className="text-3xl font-bold mb-4">Meet Your Instructor</h2>
                  <h3 className="text-2xl font-semibold mb-2">Ameer Ahmad</h3>
                  <p className="text-blue-100 mb-4">Founder & Lead Python Instructor</p>
                  <p className="text-blue-50 leading-relaxed mb-6">
                    With over 8 years of experience in Python development and education, Ameer has taught thousands of
                    students and helped them launch successful careers in tech. His practical approach and real-world
                    examples make complex concepts easy to understand.
                  </p>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                      <span>4.9 Rating</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-5 h-5" />
                      <span>15,000+ Students</span>
                    </div>
                  </div>
                </div>
                <div className="flex justify-center">
                  <div className="relative">
                    <div className="absolute inset-0 bg-white rounded-2xl blur-lg opacity-20"></div>
                    <Image
                      src="/images/founder.jpeg"
                      alt="Ameer Ahmad - Python Instructor"
                      width={300}
                      height={400}
                      className="relative rounded-2xl shadow-2xl object-cover"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* Enrollment CTA */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="text-center"
        >
          <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-green-200">
            <CardContent className="p-12">
              <h2 className="text-4xl font-bold text-slate-800 mb-4">Ready to Start Your Python Journey?</h2>
              <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
                Join 1,250+ students who have successfully learned Python and transformed their careers. Start building
                real projects from day one!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
                <div className="text-3xl font-bold text-green-600">₦25,000</div>
                <div className="text-lg text-slate-500 line-through">₦35,000</div>
                <Badge className="bg-green-100 text-green-700">Save ₦10,000</Badge>
              </div>
              <Button
                size="lg"
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white text-lg px-8 py-4"
                onClick={() => setShowPaymentModal(true)}
              >
                Enroll Now & Start Learning
              </Button>
              <p className="text-sm text-slate-500 mt-4">30-day money-back guarantee</p>
            </CardContent>
          </Card>
        </motion.section>
      </div>

      {/* Payment Modal */}
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        course={{
          name: "Python Programming for Beginners",
          instructor: "Ameer Ahmad",
          price: 25000,
          originalPrice: 35000,
        }}
      />
    </div>
  )
}
