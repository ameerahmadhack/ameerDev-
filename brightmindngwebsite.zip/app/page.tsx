"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Search, BookOpen, Users, Award, Star, Filter } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import Image from "next/image"
import { ThemeToggle } from "@/components/theme-toggle"
import { MobileNav } from "@/components/mobile-nav"
import { FloatingElements } from "@/components/floating-elements"
import { TestimonialsCarousel } from "@/components/testimonials-carousel"
import { NewsletterModal } from "@/components/newsletter-modal"
import { InstructorProfiles } from "@/components/instructor-profiles"
import { AdvancedSearch } from "@/components/advanced-search"
import { LearningPathRecommendations } from "@/components/learning-path-recommendations"
import { CourseComparison } from "@/components/course-comparison"
import { LiveChatAI } from "@/components/live-chat-ai"
import { CourseReviews } from "@/components/course-reviews"

const courses = [
  {
    name: "Python Programming",
    instructor: "Ameer Ahmad",
    description: "Master Python from basics to advanced concepts",
    url: "/python.php",
    category: "Programming",
    rating: 4.9,
    students: 1250,
    price: 25000,
    originalPrice: 35000,
  },
  {
    name: "JavaScript Essentials",
    instructor: "Fatima Al-Zahra",
    description: "Modern JavaScript and ES6+ features",
    url: "/javascript.php",
    category: "Web Development",
    rating: 4.8,
    students: 980,
    price: 22000,
    originalPrice: 30000,
  },
  {
    name: "React Development",
    instructor: "Abdullah Hassan",
    description: "Build modern web apps with React",
    url: "/react.php",
    category: "Frontend",
    rating: 4.9,
    students: 1100,
    price: 28000,
    originalPrice: 38000,
  },
  {
    name: "Node.js Backend",
    instructor: "Yusuf Ibrahim",
    description: "Server-side development with Node.js",
    url: "/nodejs.php",
    category: "Backend",
    rating: 4.7,
    students: 850,
    price: 24000,
    originalPrice: 32000,
  },
  {
    name: "PHP Web Development",
    instructor: "Khadijah Usman",
    description: "Dynamic web applications with PHP",
    url: "/php.php",
    category: "Web Development",
    rating: 4.6,
    students: 720,
    price: 20000,
    originalPrice: 28000,
  },
  {
    name: "MySQL Database",
    instructor: "Omar Suleiman",
    description: "Database design and management",
    url: "/mysql.php",
    category: "Database",
    rating: 4.8,
    students: 650,
    price: 23000,
    originalPrice: 31000,
  },
  {
    name: "HTML5 & CSS3",
    instructor: "Aisha Abdullahi",
    description: "Modern web markup and styling",
    url: "/html-css.php",
    category: "Frontend",
    rating: 4.7,
    students: 1300,
    price: 21000,
    originalPrice: 29000,
  },
  {
    name: "Java Programming",
    instructor: "Muhammad Tariq",
    description: "Object-oriented programming with Java",
    url: "/java.php",
    category: "Programming",
    rating: 4.8,
    students: 900,
    price: 26000,
    originalPrice: 34000,
  },
  {
    name: "C++ Fundamentals",
    instructor: "Bilal Ahmed",
    description: "System programming with C++",
    url: "/cpp.php",
    category: "Programming",
    rating: 4.6,
    students: 600,
    price: 19000,
    originalPrice: 27000,
  },
  {
    name: "Data Structures",
    instructor: "Zainab Musa",
    description: "Essential data structures and algorithms",
    url: "/data-structures.php",
    category: "Computer Science",
    rating: 4.9,
    students: 750,
    price: 27000,
    originalPrice: 36000,
  },
  {
    name: "Machine Learning",
    instructor: "Dr. Hamza Ali",
    description: "AI and ML fundamentals",
    url: "/machine-learning.php",
    category: "AI/ML",
    rating: 4.9,
    students: 550,
    price: 30000,
    originalPrice: 40000,
  },
  {
    name: "Web Design",
    instructor: "Hafsa Yusuf",
    description: "UI/UX design principles",
    url: "/web-design.php",
    category: "Design",
    rating: 4.7,
    students: 800,
    price: 22000,
    originalPrice: 30000,
  },
  {
    name: "MongoDB",
    instructor: "Ali Khan",
    description: "NoSQL database management",
    url: "/mongodb.php",
    category: "Database",
    rating: 4.6,
    students: 450,
    price: 18000,
    originalPrice: 26000,
  },
  {
    name: "Vue.js Framework",
    instructor: "Maryam Saeed",
    description: "Progressive JavaScript framework",
    url: "/vuejs.php",
    category: "Frontend",
    rating: 4.8,
    students: 520,
    price: 24000,
    originalPrice: 32000,
  },
  {
    name: "Angular Development",
    instructor: "Ibrahim Khalil",
    description: "Enterprise web applications",
    url: "/angular.php",
    category: "Frontend",
    rating: 4.7,
    students: 480,
    price: 23000,
    originalPrice: 31000,
  },
  {
    name: "Django Framework",
    instructor: "Sumayya Abbas",
    description: "Python web framework",
    url: "/django.php",
    category: "Backend",
    rating: 4.8,
    students: 420,
    price: 25000,
    originalPrice: 33000,
  },
  {
    name: "Laravel PHP",
    instructor: "Hamza Rashid",
    description: "Modern PHP framework",
    url: "/laravel.php",
    category: "Backend",
    rating: 4.7,
    students: 380,
    price: 22000,
    originalPrice: 30000,
  },
  {
    name: "Git & GitHub",
    instructor: "Nadia Ashraf",
    description: "Version control mastery",
    url: "/git.php",
    category: "Tools",
    rating: 4.9,
    students: 1200,
    price: 15000,
    originalPrice: 20000,
  },
  {
    name: "Docker Containers",
    instructor: "Osman Faruq",
    description: "Containerization and deployment",
    url: "/docker.php",
    category: "DevOps",
    rating: 4.8,
    students: 350,
    price: 17000,
    originalPrice: 24000,
  },
  {
    name: "AWS Cloud",
    instructor: "Amina Zubair",
    description: "Amazon Web Services fundamentals",
    url: "/aws.php",
    category: "Cloud",
    rating: 4.9,
    students: 600,
    price: 28000,
    originalPrice: 38000,
  },
  {
    name: "Cybersecurity",
    instructor: "Dr. Aisha Khan",
    description: "Information security principles",
    url: "/cybersecurity.php",
    category: "Security",
    rating: 4.8,
    students: 400,
    price: 26000,
    originalPrice: 35000,
  },
  {
    name: "Blockchain",
    instructor: "Ahmed Raza",
    description: "Distributed ledger technology",
    url: "/blockchain.php",
    category: "Emerging Tech",
    rating: 4.7,
    students: 300,
    price: 24000,
    originalPrice: 32000,
  },
  {
    name: "Flutter Mobile",
    instructor: "Safiya Malik",
    description: "Cross-platform mobile development",
    url: "/flutter.php",
    category: "Mobile",
    rating: 4.8,
    students: 450,
    price: 22000,
    originalPrice: 30000,
  },
  {
    name: "React Native",
    instructor: "Yusra Khan",
    description: "Native mobile apps with React",
    url: "/react-native.php",
    category: "Mobile",
    rating: 4.7,
    students: 380,
    price: 21000,
    originalPrice: 29000,
  },
  {
    name: "Swift iOS",
    instructor: "Zayd Hassan",
    description: "iOS app development",
    url: "/swift.php",
    category: "Mobile",
    rating: 4.8,
    students: 320,
    price: 23000,
    originalPrice: 31000,
  },
  {
    name: "Kotlin Android",
    instructor: "Layla Noor",
    description: "Modern Android development",
    url: "/kotlin.php",
    category: "Mobile",
    rating: 4.7,
    students: 290,
    price: 20000,
    originalPrice: 28000,
  },
  {
    name: "Unity Game Dev",
    instructor: "Rayan Shahid",
    description: "Game development with Unity",
    url: "/unity.php",
    category: "Game Dev",
    rating: 4.9,
    students: 500,
    price: 27000,
    originalPrice: 36000,
  },
  {
    name: "Unreal Engine",
    instructor: "Hana Ali",
    description: "Advanced game development",
    url: "/unreal.php",
    category: "Game Dev",
    rating: 4.8,
    students: 250,
    price: 25000,
    originalPrice: 33000,
  },
  {
    name: "Photoshop",
    instructor: "Imran Patel",
    description: "Digital image editing",
    url: "/photoshop.php",
    category: "Design",
    rating: 4.6,
    students: 700,
    price: 19000,
    originalPrice: 27000,
  },
  {
    name: "Illustrator",
    instructor: "Aaliyah Khan",
    description: "Vector graphics design",
    url: "/illustrator.php",
    category: "Design",
    rating: 4.7,
    students: 550,
    price: 21000,
    originalPrice: 29000,
  },
  {
    name: "Figma Design",
    instructor: "Zubair Ahmed",
    description: "UI/UX design tool mastery",
    url: "/figma.php",
    category: "Design",
    rating: 4.8,
    students: 650,
    price: 23000,
    originalPrice: 31000,
  },
  {
    name: "After Effects",
    instructor: "Sana Khan",
    description: "Motion graphics and animation",
    url: "/after-effects.php",
    category: "Design",
    rating: 4.7,
    students: 400,
    price: 22000,
    originalPrice: 30000,
  },
  {
    name: "Premiere Pro",
    instructor: "Faisal Mahmood",
    description: "Video editing and production",
    url: "/premiere.php",
    category: "Media",
    rating: 4.6,
    students: 350,
    price: 20000,
    originalPrice: 28000,
  },
  {
    name: "Excel Advanced",
    instructor: "Ayesha Siddiqui",
    description: "Data analysis with Excel",
    url: "/excel.php",
    category: "Productivity",
    rating: 4.5,
    students: 800,
    price: 18000,
    originalPrice: 26000,
  },
  {
    name: "Power BI",
    instructor: "Bilal Nasir",
    description: "Business intelligence and analytics",
    url: "/powerbi.php",
    category: "Analytics",
    rating: 4.7,
    students: 300,
    price: 24000,
    originalPrice: 32000,
  },
  {
    name: "Tableau",
    instructor: "Hadiya Khan",
    description: "Data visualization mastery",
    url: "/tableau.php",
    category: "Analytics",
    rating: 4.8,
    students: 280,
    price: 25000,
    originalPrice: 33000,
  },
  {
    name: "R Programming",
    instructor: "Dr. Fatima Rizwan",
    description: "Statistical computing with R",
    url: "/r-programming.php",
    category: "Data Science",
    rating: 4.7,
    students: 220,
    price: 23000,
    originalPrice: 31000,
  },
  {
    name: "MATLAB",
    instructor: "Prof. Imran Shah",
    description: "Technical computing platform",
    url: "/matlab.php",
    category: "Engineering",
    rating: 4.6,
    students: 180,
    price: 20000,
    originalPrice: 28000,
  },
  {
    name: "AutoCAD",
    instructor: "Saad Chaudhry",
    description: "Computer-aided design",
    url: "/autocad.php",
    category: "Engineering",
    rating: 4.5,
    students: 250,
    price: 19000,
    originalPrice: 27000,
  },
  {
    name: "SolidWorks",
    instructor: "Aisha Jamal",
    description: "3D mechanical design",
    url: "/solidworks.php",
    category: "Engineering",
    rating: 4.7,
    students: 200,
    price: 22000,
    originalPrice: 30000,
  },
  {
    name: "Blender 3D",
    instructor: "Omar Hassan",
    description: "3D modeling and animation",
    url: "/blender.php",
    category: "3D Graphics",
    rating: 4.8,
    students: 450,
    price: 24000,
    originalPrice: 32000,
  },
  {
    name: "Maya 3D",
    instructor: "Sara Khan",
    description: "Professional 3D animation",
    url: "/maya.php",
    category: "3D Graphics",
    rating: 4.7,
    students: 180,
    price: 23000,
    originalPrice: 31000,
  },
  {
    name: "Cinema 4D",
    instructor: "Yusuf Mahmood",
    description: "Motion graphics and 3D",
    url: "/cinema4d.php",
    category: "3D Graphics",
    rating: 4.6,
    students: 150,
    price: 20000,
    originalPrice: 28000,
  },
  {
    name: "Sketch Design",
    instructor: "Amina Sheikh",
    description: "Digital design for Mac",
    url: "/sketch.php",
    category: "Design",
    rating: 4.5,
    students: 300,
    price: 18000,
    originalPrice: 26000,
  },
  {
    name: "InDesign",
    instructor: "Bilal Qureshi",
    description: "Desktop publishing mastery",
    url: "/indesign.php",
    category: "Design",
    rating: 4.6,
    students: 250,
    price: 19000,
    originalPrice: 27000,
  },
  {
    name: "WordPress",
    instructor: "Khadija Ansari",
    description: "Content management system",
    url: "/wordpress.php",
    category: "CMS",
    rating: 4.5,
    students: 900,
    price: 17000,
    originalPrice: 24000,
  },
  {
    name: "Shopify",
    instructor: "Usman Butt",
    description: "E-commerce platform mastery",
    url: "/shopify.php",
    category: "E-commerce",
    rating: 4.6,
    students: 400,
    price: 20000,
    originalPrice: 28000,
  },
  {
    name: "Digital Marketing",
    instructor: "Saba Iqbal",
    description: "Online marketing strategies",
    url: "/digital-marketing.php",
    category: "Marketing",
    rating: 4.7,
    students: 650,
    price: 22000,
    originalPrice: 30000,
  },
  {
    name: "SEO Optimization",
    instructor: "Zeeshan Malik",
    description: "Search engine optimization",
    url: "/seo.php",
    category: "Marketing",
    rating: 4.8,
    students: 550,
    price: 24000,
    originalPrice: 32000,
  },
  {
    name: "Google Analytics",
    instructor: "Amina Khan",
    description: "Web analytics mastery",
    url: "/analytics.php",
    category: "Analytics",
    rating: 4.7,
    students: 480,
    price: 23000,
    originalPrice: 31000,
  },
]

export default function HomePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredCourses, setFilteredCourses] = useState(courses)
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [showNewsletterModal, setShowNewsletterModal] = useState(false)
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false)
  const [showCourseComparison, setShowCourseComparison] = useState(false)

  const categories = ["All", ...Array.from(new Set(courses.map((course) => course.category)))]

  useEffect(() => {
    let filtered = courses

    if (searchTerm) {
      filtered = filtered.filter(
        (course) =>
          course.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          course.instructor.toLowerCase().includes(searchTerm.toLowerCase()) ||
          course.description.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (selectedCategory !== "All") {
      filtered = filtered.filter((course) => course.category === selectedCategory)
    }

    setFilteredCourses(filtered)
  }, [searchTerm, selectedCategory])

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowNewsletterModal(true)
    }, 10000)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-blue-50/50 to-indigo-100/50 dark:from-background dark:via-slate-900/50 dark:to-slate-800/50 relative">
      <FloatingElements />
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-3"
            >
              <Image
                src="/images/brightmind-logo.png"
                alt="BrightMind NG Logo"
                width={50}
                height={50}
                className="rounded-lg"
              />
              <div>
                <h1 className="text-2xl font-bold text-slate-800">BrightMind NG</h1>
                <p className="text-sm text-slate-600">Illuminate Your Future</p>
              </div>
            </motion.div>

            <div className="flex items-center space-x-4">
              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/" className="text-primary font-medium">
                  Home
                </Link>
                <Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">
                  About
                </Link>
                <Link href="/categories" className="text-muted-foreground hover:text-primary transition-colors">
                  Categories
                </Link>
              </nav>
              <ThemeToggle />
              <MobileNav />
              <Button variant="outline" className="border-primary/20 text-primary hover:bg-primary/5 hidden md:flex">
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-indigo-600/10 dark:from-primary/5 dark:to-indigo-600/5" />
        <div className="absolute inset-0 opacity-30 dark:opacity-20"></div>
        <div className="container mx-auto px-4 relative">
          <div className="text-center max-w-4xl mx-auto">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
              <h2 className="text-5xl md:text-6xl font-bold text-slate-800 mb-6">
                Master Technology with
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
                  {" "}
                  Expert Guidance
                </span>
              </h2>
              <p className="text-xl text-slate-600 mb-8 leading-relaxed">
                Join thousands of students learning cutting-edge technologies from industry experts. 50+ comprehensive
                courses designed to accelerate your career.
              </p>

              <div className="flex flex-wrap justify-center gap-6 mb-12">
                <div className="flex items-center space-x-2 text-slate-700">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                  <span>50+ Courses</span>
                </div>
                <div className="flex items-center space-x-2 text-slate-700">
                  <Users className="w-5 h-5 text-blue-600" />
                  <span>25,000+ Students</span>
                </div>
                <div className="flex items-center space-x-2 text-slate-700">
                  <Award className="w-5 h-5 text-blue-600" />
                  <span>Expert Instructors</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="py-8 bg-white/50 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                <Input
                  placeholder="Search courses, instructors, or topics..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-12 h-12 border-slate-200 focus:border-blue-400"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowAdvancedSearch(true)}
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 h-10 w-10"
                >
                  <Filter className="w-4 h-4" />
                </Button>
              </div>
              <Button onClick={() => setShowCourseComparison(true)}>Compare Courses</Button>
            </div>

            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={
                    selectedCategory === category
                      ? "bg-blue-600 hover:bg-blue-700"
                      : "border-slate-200 text-slate-600 hover:bg-slate-50"
                  }
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          >
            {filteredCourses.map((course, index) => (
              <motion.div
                key={course.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                whileHover={{ y: -5, scale: 1.02 }}
                className="group"
              >
                <Card className="h-full bg-white/80 backdrop-blur-sm border-white/20 hover:shadow-xl transition-all duration-300 hover:border-blue-200">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between mb-2">
                      <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-700">
                        {course.category}
                      </Badge>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium text-slate-600">{course.rating}</span>
                      </div>
                    </div>
                    <CardTitle className="text-lg group-hover:text-blue-600 transition-colors">{course.name}</CardTitle>
                    <CardDescription className="text-slate-600">by {course.instructor}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-slate-600 mb-4 line-clamp-2">{course.description}</p>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-1 text-sm text-slate-500">
                        <Users className="w-4 h-4" />
                        <span>{course.students.toLocaleString()} students</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-lg font-bold text-primary">₦{course.price.toLocaleString()}</span>
                        {course.originalPrice && (
                          <span className="text-sm text-muted-foreground line-through">
                            ₦{course.originalPrice.toLocaleString()}
                          </span>
                        )}
                      </div>
                      <Badge variant="secondary" className="bg-green-100 text-green-700">
                        Save ₦{course.originalPrice ? (course.originalPrice - course.price).toLocaleString() : "0"}
                      </Badge>
                    </div>
                    <Button
                      asChild
                      className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
                    >
                      <Link href="/coming-soon">Start Learning</Link>
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>

          {filteredCourses.length === 0 && (
            <div className="text-center py-16">
              <div className="text-slate-400 mb-4">
                <BookOpen className="w-16 h-16 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-600">No courses found</h3>
                <p className="text-slate-500">Try adjusting your search or filter criteria</p>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Learning Path Recommendations */}
      <LearningPathRecommendations />

      {/* Instructor Profiles */}
      <InstructorProfiles />

      {/* Testimonials */}
      <TestimonialsCarousel />

      {/* Course Reviews */}
      <CourseReviews courseName="Python Programming" />

      {/* Live Chat AI */}
      <LiveChatAI />

      {/* Modals */}
      <NewsletterModal isOpen={showNewsletterModal} onClose={() => setShowNewsletterModal(false)} />
      <AdvancedSearch
        isOpen={showAdvancedSearch}
        onClose={() => setShowAdvancedSearch(false)}
        onSearch={(filters) => {
          // Handle search filters
          console.log("Search filters:", filters)
        }}
      />
      <CourseComparison
        isOpen={showCourseComparison}
        onClose={() => setShowCourseComparison(false)}
        availableCourses={courses}
      />

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <Image
                  src="/images/brightmind-logo.png"
                  alt="BrightMind NG Logo"
                  width={40}
                  height={40}
                  className="rounded-lg"
                />
                <div>
                  <h3 className="text-xl font-bold">BrightMind NG</h3>
                  <p className="text-slate-400 text-sm">Illuminate Your Future</p>
                </div>
              </div>
              <p className="text-slate-300 mb-4">
                Empowering the next generation of tech professionals with comprehensive, industry-relevant courses
                taught by expert instructors.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/" className="hover:text-white transition-colors">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/about" className="hover:text-white transition-colors">
                    About
                  </Link>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Courses
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Contact
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Categories</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Programming
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Web Development
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Data Science
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Design
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-400">
            <p>&copy; 2025 BrightMind NG. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
