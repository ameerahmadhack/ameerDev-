"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  BookOpen,
  Clock,
  Trophy,
  Target,
  TrendingUp,
  Calendar,
  Play,
  Star,
  Award,
  BarChart3,
  Heart,
  Settings,
  Bell,
  User,
  LogOut,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import Link from "next/link"
import Image from "next/image"

const enrolledCourses = [
  {
    id: 1,
    name: "Python Programming",
    instructor: "Ameer Ahmad",
    progress: 75,
    totalLessons: 24,
    completedLessons: 18,
    nextLesson: "Advanced Functions",
    timeSpent: "12h 30m",
    rating: 4.9,
    thumbnail: "/placeholder.svg?height=120&width=200",
  },
  {
    id: 2,
    name: "JavaScript Essentials",
    instructor: "Fatima Al-Zahra",
    progress: 45,
    totalLessons: 20,
    completedLessons: 9,
    nextLesson: "DOM Manipulation",
    timeSpent: "8h 15m",
    rating: 4.8,
    thumbnail: "/placeholder.svg?height=120&width=200",
  },
  {
    id: 3,
    name: "React Development",
    instructor: "Abdullah Hassan",
    progress: 30,
    totalLessons: 28,
    completedLessons: 8,
    nextLesson: "State Management",
    timeSpent: "5h 45m",
    rating: 4.9,
    thumbnail: "/placeholder.svg?height=120&width=200",
  },
]

const achievements = [
  { name: "First Course", icon: Trophy, color: "text-yellow-500", earned: true },
  { name: "Week Streak", icon: Target, color: "text-blue-500", earned: true },
  { name: "Fast Learner", icon: TrendingUp, color: "text-green-500", earned: false },
  { name: "Course Master", icon: Award, color: "text-purple-500", earned: false },
]

const recentActivity = [
  { action: "Completed", item: "Python Functions", time: "2 hours ago", type: "lesson" },
  { action: "Started", item: "JavaScript Essentials", time: "1 day ago", type: "course" },
  { action: "Earned", item: "Week Streak Badge", time: "2 days ago", type: "achievement" },
  { action: "Completed", item: "HTML Basics", time: "3 days ago", type: "lesson" },
]

const wishlistCourses = [
  { name: "Machine Learning", instructor: "Dr. Hamza Ali", price: 30000, rating: 4.9 },
  { name: "Node.js Backend", instructor: "Yusuf Ibrahim", price: 24000, rating: 4.7 },
  { name: "Vue.js Framework", instructor: "Maryam Saeed", price: 24000, rating: 4.8 },
]

export default function StudentDashboard() {
  const [totalStudyTime] = useState(26)
  const [weeklyGoal] = useState(10)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <Image
                src="/images/brightmind-logo.png"
                alt="BrightMind NG"
                width={40}
                height={40}
                className="rounded-lg"
              />
              <span className="text-xl font-bold text-slate-800">Student Dashboard</span>
            </Link>
            <div className="flex items-center space-x-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative">
                    <Bell className="w-5 h-5" />
                    <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80">
                  <div className="p-4">
                    <h3 className="font-medium mb-1">Notifications</h3>
                    <p className="text-xs text-muted-foreground mb-2">You have 3 unread notifications</p>
                    <Separator className="my-2" />
                    <div className="space-y-4 mt-4">
                      <div className="flex gap-3">
                        <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-full">
                          <BookOpen className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">New lesson available</p>
                          <p className="text-xs text-muted-foreground">Python Programming: Advanced OOP</p>
                          <p className="text-xs text-muted-foreground mt-1">10 minutes ago</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32" />
                      <AvatarFallback>ST</AvatarFallback>
                    </Avatar>
                    <span className="hidden md:inline">Student</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Welcome back, Student!</h1>
          <p className="text-slate-600">Continue your learning journey and achieve your goals.</p>
        </motion.div>

        {/* Stats Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm">Enrolled Courses</p>
                  <p className="text-3xl font-bold">{enrolledCourses.length}</p>
                </div>
                <BookOpen className="w-8 h-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm">Study Time</p>
                  <p className="text-3xl font-bold">{totalStudyTime}h</p>
                </div>
                <Clock className="w-8 h-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Achievements</p>
                  <p className="text-3xl font-bold">{achievements.filter((a) => a.earned).length}</p>
                </div>
                <Trophy className="w-8 h-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm">Weekly Goal</p>
                  <p className="text-3xl font-bold">{Math.round((totalStudyTime / weeklyGoal) * 100)}%</p>
                </div>
                <Target className="w-8 h-8 text-orange-200" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <Tabs defaultValue="courses" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4">
            <TabsTrigger value="courses">My Courses</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
            <TabsTrigger value="wishlist">Wishlist</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>

          {/* My Courses Tab */}
          <TabsContent value="courses" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {enrolledCourses.map((course, index) => (
                <motion.div
                  key={course.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -5 }}
                >
                  <Card className="h-full bg-white/80 backdrop-blur-sm border-white/20 hover:shadow-xl transition-all duration-300">
                    <div className="relative">
                      <img
                        src={course.thumbnail || "/placeholder.svg"}
                        alt={course.name}
                        className="w-full h-32 object-cover rounded-t-lg"
                      />
                      <Badge className="absolute top-2 right-2 bg-blue-500">{course.progress}% Complete</Badge>
                    </div>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg">{course.name}</CardTitle>
                      <CardDescription>by {course.instructor}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>
                            {course.completedLessons}/{course.totalLessons} lessons
                          </span>
                        </div>
                        <Progress value={course.progress} className="h-2" />
                      </div>

                      <div className="flex items-center justify-between text-sm text-slate-600">
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span>{course.timeSpent}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span>{course.rating}</span>
                        </div>
                      </div>

                      <div className="pt-2 border-t">
                        <p className="text-sm text-slate-600 mb-3">
                          Next: <span className="font-medium">{course.nextLesson}</span>
                        </p>
                        <Button className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600">
                          <Play className="w-4 h-4 mr-2" />
                          Continue Learning
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Progress Tab */}
          <TabsContent value="progress" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="w-5 h-5" />
                    <span>Learning Statistics</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Weekly Goal Progress</span>
                      <span className="text-sm text-slate-600">
                        {totalStudyTime}h / {weeklyGoal}h
                      </span>
                    </div>
                    <Progress value={(totalStudyTime / weeklyGoal) * 100} className="h-3" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <p className="text-2xl font-bold text-blue-600">
                        {enrolledCourses.reduce((acc, course) => acc + course.completedLessons, 0)}
                      </p>
                      <p className="text-sm text-slate-600">Lessons Completed</p>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">
                        {Math.round(
                          enrolledCourses.reduce((acc, course) => acc + course.progress, 0) / enrolledCourses.length,
                        )}
                        %
                      </p>
                      <p className="text-sm text-slate-600">Average Progress</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Calendar className="w-5 h-5" />
                    <span>Recent Activity</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivity.map((activity, index) => (
                      <div key={index} className="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            activity.type === "lesson"
                              ? "bg-blue-500"
                              : activity.type === "course"
                                ? "bg-green-500"
                                : "bg-purple-500"
                          }`}
                        />
                        <div className="flex-1">
                          <p className="text-sm">
                            <span className="font-medium">{activity.action}</span> {activity.item}
                          </p>
                          <p className="text-xs text-slate-500">{activity.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Wishlist Tab */}
          <TabsContent value="wishlist" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Heart className="w-5 h-5" />
                  <span>Course Wishlist</span>
                </CardTitle>
                <CardDescription>Courses you're interested in taking</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {wishlistCourses.map((course, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex-1">
                        <h4 className="font-medium text-slate-800">{course.name}</h4>
                        <p className="text-sm text-slate-600">by {course.instructor}</p>
                        <div className="flex items-center space-x-4 mt-2">
                          <div className="flex items-center space-x-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm">{course.rating}</span>
                          </div>
                          <span className="text-lg font-bold text-blue-600">₦{course.price.toLocaleString()}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          Remove
                        </Button>
                        <Link href="/coming-soon">
                          <Button size="sm" className="bg-blue-500 hover:bg-blue-600">
                            Enroll Now
                          </Button>
                        </Link>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {achievements.map((achievement, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                >
                  <Card
                    className={`text-center ${achievement.earned ? "bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200" : "bg-slate-50 border-slate-200"}`}
                  >
                    <CardContent className="p-6">
                      <div
                        className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${
                          achievement.earned ? "bg-gradient-to-br from-yellow-400 to-orange-400" : "bg-slate-300"
                        }`}
                      >
                        <achievement.icon
                          className={`w-8 h-8 ${achievement.earned ? "text-white" : "text-slate-500"}`}
                        />
                      </div>
                      <h3 className={`font-semibold mb-2 ${achievement.earned ? "text-slate-800" : "text-slate-500"}`}>
                        {achievement.name}
                      </h3>
                      <Badge variant={achievement.earned ? "default" : "secondary"}>
                        {achievement.earned ? "Earned" : "Locked"}
                      </Badge>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
