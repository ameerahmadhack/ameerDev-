"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Search, Filter, BookOpen, Users, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import Image from "next/image"
import { ThemeToggle } from "@/components/theme-toggle"
import { MobileNav } from "@/components/mobile-nav"
import { FloatingElements } from "@/components/floating-elements"

const categories = [
  {
    name: "Programming",
    description: "Master programming languages and fundamentals",
    courses: 12,
    students: 8500,
    icon: "💻",
    color: "from-blue-500 to-cyan-500",
    courses_list: ["Python Programming", "Java Programming", "C++ Fundamentals", "Data Structures"],
  },
  {
    name: "Web Development",
    description: "Build modern web applications",
    courses: 8,
    students: 6200,
    icon: "🌐",
    color: "from-green-500 to-emerald-500",
    courses_list: ["JavaScript Essentials", "PHP Web Development", "HTML5 & CSS3", "WordPress"],
  },
  {
    name: "Frontend",
    description: "Create beautiful user interfaces",
    courses: 6,
    students: 4800,
    icon: "🎨",
    color: "from-purple-500 to-pink-500",
    courses_list: ["React Development", "Vue.js Framework", "Angular Development"],
  },
  {
    name: "Backend",
    description: "Server-side development and APIs",
    courses: 5,
    students: 3200,
    icon: "⚙️",
    color: "from-orange-500 to-red-500",
    courses_list: ["Node.js Backend", "Django Framework", "Laravel PHP"],
  },
  {
    name: "Database",
    description: "Data storage and management",
    courses: 4,
    students: 2800,
    icon: "🗄️",
    color: "from-indigo-500 to-blue-500",
    courses_list: ["MySQL Database", "MongoDB"],
  },
  {
    name: "Mobile",
    description: "iOS and Android app development",
    courses: 6,
    students: 3600,
    icon: "📱",
    color: "from-teal-500 to-green-500",
    courses_list: ["Flutter Mobile", "React Native", "Swift iOS", "Kotlin Android"],
  },
  {
    name: "Design",
    description: "UI/UX and graphic design",
    courses: 8,
    students: 4200,
    icon: "🎭",
    color: "from-pink-500 to-rose-500",
    courses_list: ["Web Design", "Photoshop", "Illustrator", "Figma Design", "Sketch Design", "InDesign"],
  },
  {
    name: "AI/ML",
    description: "Artificial Intelligence and Machine Learning",
    courses: 3,
    students: 1800,
    icon: "🤖",
    color: "from-violet-500 to-purple-500",
    courses_list: ["Machine Learning"],
  },
  {
    name: "Cloud",
    description: "Cloud computing and deployment",
    courses: 2,
    students: 1500,
    icon: "☁️",
    color: "from-sky-500 to-blue-500",
    courses_list: ["AWS Cloud"],
  },
  {
    name: "DevOps",
    description: "Development operations and automation",
    courses: 3,
    students: 1200,
    icon: "🔧",
    color: "from-gray-500 to-slate-500",
    courses_list: ["Docker Containers", "Git & GitHub"],
  },
]

export default function CategoriesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredCategories, setFilteredCategories] = useState(categories)

  const handleSearch = (term: string) => {
    setSearchTerm(term)
    if (term) {
      const filtered = categories.filter(
        (category) =>
          category.name.toLowerCase().includes(term.toLowerCase()) ||
          category.description.toLowerCase().includes(term.toLowerCase()),
      )
      setFilteredCategories(filtered)
    } else {
      setFilteredCategories(categories)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-blue-50/50 to-indigo-100/50 dark:from-background dark:via-slate-900/50 dark:to-slate-800/50 relative">
      <FloatingElements />

      {/* Header */}
      <header className="bg-background/80 backdrop-blur-md border-b border-border/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-3"
            >
              <Image
                src="/images/brightmind-logo.png"
                alt="BrightMind NG Logo"
                width={50}
                height={50}
                className="rounded-lg"
              />
              <div>
                <h1 className="text-2xl font-bold">BrightMind NG</h1>
                <p className="text-sm text-muted-foreground">Illuminate Your Future</p>
              </div>
            </motion.div>

            <div className="flex items-center space-x-4">
              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                  Home
                </Link>
                <Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">
                  About
                </Link>
                <Link href="/categories" className="text-primary font-medium">
                  Categories
                </Link>
              </nav>
              <ThemeToggle />
              <MobileNav />
              <Button variant="outline" className="hidden md:flex">
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 relative">
        {/* Back Button */}
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="mb-8">
          <Button variant="ghost" asChild>
            <Link href="/" className="flex items-center space-x-2">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Home</span>
            </Link>
          </Button>
        </motion.div>

        {/* Hero Section */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Course{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400">
              Categories
            </span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-8">
            Explore our comprehensive range of technology courses organized by category. Find the perfect learning path
            for your career goals.
          </p>

          {/* Search */}
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input
              placeholder="Search categories..."
              value={searchTerm}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-10 h-12"
            />
          </div>
        </motion.section>

        {/* Categories Grid */}
        <motion.section initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.2 }}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCategories.map((category, index) => (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="group"
              >
                <Card className="h-full bg-card/80 backdrop-blur-sm border-border/20 hover:shadow-2xl transition-all duration-500 hover:border-primary/20 overflow-hidden relative">
                  {/* Gradient Background */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-5 group-hover:opacity-10 transition-opacity duration-500`}
                  />

                  <CardHeader className="relative">
                    <div className="flex items-center justify-between mb-4">
                      <div className="text-4xl">{category.icon}</div>
                      <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all duration-300" />
                    </div>
                    <CardTitle className="text-2xl group-hover:text-primary transition-colors duration-300">
                      {category.name}
                    </CardTitle>
                    <CardDescription className="text-base">{category.description}</CardDescription>
                  </CardHeader>

                  <CardContent className="relative">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                        <BookOpen className="w-4 h-4" />
                        <span>{category.courses} courses</span>
                      </div>
                      <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                        <Users className="w-4 h-4" />
                        <span>{category.students.toLocaleString()} students</span>
                      </div>
                    </div>

                    {/* Course List Preview */}
                    <div className="mb-6">
                      <h4 className="font-medium mb-3 text-sm text-muted-foreground">Featured Courses:</h4>
                      <div className="space-y-2">
                        {category.courses_list.slice(0, 3).map((course, idx) => (
                          <div key={idx} className="flex items-center space-x-2 text-sm">
                            <div className="w-1.5 h-1.5 rounded-full bg-primary/60" />
                            <span className="text-muted-foreground">{course}</span>
                          </div>
                        ))}
                        {category.courses_list.length > 3 && (
                          <div className="text-sm text-muted-foreground/60">
                            +{category.courses_list.length - 3} more courses
                          </div>
                        )}
                      </div>
                    </div>

                    <Button className="w-full group-hover:shadow-lg transition-all duration-300">
                      Explore {category.name}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {filteredCategories.length === 0 && (
            <div className="text-center py-16">
              <div className="text-muted-foreground mb-4">
                <Filter className="w-16 h-16 mx-auto mb-4" />
                <h3 className="text-xl font-semibold">No categories found</h3>
                <p className="text-muted-foreground">Try adjusting your search criteria</p>
              </div>
            </div>
          )}
        </motion.section>

        {/* Stats Section */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-20 text-center"
        >
          <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-700 dark:to-indigo-700 text-white border-0">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold mb-4">Ready to Start Learning?</h2>
              <p className="text-blue-100 mb-6 text-lg">
                Join thousands of students who have transformed their careers with BrightMind NG
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
                  <Link href="/">Browse All Courses</Link>
                </Button>
                <Button variant="outline" size="lg" className="border-white text-white hover:bg-white/10">
                  Contact Us
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.section>
      </div>
    </div>
  )
}
