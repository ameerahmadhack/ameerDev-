"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Users, CheckCircle, Clock, Eye, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import Image from "next/image"

const enrollmentData = [
  {
    id: "BM123456",
    name: "Muhammad Ibrahim",
    email: "ibrahim@email.com",
    phone: "+234 801 234 5678",
    transferPhone: "+234 801 234 5678",
    course: "Python Programming for Beginners",
    amount: 25000,
    status: "pending",
    timestamp: "2025-01-07T10:30:00Z",
    paymentMethod: "bank",
  },
  {
    id: "BM123457",
    name: "Aisha Abdullahi",
    email: "aisha@email.com",
    phone: "+234 802 345 6789",
    transferPhone: "+234 802 345 6789",
    course: "Python Programming for Beginners",
    amount: 25000,
    status: "approved",
    timestamp: "2025-01-07T09:15:00Z",
    paymentMethod: "bank",
  },
  {
    id: "BM123458",
    name: "Yusuf Hassan",
    email: "yusuf@email.com",
    phone: "+234 803 456 7890",
    transferPhone: "+234 803 456 7890",
    course: "Python Programming for Beginners",
    amount: 25000,
    status: "pending",
    timestamp: "2025-01-07T11:45:00Z",
    paymentMethod: "bank",
  },
]

export default function AdminDashboard() {
  const [enrollments, setEnrollments] = useState(enrollmentData)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")

  const handleApprove = (studentId: string) => {
    setEnrollments((prev) =>
      prev.map((enrollment) => (enrollment.id === studentId ? { ...enrollment, status: "approved" } : enrollment)),
    )
  }

  const filteredEnrollments = enrollments.filter((enrollment) => {
    const matchesSearch =
      enrollment.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      enrollment.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      enrollment.email.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesFilter = filterStatus === "all" || enrollment.status === filterStatus

    return matchesSearch && matchesFilter
  })

  const stats = {
    total: enrollments.length,
    pending: enrollments.filter((e) => e.status === "pending").length,
    approved: enrollments.filter((e) => e.status === "approved").length,
    revenue: enrollments.filter((e) => e.status === "approved").reduce((sum, e) => sum + e.amount, 0),
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-blue-50/50 to-indigo-100/50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Image
                src="/images/brightmind-logo.png"
                alt="BrightMind NG Logo"
                width={40}
                height={40}
                className="rounded-lg"
              />
              <div>
                <h1 className="text-xl font-bold text-slate-800">Admin Dashboard</h1>
                <p className="text-sm text-slate-600">BrightMind NG Course Management</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Badge variant="outline">Admin Panel</Badge>
              <Button variant="outline">Logout</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Total Enrollments</p>
                    <p className="text-3xl font-bold">{stats.total}</p>
                  </div>
                  <Users className="w-8 h-8 text-blue-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-orange-600 to-red-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100">Pending Approval</p>
                    <p className="text-3xl font-bold">{stats.pending}</p>
                  </div>
                  <Clock className="w-8 h-8 text-orange-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-600 to-emerald-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Approved Students</p>
                    <p className="text-3xl font-bold">{stats.approved}</p>
                  </div>
                  <CheckCircle className="w-8 h-8 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Revenue</p>
                    <p className="text-3xl font-bold">₦{stats.revenue.toLocaleString()}</p>
                  </div>
                  <Eye className="w-8 h-8 text-purple-200" />
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.section>

        {/* Enrollments Management */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Student Enrollments</CardTitle>
              <CardDescription>Manage course enrollments and payment approvals</CardDescription>

              {/* Search and Filter */}
              <div className="flex flex-col sm:flex-row gap-4 mt-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <Input
                    placeholder="Search by name, ID, or email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={filterStatus === "all" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilterStatus("all")}
                  >
                    All
                  </Button>
                  <Button
                    variant={filterStatus === "pending" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilterStatus("pending")}
                  >
                    Pending
                  </Button>
                  <Button
                    variant={filterStatus === "approved" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilterStatus("approved")}
                  >
                    Approved
                  </Button>
                </div>
              </div>
            </CardHeader>

            <CardContent>
              <div className="space-y-4">
                {filteredEnrollments.map((enrollment, index) => (
                  <motion.div
                    key={enrollment.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold text-lg">{enrollment.name}</h3>
                          <Badge
                            className={
                              enrollment.status === "approved"
                                ? "bg-green-100 text-green-700"
                                : "bg-orange-100 text-orange-700"
                            }
                          >
                            {enrollment.status === "approved" ? "Approved" : "Pending"}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-slate-600">
                          <div>
                            <p>
                              <strong>Student ID:</strong> {enrollment.id}
                            </p>
                            <p>
                              <strong>Email:</strong> {enrollment.email}
                            </p>
                            <p>
                              <strong>Phone:</strong> {enrollment.phone}
                            </p>
                          </div>
                          <div>
                            <p>
                              <strong>Transfer Phone:</strong> {enrollment.transferPhone}
                            </p>
                            <p>
                              <strong>Amount:</strong> ₦{enrollment.amount.toLocaleString()}
                            </p>
                            <p>
                              <strong>Enrolled:</strong> {new Date(enrollment.timestamp).toLocaleString()}
                            </p>
                          </div>
                        </div>

                        <div className="mt-2">
                          <p className="text-sm">
                            <strong>Course:</strong> {enrollment.course}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row gap-2">
                        {enrollment.status === "pending" && (
                          <Button
                            onClick={() => handleApprove(enrollment.id)}
                            className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Approve
                          </Button>
                        )}
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                ))}

                {filteredEnrollments.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-slate-500">No enrollments found matching your criteria.</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.section>
      </div>
    </div>
  )
}
