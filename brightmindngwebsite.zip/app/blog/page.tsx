"use client"

import { motion } from "framer-motion"
import {
  ArrowLeft,
  Calendar,
  Clock,
  User,
  ArrowRight,
  BookOpen,
  TrendingUp,
  Code,
  Lightbulb,
  Star,
  Eye,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import Image from "next/image"
import { ThemeToggle } from "@/components/theme-toggle"
import { MobileNav } from "@/components/mobile-nav"
import { FloatingElements } from "@/components/floating-elements"
import { useState } from "react"
import { SocialMedia, SocialShareButton } from "@/components/social-media-integration"
import { Footer } from "@/components/footer"

export default function BlogPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const featuredPost = {
    id: 1,
    title: "The Complete Guide to Starting Your Tech Career in 2024",
    excerpt:
      "Everything you need to know about breaking into the tech industry, from choosing the right skills to landing your first job.",
    author: "Ameer Ahmad",
    date: "2024-01-15",
    readTime: "12 min read",
    image: "/placeholder.svg?height=400&width=600",
    category: "Career",
    views: 2500,
    featured: true,
  }

  const blogPosts = [
    {
      id: 2,
      title: "Python vs JavaScript: Which Should You Learn First?",
      excerpt: "A comprehensive comparison of two of the most popular programming languages for beginners.",
      author: "Ameer Ahmad",
      date: "2024-01-10",
      readTime: "8 min read",
      image: "/placeholder.svg?height=300&width=400",
      category: "Programming",
      views: 1800,
    },
    {
      id: 3,
      title: "Building Your First Web Application: A Step-by-Step Guide",
      excerpt: "Learn how to create a complete web application from scratch using modern technologies.",
      author: "Ameer Ahmad",
      date: "2024-01-05",
      readTime: "15 min read",
      image: "/placeholder.svg?height=300&width=400",
      category: "Web Development",
      views: 3200,
    },
    {
      id: 4,
      title: "The Future of AI in Education: What Students Need to Know",
      excerpt: "Exploring how artificial intelligence is transforming the way we learn and teach.",
      author: "Ameer Ahmad",
      date: "2024-01-01",
      readTime: "10 min read",
      image: "/placeholder.svg?height=300&width=400",
      category: "AI & Technology",
      views: 2100,
    },
    {
      id: 5,
      title: "Remote Work Skills Every Developer Should Master",
      excerpt: "Essential skills and tools for thriving in a remote development environment.",
      author: "Ameer Ahmad",
      date: "2023-12-28",
      readTime: "7 min read",
      image: "/placeholder.svg?height=300&width=400",
      category: "Career",
      views: 1500,
    },
    {
      id: 6,
      title: "Database Design Best Practices for Beginners",
      excerpt: "Learn the fundamentals of designing efficient and scalable databases.",
      author: "Ameer Ahmad",
      date: "2023-12-25",
      readTime: "11 min read",
      image: "/placeholder.svg?height=300&width=400",
      category: "Database",
      views: 1900,
    },
    {
      id: 7,
      title: "Top 10 Coding Interview Questions and How to Answer Them",
      excerpt: "Prepare for your next technical interview with these commonly asked questions.",
      author: "Ameer Ahmad",
      date: "2023-12-20",
      readTime: "13 min read",
      image: "/placeholder.svg?height=300&width=400",
      category: "Interview Prep",
      views: 4100,
    },
  ]

  const categories = [
    { name: "All", count: 7, icon: BookOpen },
    { name: "Programming", count: 2, icon: Code },
    { name: "Career", count: 2, icon: TrendingUp },
    { name: "Web Development", count: 1, icon: Lightbulb },
    { name: "AI & Technology", count: 1, icon: Star },
    { name: "Database", count: 1, icon: BookOpen },
  ]

  const [selectedCategory, setSelectedCategory] = useState("All")

  const filteredPosts = blogPosts.filter((post) => {
    const matchesSearch =
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "All" || post.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-blue-50/50 to-indigo-100/50 dark:from-background dark:via-slate-900/50 dark:to-slate-800/50 relative">
      <FloatingElements />

      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-3"
            >
              <Image
                src="/images/brightmind-logo.png"
                alt="BrightMind NG Logo"
                width={50}
                height={50}
                className="rounded-lg"
              />
              <div>
                <h1 className="text-2xl font-bold text-slate-800">BrightMind NG</h1>
                <p className="text-sm text-slate-600">Illuminate Your Future</p>
              </div>
            </motion.div>

            <div className="flex items-center space-x-4">
              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                  Home
                </Link>
                <Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">
                  About
                </Link>
                <Link href="/blog" className="text-primary font-medium">
                  Blog
                </Link>
                <Link href="/contact" className="text-muted-foreground hover:text-primary transition-colors">
                  Contact
                </Link>
                <Link href="/categories" className="text-muted-foreground hover:text-primary transition-colors">
                  Categories
                </Link>
              </nav>
              <ThemeToggle />
              <MobileNav />
              <Button variant="outline" className="border-primary/20 text-primary hover:bg-primary/5 hidden md:flex">
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="mb-8">
          <Button variant="ghost" asChild className="text-slate-600 hover:text-slate-800">
            <Link href="/" className="flex items-center space-x-2">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Home</span>
            </Link>
          </Button>
        </motion.div>

        {/* Hero Section */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-slate-800 mb-6">
            Tech{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">Blog</span>
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed mb-8">
            Insights, tutorials, and career advice from industry experts to help you succeed in tech.
          </p>

          {/* Search Bar */}
          <div className="max-w-md mx-auto">
            <Input
              type="text"
              placeholder="Search articles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full transition-all duration-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="mt-8"
          >
            <SocialMedia variant="follow" />
          </motion.div>
        </motion.section>

        {/* Categories */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-12"
        >
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category, index) => (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index, duration: 0.3 }}
              >
                <Button
                  variant={selectedCategory === category.name ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category.name)}
                  className="flex items-center space-x-2 transition-all duration-300"
                >
                  <category.icon className="w-4 h-4" />
                  <span>{category.name}</span>
                  <Badge variant="secondary" className="ml-1">
                    {category.count}
                  </Badge>
                </Button>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Featured Post */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mb-16"
        >
          <Card className="bg-white/80 backdrop-blur-sm border-white/20 shadow-xl overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
              <div className="relative h-64 lg:h-full overflow-hidden">
                <motion.div whileHover={{ scale: 1.05 }} transition={{ duration: 0.5 }} className="h-full">
                  <Image
                    src={featuredPost.image || "/placeholder.svg"}
                    alt={featuredPost.title}
                    fill
                    className="object-cover"
                  />
                </motion.div>
                <div className="absolute top-4 left-4">
                  <Badge className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">Featured</Badge>
                </div>
              </div>
              <div className="p-8">
                <div className="flex items-center justify-between mb-4">
                  <Badge variant="outline">{featuredPost.category}</Badge>
                  <div className="flex items-center space-x-2 text-slate-500 text-sm">
                    <Eye className="w-4 h-4" />
                    <span>{featuredPost.views.toLocaleString()} views</span>
                  </div>
                </div>

                <h2 className="text-2xl lg:text-3xl font-bold text-slate-800 mb-4">{featuredPost.title}</h2>

                <p className="text-slate-600 mb-6 leading-relaxed">{featuredPost.excerpt}</p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm text-slate-500">
                    <div className="flex items-center space-x-1">
                      <User className="w-4 h-4" />
                      <span>{featuredPost.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>{new Date(featuredPost.date).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{featuredPost.readTime}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <SocialShareButton
                      url={`https://brightmindng.com/blog/${featuredPost.id}`}
                      title={featuredPost.title}
                    />

                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                        Read More
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </motion.div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </motion.section>

        {/* Blog Posts Grid */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-3xl font-bold text-center text-slate-800 mb-12">Latest Articles</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 * index }}
                whileHover={{ y: -5 }}
              >
                <Card className="bg-white/80 backdrop-blur-sm border-white/20 hover:shadow-lg transition-all duration-300 h-full">
                  <div className="relative h-48 overflow-hidden rounded-t-lg">
                    <motion.div whileHover={{ scale: 1.05 }} transition={{ duration: 0.5 }} className="h-full">
                      <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
                    </motion.div>
                    <div className="absolute top-4 left-4">
                      <Badge variant="secondary">{post.category}</Badge>
                    </div>
                    <div className="absolute top-4 right-4">
                      <div className="flex items-center space-x-1 bg-black/50 text-white px-2 py-1 rounded text-xs">
                        <Eye className="w-3 h-3" />
                        <span>{post.views.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold text-slate-800 mb-3 line-clamp-2">{post.title}</h3>

                    <p className="text-slate-600 mb-4 line-clamp-3">{post.excerpt}</p>

                    <div className="flex items-center justify-between text-sm text-slate-500 mb-4">
                      <div className="flex items-center space-x-1">
                        <User className="w-4 h-4" />
                        <span>{post.author}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{post.readTime}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-500">{new Date(post.date).toLocaleDateString()}</span>
                      <div className="flex items-center space-x-2">
                        <SocialShareButton url={`https://brightmindng.com/blog/${post.id}`} title={post.title} />
                        <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700">
                          Read More
                          <ArrowRight className="w-4 h-4 ml-1" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {filteredPosts.length === 0 && (
            <div className="text-center py-12">
              <BookOpen className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-600 mb-2">No articles found</h3>
              <p className="text-slate-500">Try adjusting your search or category filter.</p>
            </div>
          )}
        </motion.section>

        {/* Newsletter Signup */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mb-16"
        >
          <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white overflow-hidden relative">
            <motion.div
              className="absolute inset-0 bg-[url('/placeholder.svg?height=400&width=600')] opacity-10"
              animate={{
                backgroundPosition: ["0% 0%", "100% 100%"],
              }}
              transition={{
                duration: 20,
                repeat: Number.POSITIVE_INFINITY,
                repeatType: "reverse",
              }}
            />
            <CardContent className="p-8 text-center relative z-10">
              <motion.h2
                className="text-3xl font-bold mb-4"
                initial={{ y: -20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
              >
                Stay Updated
              </motion.h2>
              <motion.p
                className="text-blue-100 mb-6 text-lg"
                initial={{ y: -20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                viewport={{ once: true }}
              >
                Get the latest tech insights and tutorials delivered to your inbox weekly.
              </motion.p>

              <motion.div
                className="flex flex-col sm:flex-row gap-4 justify-center items-center max-w-md mx-auto"
                initial={{ y: -20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="bg-white/10 border-white/20 text-white placeholder:text-blue-100 transition-all duration-300 focus:ring-2 focus:ring-white/50"
                />
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button className="bg-white text-blue-600 hover:bg-blue-50 whitespace-nowrap">Subscribe Now</Button>
                </motion.div>
              </motion.div>

              <motion.p
                className="text-blue-100 text-sm mt-4"
                initial={{ y: -20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                viewport={{ once: true }}
              >
                Join 5,000+ students already subscribed. Unsubscribe anytime.
              </motion.p>
            </CardContent>
          </Card>
        </motion.section>
      </div>

      <Footer />
    </div>
  )
}
