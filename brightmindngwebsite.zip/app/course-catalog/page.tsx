"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import {
  Search,
  Filter,
  Grid,
  List,
  Heart,
  Star,
  ChevronDown,
  BookOpen,
  Clock,
  BarChart,
  X,
  Check,
  Users,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

// Sample course data
const courses = [
  {
    id: 1,
    title: "Python Programming Masterclass",
    instructor: "Ameer Ahmad",
    image: "/placeholder.svg?height=200&width=300",
    category: "Programming",
    level: "Beginner",
    rating: 4.9,
    reviews: 1250,
    students: 15000,
    duration: "30 hours",
    lectures: 120,
    price: 49.99,
    tags: ["python", "programming", "data science"],
    description:
      "Master Python programming from the ground up. Learn everything from basic syntax to advanced concepts like OOP and data structures.",
    isNew: true,
    isBestseller: true,
  },
  {
    id: 2,
    title: "Web Development Bootcamp",
    instructor: "Fatima Al-Zahra",
    image: "/placeholder.svg?height=200&width=300",
    category: "Web Development",
    level: "Intermediate",
    rating: 4.8,
    reviews: 980,
    students: 8500,
    duration: "45 hours",
    lectures: 180,
    price: 59.99,
    tags: ["html", "css", "javascript", "react"],
    description:
      "Comprehensive web development course covering HTML, CSS, JavaScript, React, and more. Build real-world projects and deploy them.",
    isNew: false,
    isBestseller: true,
  },
  {
    id: 3,
    title: "Machine Learning Fundamentals",
    instructor: "Dr. Hamza Ali",
    image: "/placeholder.svg?height=200&width=300",
    category: "Data Science",
    level: "Advanced",
    rating: 4.9,
    reviews: 750,
    students: 5200,
    duration: "38 hours",
    lectures: 95,
    price: 69.99,
    tags: ["machine learning", "ai", "data science", "python"],
    description:
      "Learn the fundamentals of machine learning algorithms, data preprocessing, model evaluation, and implementation using Python.",
    isNew: true,
    isBestseller: false,
  },
  {
    id: 4,
    title: "UI/UX Design Principles",
    instructor: "Hafsa Yusuf",
    image: "/placeholder.svg?height=200&width=300",
    category: "Design",
    level: "Beginner",
    rating: 4.7,
    reviews: 620,
    students: 6800,
    duration: "25 hours",
    lectures: 85,
    price: 44.99,
    tags: ["ui", "ux", "design", "figma"],
    description:
      "Master the principles of UI/UX design. Learn how to create beautiful, user-friendly interfaces that deliver exceptional experiences.",
    isNew: false,
    isBestseller: false,
  },
  {
    id: 5,
    title: "Mobile App Development with Flutter",
    instructor: "Ibrahim Musa",
    image: "/placeholder.svg?height=200&width=300",
    category: "Mobile Development",
    level: "Intermediate",
    rating: 4.8,
    reviews: 480,
    students: 3900,
    duration: "32 hours",
    lectures: 110,
    price: 54.99,
    tags: ["flutter", "dart", "mobile", "android", "ios"],
    description:
      "Build beautiful cross-platform mobile apps with Flutter. Create apps for both Android and iOS with a single codebase.",
    isNew: true,
    isBestseller: false,
  },
  {
    id: 6,
    title: "Advanced JavaScript Concepts",
    instructor: "Fatima Al-Zahra",
    image: "/placeholder.svg?height=200&width=300",
    category: "Programming",
    level: "Advanced",
    rating: 4.9,
    reviews: 890,
    students: 7200,
    duration: "28 hours",
    lectures: 95,
    price: 64.99,
    tags: ["javascript", "es6", "nodejs", "async"],
    description:
      "Deep dive into advanced JavaScript concepts including closures, prototypes, async/await, and design patterns.",
    isNew: false,
    isBestseller: true,
  },
]

// Filter options
const categories = ["All Categories", "Programming", "Web Development", "Data Science", "Design", "Mobile Development"]
const levels = ["All Levels", "Beginner", "Intermediate", "Advanced"]

export default function CourseCatalogPage() {
  // State for filters and view
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All Categories")
  const [selectedLevel, setSelectedLevel] = useState("All Levels")
  const [priceRange, setPriceRange] = useState([0, 100])
  const [viewMode, setViewMode] = useState("grid")
  const [sortBy, setSortBy] = useState("popular")
  const [wishlist, setWishlist] = useState<number[]>([])

  // Toggle wishlist
  const toggleWishlist = (courseId: number) => {
    if (wishlist.includes(courseId)) {
      setWishlist(wishlist.filter((id) => id !== courseId))
    } else {
      setWishlist([...wishlist, courseId])
    }
  }

  // Filter courses
  const filteredCourses = courses.filter((course) => {
    // Search filter
    const matchesSearch =
      searchQuery === "" ||
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.instructor.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

    // Category filter
    const matchesCategory = selectedCategory === "All Categories" || course.category === selectedCategory

    // Level filter
    const matchesLevel = selectedLevel === "All Levels" || course.level === selectedLevel

    // Price filter
    const matchesPrice = course.price >= priceRange[0] && course.price <= priceRange[1]

    return matchesSearch && matchesCategory && matchesLevel && matchesPrice
  })

  // Sort courses
  const sortedCourses = [...filteredCourses].sort((a, b) => {
    switch (sortBy) {
      case "popular":
        return b.students - a.students
      case "rating":
        return b.rating - a.rating
      case "newest":
        return b.isNew ? 1 : -1
      case "price-low":
        return a.price - b.price
      case "price-high":
        return b.price - a.price
      default:
        return 0
    }
  })

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.4 },
    },
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 pb-20">
      {/* Hero section */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Explore Our Courses</h1>
            <p className="text-lg md:text-xl text-blue-100 mb-8">
              Discover a wide range of courses taught by expert instructors to help you achieve your goals
            </p>

            <div className="relative max-w-2xl mx-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 dark:text-slate-500" />
              <Input
                type="text"
                placeholder="Search for courses, topics, or instructors..."
                className="pl-10 h-12 bg-white/90 dark:bg-slate-800/90 text-slate-900 dark:text-white border-0 rounded-lg shadow-lg"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </motion.div>
        </div>
      </div>

      {/* Main content */}
      <div className="container mx-auto px-4 mt-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters - Desktop */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="hidden lg:block w-64 shrink-0"
          >
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-semibold text-lg">Filters</h3>
                <Button variant="ghost" size="sm" className="h-8 text-xs">
                  Reset All
                </Button>
              </div>

              <div className="space-y-6">
                {/* Category filter */}
                <div>
                  <h4 className="font-medium mb-3 text-sm text-muted-foreground">Category</h4>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <div key={category} className="flex items-center">
                        <Button
                          variant="ghost"
                          className={`justify-start px-2 h-8 w-full ${
                            selectedCategory === category
                              ? "bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
                              : ""
                          }`}
                          onClick={() => setSelectedCategory(category)}
                        >
                          {selectedCategory === category && <Check className="mr-2 h-4 w-4" />}
                          {category}
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Level filter */}
                <div>
                  <h4 className="font-medium mb-3 text-sm text-muted-foreground">Level</h4>
                  <div className="space-y-2">
                    {levels.map((level) => (
                      <div key={level} className="flex items-center">
                        <Button
                          variant="ghost"
                          className={`justify-start px-2 h-8 w-full ${
                            selectedLevel === level
                              ? "bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
                              : ""
                          }`}
                          onClick={() => setSelectedLevel(level)}
                        >
                          {selectedLevel === level && <Check className="mr-2 h-4 w-4" />}
                          {level}
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Price filter */}
                <div>
                  <h4 className="font-medium mb-3 text-sm text-muted-foreground">Price Range</h4>
                  <div className="px-2">
                    <Slider
                      defaultValue={[0, 100]}
                      max={100}
                      step={1}
                      value={priceRange}
                      onValueChange={setPriceRange}
                      className="mb-6"
                    />
                    <div className="flex items-center justify-between text-sm">
                      <span>${priceRange[0]}</span>
                      <span>${priceRange[1]}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Filters - Mobile */}
          <div className="lg:hidden mb-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="w-full flex items-center justify-between">
                  <div className="flex items-center">
                    <Filter className="mr-2 h-4 w-4" />
                    <span>Filters</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="rounded-full">
                      {selectedCategory !== "All Categories" ? "1" : "0"}
                    </Badge>
                    <ChevronDown className="h-4 w-4" />
                  </div>
                </Button>
              </SheetTrigger>
              <SheetContent side="bottom" className="h-[85vh]">
                <div className="h-full overflow-y-auto py-6 px-2">
                  <h3 className="font-semibold text-lg mb-6">Filters</h3>

                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="category">
                      <AccordionTrigger>Category</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 mt-2">
                          {categories.map((category) => (
                            <div key={category} className="flex items-center">
                              <Button
                                variant="ghost"
                                className={`justify-start px-2 h-8 w-full ${
                                  selectedCategory === category
                                    ? "bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
                                    : ""
                                }`}
                                onClick={() => setSelectedCategory(category)}
                              >
                                {selectedCategory === category && <Check className="mr-2 h-4 w-4" />}
                                {category}
                              </Button>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="level">
                      <AccordionTrigger>Level</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 mt-2">
                          {levels.map((level) => (
                            <div key={level} className="flex items-center">
                              <Button
                                variant="ghost"
                                className={`justify-start px-2 h-8 w-full ${
                                  selectedLevel === level
                                    ? "bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
                                    : ""
                                }`}
                                onClick={() => setSelectedLevel(level)}
                              >
                                {selectedLevel === level && <Check className="mr-2 h-4 w-4" />}
                                {level}
                              </Button>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="price">
                      <AccordionTrigger>Price Range</AccordionTrigger>
                      <AccordionContent>
                        <div className="px-2 mt-4">
                          <Slider
                            defaultValue={[0, 100]}
                            max={100}
                            step={1}
                            value={priceRange}
                            onValueChange={setPriceRange}
                            className="mb-6"
                          />
                          <div className="flex items-center justify-between text-sm">
                            <span>${priceRange[0]}</span>
                            <span>${priceRange[1]}</span>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>

                  <div className="mt-8 flex gap-4">
                    <Button variant="outline" className="flex-1">
                      Reset
                    </Button>
                    <Button className="flex-1">Apply Filters</Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Course listing */}
          <div className="flex-1">
            {/* Controls */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div className="text-sm text-muted-foreground">
                Showing <span className="font-medium text-foreground">{sortedCourses.length}</span> courses
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[180px] h-9">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popular">Most Popular</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                  </SelectContent>
                </Select>

                <div className="flex items-center border rounded-md overflow-hidden">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`h-9 w-9 rounded-none ${viewMode === "grid" ? "bg-muted" : ""}`}
                    onClick={() => setViewMode("grid")}
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`h-9 w-9 rounded-none ${viewMode === "list" ? "bg-muted" : ""}`}
                    onClick={() => setViewMode("list")}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Course grid/list */}
            {sortedCourses.length > 0 ? (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className={
                  viewMode === "grid"
                    ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-6"
                    : "space-y-6"
                }
              >
                {sortedCourses.map((course) => (
                  <motion.div key={course.id} variants={itemVariants}>
                    {viewMode === "grid" ? (
                      <Card className="h-full overflow-hidden hover:shadow-lg transition-shadow duration-300">
                        <div className="relative">
                          <img
                            src={course.image || "/placeholder.svg"}
                            alt={course.title}
                            className="w-full h-48 object-cover"
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            className="absolute top-2 right-2 h-8 w-8 rounded-full bg-white/80 hover:bg-white dark:bg-slate-800/80 hover:dark:bg-slate-800"
                            onClick={() => toggleWishlist(course.id)}
                          >
                            <Heart
                              className={`h-4 w-4 ${wishlist.includes(course.id) ? "fill-red-500 text-red-500" : ""}`}
                            />
                          </Button>
                          {course.isNew && (
                            <Badge className="absolute top-2 left-2 bg-green-500 hover:bg-green-600">New</Badge>
                          )}
                          {course.isBestseller && (
                            <Badge className="absolute top-2 left-2 bg-amber-500 hover:bg-amber-600">Bestseller</Badge>
                          )}
                        </div>

                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <Badge variant="outline" className="mb-2">
                              {course.category}
                            </Badge>
                            <div className="flex items-center">
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                              <span className="text-sm font-medium">{course.rating}</span>
                              <span className="text-xs text-muted-foreground ml-1">({course.reviews})</span>
                            </div>
                          </div>
                          <Link href="/coming-soon" className="hover:underline">
                            <h3 className="font-semibold text-lg line-clamp-2">{course.title}</h3>
                          </Link>
                          <p className="text-sm text-muted-foreground">By {course.instructor}</p>
                        </CardHeader>

                        <CardContent className="pb-2">
                          <p className="text-sm text-muted-foreground line-clamp-2 mb-4">{course.description}</p>

                          <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                            <div className="flex items-center">
                              <BookOpen className="h-3 w-3 mr-1" />
                              <span>{course.lectures} lectures</span>
                            </div>
                            <div className="flex items-center">
                              <Clock className="h-3 w-3 mr-1" />
                              <span>{course.duration}</span>
                            </div>
                            <div className="flex items-center">
                              <BarChart className="h-3 w-3 mr-1" />
                              <span>{course.level}</span>
                            </div>
                          </div>
                        </CardContent>

                        <CardFooter className="pt-4 border-t flex items-center justify-between">
                          <div className="font-bold">${course.price.toFixed(2)}</div>
                          <Link href="/coming-soon">
                            <Button size="sm">View Course</Button>
                          </Link>
                        </CardFooter>
                      </Card>
                    ) : (
                      <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
                        <div className="flex flex-col md:flex-row">
                          <div className="relative md:w-64 shrink-0">
                            <img
                              src={course.image || "/placeholder.svg"}
                              alt={course.title}
                              className="w-full h-48 md:h-full object-cover"
                            />
                            <Button
                              variant="ghost"
                              size="icon"
                              className="absolute top-2 right-2 h-8 w-8 rounded-full bg-white/80 hover:bg-white dark:bg-slate-800/80 hover:dark:bg-slate-800"
                              onClick={() => toggleWishlist(course.id)}
                            >
                              <Heart
                                className={`h-4 w-4 ${wishlist.includes(course.id) ? "fill-red-500 text-red-500" : ""}`}
                              />
                            </Button>
                            {course.isNew && (
                              <Badge className="absolute top-2 left-2 bg-green-500 hover:bg-green-600">New</Badge>
                            )}
                            {course.isBestseller && (
                              <Badge className="absolute top-2 left-2 bg-amber-500 hover:bg-amber-600">
                                Bestseller
                              </Badge>
                            )}
                          </div>

                          <div className="flex-1 p-6">
                            <div className="flex flex-wrap justify-between items-start gap-2 mb-2">
                              <Badge variant="outline">{course.category}</Badge>
                              <div className="flex items-center">
                                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                                <span className="text-sm font-medium">{course.rating}</span>
                                <span className="text-xs text-muted-foreground ml-1">({course.reviews})</span>
                              </div>
                            </div>

                            <Link href="/coming-soon" className="hover:underline">
                              <h3 className="font-semibold text-xl mb-1">{course.title}</h3>
                            </Link>
                            <p className="text-sm text-muted-foreground mb-3">By {course.instructor}</p>

                            <p className="text-sm text-muted-foreground mb-4">{course.description}</p>

                            <div className="flex flex-wrap gap-4 text-xs text-muted-foreground mb-4">
                              <div className="flex items-center">
                                <BookOpen className="h-3 w-3 mr-1" />
                                <span>{course.lectures} lectures</span>
                              </div>
                              <div className="flex items-center">
                                <Clock className="h-3 w-3 mr-1" />
                                <span>{course.duration}</span>
                              </div>
                              <div className="flex items-center">
                                <BarChart className="h-3 w-3 mr-1" />
                                <span>{course.level}</span>
                              </div>
                              <div className="flex items-center">
                                <Users className="h-3 w-3 mr-1" />
                                <span>{course.students.toLocaleString()} students</span>
                              </div>
                            </div>

                            <div className="flex items-center justify-between mt-auto pt-4 border-t">
                              <div className="font-bold text-lg">${course.price.toFixed(2)}</div>
                              <Link href="/coming-soon">
                                <Button>View Course</Button>
                              </Link>
                            </div>
                          </div>
                        </div>
                      </Card>
                    )}
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <div className="text-center py-12">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 mb-4">
                  <X className="h-8 w-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-medium mb-2">No courses found</h3>
                <p className="text-muted-foreground mb-6">Try adjusting your search or filter criteria</p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchQuery("")
                    setSelectedCategory("All Categories")
                    setSelectedLevel("All Levels")
                    setPriceRange([0, 100])
                  }}
                >
                  Reset Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
